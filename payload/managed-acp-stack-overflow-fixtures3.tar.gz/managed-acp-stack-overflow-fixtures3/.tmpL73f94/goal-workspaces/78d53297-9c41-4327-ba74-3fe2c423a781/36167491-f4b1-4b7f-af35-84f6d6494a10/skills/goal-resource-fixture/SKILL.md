---
name: goal-resource-fixture
description: Fixture material for selected context
---
GOAL_RESOURCE_SKILL_MARKER: report actual verification.
