# Development Guide

This document is the workspace-level guide for BitRouter internals. Start with [`README.md`](../README.md) for the product introduction, then use this guide when you need to understand how the workspace is assembled or how to build on top of the SDK.

## Workspace Architecture

BitRouter is a Cargo workspace organized into `crates/` for shared libraries and contracts, `apps/` for product hosts, and `extensions/` for independently delivered capabilities. Each extension groups its related Cargo packages in one directory; `helpers/` contains contributor tooling.

| Crate                            | Tier    | Responsibility                                                                                                          |
| -------------------------------- | ------- | ----------------------------------------------------------------------------------------------------------------------- |
| `crates/bitrouter-ai`            | crate   | Model semantics, three-protocol codecs, SSE framing, selected-model HTTP calls, injected auth transactions and explicit catalog runtime; no router/application dependency |
| `crates/bitrouter-sdk`           | crate   | The SDK: three protocol pipelines, hook traits, staged AI executor integration, config loading, the axum HTTP server, and the observability contract (`observe`) |
| `extensions/regex-checker/matcher` | extension library | Rules and native request-check callback; optional `sdk` retains legacy hooks |
| `crates/bitrouter-telemetry`     | crate   | Optional telemetry egress: the OTLP exporter (traces + metrics, multi-tenant attribution), the inbound ingress span, and the `tracing` ↔ OTel bridge — all default-off |
| `crates/bitrouter-orchestrator` | crate | Durable Goals, versioned workflow/input/verification contracts, retained native Thread/Turn runtime, and optional native/external ACP runtime |
| `crates/bitrouter-tui` | crate | Goals, current Goal and read-only Workflow, plus shared terminal and retained native/ACP renderer components |
| `apps/bitrouter`                 | app     | Assembly library + the `bro` CLI binary (package/lib stay `bitrouter`) — assembles `App`, management commands, ACP host adapters and durable storage |

The `extensions/` directory expresses ownership and delivery boundaries; it does not create a loader or force a transport. Cargo packages remain ordinary Rust libraries or binaries. Custom hosts register native request checks through `bitrouter_sdk::extension::ExtensionApi` inside `assemble::build_app_with_extensions`; the SDK also retains legacy `Plugin`/hook interfaces for host assembly. See [the extension directory guide](../extensions/README.md) and [guardrails](../extensions/regex-checker/README.md).

For the native runtime module map, execution reading order and test layout, see
the [orchestrator source guide](../crates/bitrouter-orchestrator/README.md).

Protocol/process tests build real peers from the unpublished
[`bitrouter-test-fixtures`](../helpers/bitrouter-test-fixtures/Cargo.toml)
helper package. These fixtures depend only on ACP types and JSON; they do not
pull application/model/storage libraries into a test-time build. Fixture
construction still uses Cargo's reported executable, with no interpreter or
stale prebuilt-binary shortcut.

### External interfaces

Clients reach BitRouter through its external **interfaces** — the ways *in*. These are distinct from AI's three internal *wire-protocol adapters* (Chat Completions / Responses / Messages, described below): an interface is an entry point, an adapter is a dialect the `language_model` pipeline parses and speaks.

| Interface                 | Where it lives                                                                                            | Entry point              |
| ------------------------- | -------------------------------------------------------------------------------------------------------- | ------------------------ |
| **API** (HTTP LLM router) | `bitrouter-sdk` `server` feature (`crates/bitrouter-sdk/src/server.rs`) over the `language_model` pipeline | `bro serve`        |
| **MCP gateway**           | `bitrouter-sdk` `mcp` feature plus app assembly: downstream `/mcp` aggregation, configured upstream clients, Skills-over-MCP relay, and server-side tool execution | `POST /mcp`; `bro mcp check` |
| **ACP**                   | `bitrouter-orchestrator` `acp` feature (`crates/bitrouter-orchestrator/src/acp/`): controller, transport-generic client, agent-process transport and typed updates. The transparent stdio bridge, headless runner and Goal workers share these contracts. Subcommand glue lives in `apps/bitrouter/src/acp_cli.rs`. | `bro acp serve <agent>`; `bro run` |
| **Native ACP** | `bitrouter-orchestrator::acp::native`: negotiated v1/v2 handlers over the host's ThreadService. App `native_acp.rs` owns the local endpoint and stdio bridge; EOF detaches. | bare `bro acp serve` |
| **BRO Goals** | `bitrouter-tui::goals` draws Goals/current Goal/read-only Workflow; app `goal_code` submits identified local operations. Daemon `goal_runtime` coordinates Goal input and native/managed ACP workers through ThreadService; `GoalService` and app `goal_store` commit versioned requirements, arrangements and receipts. Superseded reconciled executions without active references move atomically to immutable operation history. | Bare `bro`; `bro code [--config PATH] [--workspace PATH]`; local Goal protocol v6 |
| **Native harness interface** | App `spawn` injects per-process router settings and starts the harness's own interface. | `bro claude`; `bro codex`; `bro launch <agent>` |
| **BRO native agent** | `bitrouter-orchestrator::service::ThreadService` owns retained Thread/Turn execution, durable context, FIFO/steering and owner/workspace fencing for standalone native work and linked Goal workers. Standalone native APIs do not automatically create Goals or bypass managed work controls. | `bro task run`; local v17 native socket; opt-in `/agent/v2` HTTP API |
| **CLI**                   | `apps/bitrouter` — the composition-root binary                                                            | `bro <subcommand>` |

The [BRO refactor](BRO_ORCHESTRATOR_REFACTOR_IMPLEMENTATION.md) has begun with
Goal-owner/input Thread links over the daemon's existing ThreadService. Planning,
input generation, review and completion evaluation now enter tool-free Turns
through its shared admission, runner, writer fencing and shutdown authority,
retaining the existing Goal model-control accounting. Native Goal workers now have an app dispatch path and explicit Thread/Turn
links. Native permission replies use the shared approval transaction; stopped
local effects use original-history/workspace reconciliation. Shared generation
admission and native worker admission share bounded capacity waiting; active cold recovery and worker quote
waiting still need closure. Managed ACP uses the same acceptance/control owner;
the supervisor supplies protocol/process facts. Historical unbound runs retain
their reconciliation path. Worker changes version the existing work and create
a new Thread after old stop/effects are confirmed; known local results are
transferred before dispatch. The ledger tracks remaining acceptance gates.
Migrations 000030/000031 fence incompatible database writers for execution links
and immutable requested-worker sources. They add no table and do not migrate
persistence into core.

Native Goal evidence now reads original Thread history and source-bound Goal
accounting receipts for prepared inputs, router bindings and actual SDK/fallback
reports. Bounded omissions and missing usage remain explicit. These read-only
reads do not authorize work. Prepared configuration alone does not establish
tool use, and commit times do not establish execution overlap. Actual received
native content now carries bounded intervals in the existing accounting report.
Only monotonic ticks with the same process clock identity support overlap;
wall timestamps, admission and provider elapsed time are insufficient. This
does not attest physical provider compute or a complete execution timeline.
Final live/provider, recovery and full-refactor qualification remain open.
Before fresh native/ACP worker admission, selected MCP descriptors must match
their saved preparation hash. ACP also checks the gap between accepted Thread
metadata and Turn admission. Existing accepted receipts keep their original
resource records when configuration later changes; these checks grant no tools.

**`bitrouter-tui` must not depend on the `bitrouter` app crate.** That absence
is the boundary, and Cargo enforces it: the app depends on the crate by path,
so the reverse edge is a cyclic-package error, not a review question. What it
prevents is **reachability** — daemon-wide data (the metering store, the
control socket, request history) is unreachable from the renderer rather than
merely unused. The previous terminal UI lived inside the application, could
reach any function in it, and accreted verbs with no command-line equivalent
until it was deleted; a module boundary was a promise, this one is a compiler
error.

**The ACP-generic charter is retired.** The crate was once forbidden from
naming any BitRouter concept. The check for it began life unanchored — as
`grep -rn "bitrouter/"`, which matched the doc comment that stated it — and was
later tightened to
`rg -n "bitrouter.dev/cost|COST_PROVENANCE_META_KEY" crates/bitrouter-tui/src`.
That tightened form worked, and this change deliberately breaks it: the
cost-provenance wire spelling now lives in `crates/bitrouter-tui/src/cost.rs`
(and is pinned equal to the controller's by a test in `acp_cli.rs`), because
splitting one `_meta` key across a crate boundary bought nothing but two
places to look. This is BitRouter's TUI and may name BitRouter's concepts.
Conforming to ACP is still how the renderer works, and a non-BitRouter agent
still renders — it lands in the honest-default branch of every control.

What has *not* changed is why any of it was chosen. The honesty rules are now
pinned by named tests rather than by an absent dependency: a cost nobody can
vouch for is never drawn as ours (the harness's own figure is labelled the
agent's, an unknown marker is not drawn, and no figure renders `unreported`,
never `$0.00`); a controller that advertises no route control gets no picker
rather than a dead one; a cancelled permission never resolves to consent. Those tests are the guard — deleting one is the change to refuse in
review.

Where a control's honesty depends on something ACP does not carry, the crate
takes it as a **parameter** rather than inferring it — `Picker::open` takes
whether the controller advertised route control, `Cost::new` takes who wrote
the figure — so there is no constructor that skips the question.

The rule these add up to, and it is enforced rather than agreed:

> **`apps/bitrouter` may touch the terminal. Only `bitrouter-tui` may draw on
> it.**

`apps/bitrouter` does not depend on `ratatui`. It cannot construct a widget, so
every drawn thing goes through the renderer crate and the compiler says so —
adding `ratatui` back to that manifest is the change to refuse in review.

What the app keeps is `crossterm`, and that is the rule rather than an exception
to it: crossterm is terminal **I/O** (owning stdin, bracketed paste, reading key
events), which is this process's, while ratatui is **drawing**, which is the
crate's.

The last surface short of this was `status --watch`, a self-refreshing ratatui
table over daemon-wide request rows. It could not move to `bitrouter-tui` —
those rows come from the metering store and cover every caller, most of which
never speak ACP, so importing them would have put a daemon-wide model inside a
session-scoped crate. It was removed instead, and `bro requests`
reports the same data through the ordinary CLI report layer
(`apps/bitrouter/src/output/reports/requests.rs`) — JSON by default, `--human`
for the table, and no terminal code anywhere in it.

The second line, which keeps the crate synchronous, is **meaning vs
transport**. What a key *means* is a terminal fact and lives in the crate
(`editor`: multiline composition; `code`: focus and interaction transitions). *Owning stdin and
delivering events* is a fact about the host process — what else it selects
over, and which runtime it has — so the pump stays in the app
(`apps/bitrouter/src/chat/code.rs`). The same cut keeps signal handling out
(`crate::chat::signals::Shutdown`) while terminal enter/restore stays in.
`bitrouter-tui` therefore depends on no async runtime at all, and
`cargo tree -p bitrouter-tui | rg -c '^tokio'` printing `0` is how that is
checked.

BRO native tools are `read`, `glob`, `grep`, `write`, `edit`, and `shell`.
`read` dispatches known workspace paths to file lines or direct directory
entries. The three inspection tools form the read-only profile. The server
resolves one interpreter before a coding execution; model commands and
verification share it. See [the six-tool contract](BRO_BASE_TOOLS_SPEC.md).

The native BRO runtime has one `ThreadService` per serving instance. App-owned
SQLite stores Thread/Turn facts, acceptance keys, public events and owner/version
fences. Clients only project state; detaching does not cancel, approve or resume.
Bounded tool workers, ordered exclusive effects, FIFO/steering, joined shutdown,
workspace locks/markers and bounded startup discovery preserve execution barriers.
Cold queries do not execute. Safe same-owner reload and explicit stopped-owner
checkpoint recovery preserve identities and budgets without replaying completed
effects; lost owners, unknown effects and uncertain accounting remain blocked.

Use [the standalone runtime contract](BRO_AGENT_RUNTIME_SPEC.md) for current
requirements, including root format 9 (reading formats 2–8) and local v17/HTTP v2. The
[runtime acceptance index](BRO_AGENT_RUNTIME_IMPLEMENTATION.md) separates local
fixtures, historical provider/platform checks and remaining product gates.
[Conversation UI](BRO_CONVERSATION_UI_SPEC.md) and
[six tools](BRO_BASE_TOOLS_SPEC.md) specialize that contract. Older phase ledgers
are historical references, not competing descriptions of current behavior.
Future [core/harness separation](BRO_AGENT_RUNTIME_HANDOFF.md) assigns live
scheduling/checkpoint semantics to Core and durable storage/ACK authority to
Harness; the standalone implementation does not prove that integration.
Router metering and external ACP session ownership retain their own boundaries.

The CLI is the **host** interface: it owns `main()` and mounts the other
interfaces as subcommands. The SDK owns protocol interop such as the MCP
gateway and ACP pipeline; the app owns local actions, composition, and human
presentation.

### Dependency Logic

Model semantic types, wire codecs, authentication contracts and credential values
have one owner in **`bitrouter-ai`**. The SDK, provider integrations and application
consumers depend directly on AI; AI has no SDK, application or agent-runtime
dependency. AI owns three generation codecs, the native Decisions codec, SSE framing and selected-model HTTP
invocation (`ModelClient` and `HttpTimeouts`); its errors carry domain facts rather
than gateway status policy. Explicitly registered `AuthApplier`s can shape a body,
authenticate and recover the same selected account once after a 401. `ModelClient`
performs no implicit catalog loading, account selection, login or routing fallback.

Native Decisions uses `DecisionRequest`/`DecisionResult` and
`ModelClient::decide`. SDK envelopes distinguish `PipelineInput::Generation`
from `PipelineInput::Decisions`, and the output variants likewise retain their
semantic operation. The HTTP gateway serves `POST /v1/decisions` through the
shared execution, delivery and settlement lifecycle. Streaming and generative
continuation/tool defaults are rejected or scoped before native dispatch.

Routing selects a compatible operation before preferred-protocol matching.
`ModelTarget.api_protocol` determines the AI client's outbound wire. Existing
generation calls prefer a supported inbound wire or the first configured
generation wire; the enum/unknown-host fallback is Chat Completions.

Route hooks may capture evidence in `after_resolve`, after every mutable
`resolve` hook and operation/effort filtering. App-owned `CaptureTariffs` freezes
each effective target's independent protocol tariff and endpoint profile here.
Published tariffs retain their optional `endpoint_profile` provenance across
registry merge and configuration changes, so global rates cannot silently rebind
to a regional endpoint. Legacy/custom tariffs without a declaration bind to the
configured endpoint. Metering and evaluation use that snapshot; `UsagePricingSnapshot` projects the
same rates to the SDK's conservative stream usage selection. Unknown frozen
prices disable live price lookup. Custom hosts composing `MeteringRecorder`
must also install `recorder.tariff_capture(require_known)` at the route stage.

`server.require_known_pricing` is opt-in and restart-required. It rejects routes
without guaranteed price coverage before I/O, including native Decisions while
cache billing remains unverified. Prices and endpoint profile anchors also
require restart. Native nonzero cache usage retains counters and raw evidence
with an unavailable cost. See [Decisions specification](DECISIONS_API_SPEC.md)
and the shipped [setup reference](../skills/bitrouter/references/decisions.md).

Codex subscription `generate` calls use upstream SSE and AI's canonical stream
collector; the SDK shares that collector and retains its gateway request policy
and execution envelope. Collection requires a terminal and consumes through EOF
before returning success. It preserves fields already present in canonical
events. Completed Responses reasoning now has a redacted AI-owned native capsule
carrying the final item payload. Responses JSON/SSE output retains its identity,
opaque encrypted content and native summary/content fields, while visible text
lanes remain separate. Snapshot consistency checks prevent native data from
restoring text changed by hooks. Responses ingress retains native reasoning, including
encrypted-only items. Native replay still requires future target/account authority
proofs. AI's content-free `ConversionReport` covers initial native-reasoning and
structured-output admission; direct invocation and SDK HTTP preflight use the same
request preparation. Router exclusions reach `ObserveHook::on_conversion_excluded`
before hop observers or provider execution, while an all-excluded chain returns a
typed incompatibility report. Other client codecs return output incompatibility
when they cannot retain native reasoning. Gateway status mapping stays in the SDK.
Built-in request parsing now also refuses initial ingress omissions before any partial
Prompt can enter the pipeline: unknown items/blocks, unsupported content values,
lossy system/tool-result shapes and unsigned Messages thinking.
Reports carry original wire indices and remain content-free. HTTP handler tests verify
400 responses before any executor call in ordinary and streaming modes. Shared request admission now also excludes initial structural history losses: omitted
reasoning/sources, provider execution or MCP identity lost in projection, unsupported
approval parts/reasons and omitted tool-result media/file IDs. Existing native-family
tool declarations remain eligible; unknown cross-family translation and non-object
argument loss are refused. Native continuity tokens cannot cross a wire that omits them. Native token
presence/representation and local denial pairing are not complete authority proofs.
Projection now also refuses explicit strict flags, schema names/descriptions and file
names that the selected codec would omit, plus tool-result error/denial status loss.
Google Chat admits a conservative target-scoped schema/option subset without rewriting constraints. Explicit cache resources and unverified strict/schema metadata are refused. A suppressed paired denial cannot lose its supplied reason.
Malformed argument strings cannot become empty objects on Messages. Chat and
Messages preserve text-only tool-result arrays, and Chat preserves multiple text parts.
Unclassified Chat ordering/reasoning concatenation and selected three-wire ingress
attribute/boundary losses are refused. Value-preserving JSON encoding into
string-only tool slots remains eligible; error/denial status is checked separately.
`ConversionReport.admitted` retains classified JSON encoding separately from refusal issues.
Selected-target preparation can return
the report through `ModelClient::render_request_with_report`; executor preflight returns
that assessment. The SDK rechecks refusals and invokes `on_conversion_admitted` for
eligible detected effects before hop start, without counting a candidate as an HTTP
attempt. Empty assessments emit no conversion callback. Remaining ingress attributes,
media/options/boundary effects, schema/model validation, other admitted classifications,
Core/durable recording, output effects and degradation authorization remain open.

`bitrouter-ai::catalog` owns the consumed provider/model schema, explicit bounded
refresh and source-keyed injected stores. A catalog starts empty with memory-only
storage; loading and network permission are separate explicit operations. Failed
parse, validation or persistence retains its prior snapshot. `apps/bitrouter/src/catalog.rs`
selects the 24-hour file cache and startup/reload refresh policy; `bundled_registry.rs`
supplies the committed offline baseline for the default public source. Unbound
legacy caches are preserved but not adopted as an assumed source. Activation,
credential lookup and user-config merge remain in the application/provider bridge.

`bitrouter_ai::providers::{anthropic,antigravity,claude_code,codex,copilot,hosted,supergrok}` implements
request-time authentication and adaptations over caller-injected sessions/stores. Generic OAuth
response decoding and bounded refresh live in `auth::oauth`; browser/login UI,
CLI import and file-path policy stay above AI. Application assembly constructs
the native sessions from its selected file backend and OAuth registration.
The selected default account label is owned by `auth::store::DEFAULT_ACCOUNT`.
Anthropic's API-key applier receives a credential backend directly. Claude Code
receives an `OAuthSession` and an explicitly permitted fallback token. Its live
CLI adoption backend and environment capture remain in
`bitrouter::providers::claude_code`; application assembly chooses those sources
and the public Anthropic OAuth client registration. These are explicit inputs;
AI performs no ambient source discovery or interactive login.
Explicit device authorization and bounded polling now live in
`bitrouter_ai::auth::device_code`. AI's opt-in `pkce` feature supplies
`auth::{pkce,auth_code,listener,login}` and `providers::login` registration inputs.
The application's `LoginUx` implementation supplies terminal hints and callback
HTML; the library owns state/redirect validation and the caller's total async
login deadline. The application retains its existing 15-minute deadline and
login-method/account selection. Dropping the library future releases its
listener and pending async callbacks; already-started blocking stdin work
remains an application limitation.
AI's `hosted-login` feature supplies `providers::hosted::flow` over explicit
`LoginParams`, including device authorization, deadline-bounded polling,
revocation and complete hosted envelope construction. Cloud settings/default
scopes and file persistence remain above AI. The `hosted` feature alone still
supplies request authentication/refresh without login's random-number dependency.
AI's opt-in `file-store` feature now owns ordinary explicit-path snapshots in
`auth::file::snapshot` and selected-account leases in `auth::file::backend`.
`apps/bitrouter/src/provider_credentials.rs` retains the existing XDG/Windows/home
location precedence and `oauth-tokens.json` filename. Reads preserve labeled and
legacy formats without writing; a later mutation uses the labeled format.
Administrative writes and refresh/composite backends bind to the same selected
path, including existing file/directory aliases and missing parent directories.
Relative paths bind at construction rather than following a later cwd change.
The [revised providers-retirement plan](BITROUTER_AI_REFACTOR_SPEC.md#revised-next-steps-retire-bitrouter-providers)
now places product activation/configuration and credential discovery in
`apps/bitrouter/src/providers`, and hosted account persistence/settings/assembly in
`apps/bitrouter/src/cloud/account`. The old providers package is removed locally.
Model, Cloud management and telemetry retain the same shared AI hosted session;
external consumer migration and publication remain separate verification work.
Native Gemini Generate Content and the private `google-ai` Antigravity transport are retired. Metered Google calls use the official Chat endpoint. Tool signatures retain canonical metadata and a selected-credential replay proof; clients must echo the entire tool-call `extra_content`. The proof is removed before upstream dispatch. See [retirement progress](GEMINI_PROTOCOL_RETIREMENT_PROGRESS.md) for the actual SDK limitation and live validation gates.

`ModelTarget` carries effective connection values, compatibility and an optional
caller-selected account label. SDK routing, header policy, continuation admission
and public error policy remain above AI. Stable credential/scheme proof primitives
live in AI; the SDK enforces bindings against the final outbound request. SDK
`HttpExecutor` delegates projection, HTTP I/O and decoding while retaining its
pipeline retry budget, hooks and settlement integration.

AI's injected account store holds a transaction through OAuth rotation and commit.
After acquiring the lease, `OAuthSession` owns completion independently of a dropped
caller future. The Codex applier uses this contract with either injected memory
storage or AI's explicitly constructed optional file backend. The file backend serializes
same-account refresh in process, preserves unrelated file entries, and rejects a
commit after login/logout replaces its original credential. Failed persistence
retains the rotated replacement for a later commit; this is volatile recovery,
not a claim of crash durability or cross-process exclusion. Ordinary subscription providers and Claude CLI adoption also use these transactions.
Explicit call overrides outrank stored credentials; permitted fallback is used only
for an absent slot. Copilot caches are source-bound. Google Chat tool continuity is bound to the effective static credential, endpoint and model. Hosted OAuth uses the richer owned
transaction contract in AI's optional `hosted` feature. `HostedSession` receives
a selected slot, full-envelope store and HTTP client; its shared metadata/token
decoders also serve application-driven device login. The application account
manager assembles a process-local file backend, while model calls, telemetry and
Cloud management all resolve through the same AI session. File policy, account
activation, CLI defaults and onboarding text stay above AI. See
[implementation progress](BITROUTER_AI_REFACTOR_PROGRESS.md).
**`apps`** composes the libraries, and the SDK never depends back on the host.

Note what that does *not* say: it constrains the direction of dependencies, not how much lives in the SDK. A capability belongs in the SDK when it is an **interop surface** — a *contract* the SDK's own domain model is rendered into, which must be identical across deployments to mean anything — and it goes behind a default-off feature so consumers who skip it pay nothing. Deployment business logic (auth, policy, charging, metering, content policy) stays out, whether it would point down cleanly or not.

Observability is the case in point, and it is the one the workspace previously got wrong in both directions. The contract is the **span schema** — the span names (`chat`, `route`, `settle`, the per-hop `chat`), the `bitrouter.*` attribute vocabulary, and the invariants that fail silently when a deployment re-derives them wrong (a hop is not a `gen_ai` generation; stamping it as one makes gen_ai-aware backends double-count cost). *That* is BitRouter semantics, it lives in `bitrouter-sdk` as `observe`, and it is behind no feature gate at all, because a deployment implementing the contract must not have to enable a renderer it is not using.

Rendering the contract onto a wire is not the contract. OTLP transport, bearer refresh, batch processing, endpoint configuration and cardinality limiting are one egress path's implementation — by volume, roughly 40% of the old module's production lines were transport and vendor glue and another 17% deployment configuration, against ~43% span semantics — and they ship in `bitrouter-telemetry`. They were briefly folded into the SDK behind a default-off feature; that placement cost the foundation crate two permanent 0.x public dependencies and needed three separate paragraphs of "do not read this as a precedent" to hold its shape. Both are gone. `ObserveHook` is the seam the renderer plugs into, and it is a seam with more than one production implementation: `apps/bitrouter` registers its own observers beside the OTLP one. See [`TELEMETRY_CRATE_SPEC.md`](TELEMETRY_CRATE_SPEC.md).

Because the schema is the contract, it is written down rather than inferred from a renderer's call sites. `crates/bitrouter-sdk/src/observe/schema.rs` declares every span, attribute, event, metric and silent-failure invariant, names no `opentelemetry` type, depends on nothing but `serde`, and renders to the committed artifact `crates/bitrouter-sdk/span-schema.json` — regenerate with `UPDATE_SPAN_SCHEMA=1 cargo test -p bitrouter-sdk committed_artifact` (default features: the module is ungated, and a staleness guard that only fired under `--all-features` would let the artifact rot everywhere else), and the ordinary test run fails when it is stale. It sits beside `public-api-deps.txt`, the crate's other generated manifest — but unlike that one it *ships* with the crate, because it is the interop surface. The declaration is `pub` for the same reason: a second renderer needs it at compile time, not just as JSON. The three helpers only a conformance suite calls — `span_def_for`, `value_type_matches` and `render_json` — sit behind the default-off `testing` feature instead, since public API with no production caller is what CLAUDE.md rule 4 forbids; the feature carries no dependency, so a renderer enables it under `[dev-dependencies]` and pays nothing. Conformance tests in `bitrouter-telemetry`'s `otel/exporter.rs`, `otel/acp.rs` and `otel/http_layer.rs` drive real lifecycles and assert that nothing reaches the wire the declaration does not describe, so the artifact is checked rather than aspirational. See [`TELEMETRY_CRATE_SPEC.md`](TELEMETRY_CRATE_SPEC.md).

1. **`bitrouter-sdk`** — the pipeline and gateway foundation. Knows nothing about which providers exist or how the binary is wired. It consumes model semantics from `bitrouter-ai` and owns:
   - **Three independent pipelines**, one per wire family. They are deliberately *not* generic over a shared hook trait — each has its own hook set:
     - `language_model` — the main pipeline: LLM completions with the full hook chain (pre-request → route → execute → settle), an interleaved stream stage, and read-only observation.
     - `mcp` — Model Context Protocol routing (pure routing, no settlement).
     - `acp` — Agent Client Protocol routing (pure routing, no settlement).
   - **Hook traits** — `PreRequestHook`, `RouteHook`, `ExecutionHook`, `StreamHook`, `SettlementRecorder`, `ObserveHook` — trusted host assembly interfaces used by builtins and legacy packages. New request-check extensions use the restricted author API rather than mutable pipeline hooks.
   - **Config + routing** — YAML parsing, `${VAR}` substitution, the `ConfigRoutingTable`.
   - The **axum HTTP server** and the `App` builder.
2. **`bitrouter-ai`** — owns catalog metadata, protocol codecs, selected-target invocation and authentication. It has no SDK or application dependency. Explicit login and ordinary file storage are opt-in features; external CLI/Keychain discovery, account selection, product activation and Cloud management remain in the application.
3. **`bitrouter-guardrails`** provides the regex matcher and the SDK request-check callback; its explicit `sdk` feature enables legacy global/stream hooks. It depends on `bitrouter-sdk` with default features disabled. The default host still has no normal/build dependency on the matcher. **`bitrouter-telemetry`** implements SDK hooks; telemetry's whole OpenTelemetry stack sits behind `otel-*` and its ingress span behind `server`, so `cargo add bitrouter-telemetry` on its own pulls neither. The `feature-isolation` CI job enforces all of it, plus the invariant that gives the split its point: **no `opentelemetry*` crate is in `bitrouter-sdk`'s tree at any feature combination**, and the two OTLP transports stay isolated from each other.
4. **`apps/bitrouter`** — owns `providers::{apply,builtin,entry,registry,import,claude_code,antigravity}` for configuration, activation and credential-source policy; `cloud::account::{credentials,transaction,manager,settings}` retains Cloud account files and shared AI session assembly. The only compiled-in provider entry is `apps/bitrouter/providers/bitrouter.toml`; other providers come from AI catalog metadata and the product registry bridge. The app assembles the default host without a guardrails matcher dependency. The assembly layer (`assemble.rs`) turns a parsed `Config` into a running `App` by wiring the builtin hooks (auth, policy, metering, observability) and router-bound native request checks onto the `language_model` pipeline; `main.rs` is a thin CLI shell over that library.

### Extension authors and host assembly

New request-check authors use an ordinary function accepting
`bitrouter_sdk::extension::ExtensionApi` and call
`request_check(id, revision, callback)`. Business inputs and decisions live in
`extension::request_check`, without a wire envelope. The custom host passes the
registration function to `host::serve_with_extensions` for the shared foreground
daemon lifecycle, or `assemble::build_app_with_extensions` for low-level embedding.
Fragment and coverage types also live in `extension::request_check`.
Router bindings
control execution scope and order; registration is not global activation.
Beta supports compiled extensions only: no HTTP checker service, wire crate,
probe command, runtime installation or extra extension API crate.

Valid unconfigured registrations are inactive with sorted startup diagnostics;
configured instances require a matching registration even without bindings.
The regex example uses the same inference, local/remote management, reload and
shutdown path as `bro serve`. Restart custom hosts with their own executable;
the example does not implement the default CLI's background-launch protocol.

The SDK entry does not expose host builders, migrations, credentials or mutable
pipeline context. The host retains resource bounds, fixed binding identity and
bounded content-free tracing. Synchronous callbacks cannot be forcibly
terminated by deadlines; they are trusted in-process code.

Legacy `Plugin` / `AppBuilder::plugin` and optional `GuardrailsPlugin` retain
custom-host global, stream/output and migration semantics. Input-only checks do
not replace those capabilities. The recently introduced app ExtensionApi and
Native map assembly entry migrate to the SDK entry. `PluginId`, existing
`Config::plugins` consumers, Context extensions and external agent-plugin
manifests retain their separate meanings. See [migration](GUARDRAILS_EXTENSION.md).

### SDK feature flags

The SDK keeps its default dependency tree minimal — capabilities that pull weight are feature-gated:

| Feature        | Pulls in                              | Purpose                                                       |
| -------------- | ------------------------------------- | ------------------------------------------------------------- |
| `server`       | axum, tower                           | The HTTP server, SSE handlers, admin endpoints                |
| `config_file`  | serde-saphyr, `tokio::fs`             | YAML `bitrouter.yaml` loading                                 |
| `mcp`          | rmcp                                  | The bundled `RmcpExecutor` for the `mcp` pipeline             |
| `testing`      | nothing                               | `observe::schema`'s conformance helpers (`span_def_for`, `value_type_matches`, `render_json`) — for a renderer's `[dev-dependencies]`, never a production build |

ACP is no longer an SDK feature. The controller, client, capture port, telemetry, translation and agent-process transport live in `crates/bitrouter-orchestrator/src/acp/`; the orchestrator's optional `acp` feature owns the official ACP SDK and conductor, and the app enables it. `config::agent` retains only `AcpAgentConfig`, `AcpTransport` and their validation error, so existing `agents:` YAML and schema stay compatible without pulling the protocol runtime into the SDK. The conductor still reaches the trace viewer and its HTTP server, but that dependency is confined to the orchestrator's ACP feature. Native-only consumers leave that feature disabled. CI checks that no ACP runtime package reaches the SDK, even under `--all-features`.

`observe` — the span schema and the `SpanAttributes` hatch — is otherwise **not** in this table: the declaration itself is ungated and carries no dependency beyond `serde`. Only the three helpers a conformance suite calls sit behind `testing`, which is why that row's "Pulls in" column is empty.

### `bitrouter-telemetry` feature flags

| Feature        | Pulls in                              | Purpose                                                       |
| -------------- | ------------------------------------- | ------------------------------------------------------------- |
| `otel`         | (selects `otel-http`)                 | OTLP export of the span / metric model — the entry point       |
| `otel-http`    | opentelemetry\*, tracing-opentelemetry, tracing-subscriber, opentelemetry-http, dashmap | The above over OTLP/HTTP + protobuf (reqwest + rustls) |
| `otel-grpc`    | the same stack plus tonic             | The above over OTLP/gRPC (tonic + native trust roots)          |
| `server`       | axum, http-body, pin-project-lite, `bitrouter-sdk/server` | The inbound ingress SERVER span, as a middleware over the SDK's router |

> **The public-dependency commitment lives with the renderer, and that is the point of the split.** `otel::subscriber::tracing_subscriber_layer` returns `impl tracing_subscriber::Layer<S>`, so **tracing-subscriber 0.3** and **tracing-core 0.1** are semver-committed public dependencies — of `bitrouter-telemetry`, which is default-off and which nothing else in the workspace links. They were public dependencies of `bitrouter-sdk` for one release cycle, where a `tracing-subscriber` 0.4 would have forced a breaking release on every consumer including the five that never enabled `otel`. `crates/bitrouter-sdk/public-api-deps.txt` records the removal. `server` is split out because the two halves have different consumers: a deployment that builds its own ingress span and only wants the bridge should not compile axum for it — the out-of-tree consumer is exactly that, since it installs its own `TraceLayer` so a public multi-tenant edge does not let callers control its trace ids or sampling.

Without `mcp` / `acp`, the SDK still exposes those pipelines, hook traits, and transport enums — a consumer can plug in a custom `Executor` without pulling rmcp or the stdio bridge.

> **Rule of thumb:** a feature exists only if disabling it removes a non-trivial set of dependencies. Pure module-visibility toggles are not features — the module is always compiled.

## Request Flow

A streaming LLM request moves through the workspace like this:

1. The `bitrouter` binary resolves the config source (see *Configuration*), loads or synthesises a `Config`, and `assemble.rs` builds an `App` — the `language_model` pipeline with the builtin hooks wired on.
2. The SDK's axum server receives the inbound HTTP request on one of the protocol routes and the matching **inbound adapter** parses it into a canonical `PipelineRequest` (model name, messages, tools, params).
3. The `language_model` pipeline runs its stages:
   - **Pre-request** — local policy hooks, followed by explicitly bound external request checks. Authentication and normalization occur before router admission.
   - **Route** — the `RoutingTable` resolves the model name to a fallback chain of `RoutingTarget`s (provider + upstream model id + protocol); `RouteHook`s may rewrite the chain.
   - **Execute** — the executor dials the first target; on failure the `FallbackPolicy` decides whether to try the next. The **outbound adapter** for the target's protocol renders the provider request and decodes the provider response (and its SSE stream).
   - **Settlement** — every `SettlementRecorder` runs (metering, etc.), success or failure.
4. For streaming, the canonical `StreamPart` stream flows through the `StreamHook` stage and is re-encoded by the inbound adapter into the **client's** protocol — so a client written for the Responses protocol can transparently use a Messages upstream, and vice versa.
5. `ObserveHook`s receive read-only lifecycle events throughout; `bitrouter-telemetry` turns them into OTLP traces and metrics, and the binary's own observers consume the same events.

The `mcp` and `acp` pipelines are simpler: pure routing with no settlement.

## Configuration Model

### Config source resolution

When a subcommand doesn't pass `-c <path>`, the binary walks a fixed order (see `apps/bitrouter/src/paths.rs`):

1. **`-c <path>`** — explicit; a missing file is a hard error.
2. **`./bitrouter.yaml`** in the current directory.
3. **`$BITROUTER_HOME/bitrouter.yaml`** — if the env var is set, that file must exist.
4. **`~/.bitrouter/bitrouter.yaml`** — used if present.
5. **Zero-config in-memory defaults** — when nothing above exists. No file is written; `bro init` is the explicit way to scaffold one.

The daemon `chdir`s into the bitrouter home (the config file's directory, or `~/.bitrouter` for zero-config) on startup, so relative paths in the config — `database.url`, `server.control_socket` — and the socket / pid / log all resolve against one stable location.

### Zero-config and the provider catalog

In zero-config mode `bitrouter::providers::apply::zero_config()` builds a `Config` with `skip_auth: true`, `listen: 127.0.0.1:4356`, and the compiled-in hosted gateway auto-enabled when its API key is set in the environment. Every other public provider comes from the fetched-or-cached registry merge: an env-keyed registry provider becomes active when its credential is available, and a local-OAuth provider becomes active after `bro providers login <provider>`.

## HTTP Server Surface

The axum server lives behind the SDK's `server` feature (`crates/bitrouter-sdk/src/server.rs`):

| Route                               | Handler                          |
| ----------------------------------- | -------------------------------- |
| `POST /v1/chat/completions`         | Chat Completions inbound         |
| `POST /v1/responses`                | Responses inbound                |
| `POST /v1/messages`                 | Messages inbound                 |
| `POST /v1/decisions`               | Native Decisions inbound         |
| `GET  /v1/models`                   | model catalog listing            |
| `POST /mcp/{server}`                | MCP gateway (JSON-RPC proxy)     |
| `GET  /metrics`                     | OTLP-migration banner (see below)|
| `GET  /health`                      | health check                    |

`GET /metrics` is retained for endpoint compatibility only. Prometheus accumulation was removed: metrics are now *pushed* over OTLP by `bitrouter-telemetry`, and the endpoint serves a short banner pointing at `plugins.bitrouter-telemetry.otel` (`EmptyMetricsRenderer` in `apps/bitrouter/src/assemble.rs`). The SDK's `MetricsRenderer` trait and its `text/plain; version=0.0.4` content-type default still exist — a deployment that wants a real pull-based endpoint implements the trait itself.

Daemon mutation (`stop` / `restart` / `reload`) runs over a Unix domain socket.
When the optional authenticated HTTP control listener is enabled, it exposes
typed operator reads and reload operations behind its own bearer gate and
loopback exposure policy. It does not mount an MCP origin endpoint. See
`apps/bitrouter/src/{daemon,remote_control}.rs`.

## CLI Surface

`bro <subcommand>` exposes lifecycle and reports plus agent-facing entries: `task run` (BRO headless), bare `code` (BRO interactive), `launch <agent>` (native interface), `code <agent>` (ACP UI), `run <agent>` (headless turn), and `acp serve` (native v1/v2 ingress) and `acp serve <agent>` (external manager endpoint). `claude`, `claude-code`, and `codex` are native shortcuts. `requests` is the canonical request-history report; `mcp check [server]` inspects configured upstream MCP servers. Old `spawn`, `chat`, `tui`, `tools`, and related compatibility leaves are hidden. See `apps/bitrouter/src/main.rs`.

### Observability surface (`bro requests`)

One surface, and no module of its own. `RequestsReport`
(`apps/bitrouter/src/output/reports/requests.rs`) is an ordinary `CliReport`:
the builder in `main.rs` polls the metering store and the control socket, and
`Human::table` / `Human::status_block` render it. There is no second table
implementation and no terminal-only path.

The `apps/bitrouter/src/tui/` module it replaced is **deleted**. It had become a
618-line private implementation of one public function that bypassed `Output`
(so `--json` was silently ignored) and reimplemented `output/human.rs`'s table.
Its signal arm moved to `chat/signals.rs`, next to its only caller.

`apps/bitrouter` no longer depends on `ratatui`; `crates/bitrouter-tui` owns
drawn terminal UI for ACP chat.

The hosted mode `bro launch --tui` and its VT emulator (`tui/host.rs`, `tui/term.rs`, `tui/pty.rs`, `tui/conformance.rs`, `tui/fixtures/`) are **deleted**, along with the fidelity matrix that gated them and the `alacritty_terminal` / `portable-pty` / `termwiz` / `wezterm-input-types` dependencies. See [`ACP_TUI_SPEC.md`](ACP_TUI_SPEC.md) for the reasoning and for what replaces it — an inline-viewport ACP client rather than a terminal emulator.

`spawn::prepare` still builds the child once and `exec_inherited` runs it; the `Prepared` seam is kept independent of hosting.

## Where To Extend The System

### Add or update a provider

Add a provider definition under `registry/providers/*.yaml` (the registry source; `dist/` is regenerated by `helpers/dist-helper`). `bearer` / `header` auth needs no Rust. For a regional or per-account base URL, use `${VAR}` in `api_base` — it is resolved from the environment at merge time (e.g. Bedrock `https://bedrock-mantle.${AWS_REGION}.api.aws/v1`). For stateful auth (OAuth, token-exchange), add an injected `AuthApplier` impl in `crates/bitrouter-ai/src/providers/` keyed by the registry `auth.handler` and register it in `apps/bitrouter/src/assemble.rs::build_auth_appliers` (see `copilot`). See [`CONTRIBUTING.md`](../CONTRIBUTING.md) for the step-by-step.

### Add a new wire protocol

Protocol adapters live in `crates/bitrouter-ai/src/protocol/`. A new protocol needs an inbound adapter (parse request / encode response + SSE), an outbound adapter (render request / decode response + SSE), a variant on `ApiProtocol`, dispatch wiring, and coverage in the protocol-conversion test matrix.

### Add a provider whose wire isn't HTTP+JSON+SSE

Rare — no current registry provider needs this. The big clouds (Bedrock, Azure) speak one of BitRouter's built-in protocols over SSE and are ordinary Bearer registry providers. Only if an upstream uses a wire an existing outbound adapter can't decode (e.g. a vendor SDK's binary event-stream) do you add an `ApiProtocol::Custom` outbound adapter + `Transport` in a standalone crate, registered on the dispatch executor at startup. See the `Custom` escape-hatch docs in `crates/bitrouter-ai/src/protocol/mod.rs`.

### Add a hook (auth, policy, metering, guardrail, observability)

Implement one of the SDK hook traits (`PreRequestHook`, `RouteHook`, `ExecutionHook`, `StreamHook`, `SettlementRecorder`, `ObserveHook`) and wire it onto the pipeline in `apps/bitrouter/src/assemble.rs`. A hook that brings real dependency weight belongs in its own `crates/` library behind a default-off feature — the telemetry pattern. Guardrails run as an independently deployed input checker in the default product; the library's optional SDK hooks are for explicit trusted-host assembly. What goes in the SDK is the *contract* such a hook binds to, not the hook: `observe::schema` is in the SDK, its OTLP renderer is not. A lightweight hook can live in the binary.

### Embed the SDK in your own service

`apps/bitrouter/src/assemble.rs` is the worked example: it builds an `App` via `App::builder()`, registers the `language_model` pipeline with a routing table, an executor, and the hook chain, then serves it. A consumer that wants BitRouter's routing + protocol conversion without the stock CLI composes the same builder with its own hooks and routing table.

## Validation

Before opening a change, run the workspace checks from [`CONTRIBUTING.md`](../CONTRIBUTING.md):

```sh
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo test --workspace --all-features
```

CI additionally runs `doc` (rustdoc under `-D warnings`), `doctest`, `feature-isolation` (the SDK's default tree stays free of axum, the OTel stack never reaches the SDK at any feature combination, and the two OTLP transports stay isolated), `sdk-public-api` (see below), and `msrv` (pinned to Rust 1.93). AI agents should also read [`CLAUDE.md`](../CLAUDE.md).

### The `sdk-public-api` job

`bitrouter-sdk` owns the observability contract without owning a renderer of it, which only holds while no `opentelemetry*` or `tracing_opentelemetry` type appears in any public SDK signature. `feature-isolation` now proves the stronger form — the stack is not in the SDK's tree at all — so this job is the *forward* guard: it is what catches the next change that pulls a renderer back in. The job renders the SDK's entire public surface with [`cargo public-api`](https://github.com/cargo-public-api/cargo-public-api) — one fully-qualified line per public item — greps that rendering for forbidden types, then reduces it to the set of foreign crates the public API reaches and diffs that against `crates/bitrouter-sdk/public-api-deps.txt`. That second half is the broader guard: a grep can only find a type you already know to look for, whereas the manifest catches the SDK quietly gaining a *new* public dependency — which is how `tracing_core` got there, through a generic bound. Full rationale in [`TELEMETRY_CRATE_SPEC.md`](TELEMETRY_CRATE_SPEC.md).

**If this job fails on your PR**, read which step failed. A forbidden-type or re-export failure is a real design problem — keep the OTel type out of the public signature (make it `pub(crate)`, or return `impl Trait`), do not regenerate around it. A public-dependency failure means your change added or removed a crate from the SDK's public API; a `+` line means an upstream breaking release in that crate now becomes a BitRouter breaking release, so confirm that is intended before regenerating:

```sh
rustup toolchain install nightly-2026-05-05
cargo install cargo-public-api --locked --version 0.52.0
cargo +nightly-2026-05-05 public-api \
  -p bitrouter-sdk --all-features --simplified \
  | grep -oE '\b[a-z_][a-z0-9_]*(::[a-zA-Z_][a-zA-Z0-9_]*)+' \
  | cut -d: -f1 | sort -u \
  | grep -vxE 'bitrouter_sdk|core|std|alloc'
```

Append the output under the comment header in `public-api-deps.txt` — the header is stripped before comparison, so keep it out of the generated part. Both versions are pinned in `crates/bitrouter-sdk/public-api.pins`, which the CI job reads; take them from there rather than from this snippet if the two ever disagree. They are pinned because the manifest is derived from `cargo public-api`'s rendering, and both rustdoc's JSON format and that rendering change across releases. Run it on Linux or macOS; the SDK has `#[cfg(unix)]` items, so a Windows-generated listing will not match.

### Named-router request checks

Named-router entry checks use the SDK's typed `language_model::request_checks`
contract. The app assembles startup-owned compiled registrations in
`request_checks`; a custom host supplies callbacks through
`extension::ExtensionApi`. The official `bro` binary has no custom
registrations, and there is no request-check inventory or receipt store.

Authentication and session/continuation normalization precede router binding.
The logical router/check binding remains fixed through candidate preparation,
model selection and fallback. One preparation path serves both response modes.
Checked routers apply effective defaults before content checks; ordinary local
hooks cannot change their selector afterward. Unguarded requests preserve the
legacy pre-request rewrite/defaults timing. The existing model selector and
executor run after required checks allow. Local policy rejection never invokes
a registered checker. The runtime emits bounded, content-free tracing for
registration and invocation outcomes; it does not expose checker inventory,
progress reporting or durable workflow state. Registration readiness and a
real invocation remain separate evidence.

See [REQUEST_CHECKS_SPEC.md](REQUEST_CHECKS_SPEC.md) for coverage, resource limits,
activation and the acceptance ledger. The default host no longer links
the matcher and rejects legacy `plugins.bitrouter-guardrails` configuration. See
[GUARDRAILS_EXTENSION.md](GUARDRAILS_EXTENSION.md) for custom-host assembly,
input-only scope, explicit migration blockers, and process-level verification.

### Native harness resources

`bitrouter-orchestrator::harness` owns direct MCP connections and local skills
discovery. The app supplies daemon-owned transport configuration and global roots;
active ThreadService Turns freeze inventories and execute MCP through existing
durable approval/tool barriers. SDK gateway interop and routed provider generation
retain their existing responsibilities. See [BRO harness resources](BRO_HARNESS_RESOURCES.md).
