//! Durable conversation and input contracts. Transports supply authenticated
//! callers and never select a workspace or permission grant on their behalf.

use std::path::PathBuf;

use bitrouter_sdk::caller::CallerContext;
use serde::{Deserialize, Serialize};

use crate::agent::AgentConfig;
use crate::item::CallRecord;
use crate::store::EffectStatus;
use crate::turn::{
    SteeringReceipt, TurnEvent, TurnLifecycle, TurnReceipt, TurnSnapshot, TurnStatus,
};

pub mod executor;

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PermissionProfile {
    ReadOnly,
    #[default]
    Ask,
    AllowEffects,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ThreadStatus {
    Idle,
    Busy,
    Paused,
    RecoveryRequired,
    Closing,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThreadTarget {
    pub thread_id: String,
    pub server_instance_id: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThreadSnapshot {
    pub server_instance_id: String,
    pub thread_id: String,
    /// Explicit Goal ownership, not inferred from parentage or model activity.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub owned_goal_id: Option<String>,
    /// Independent input interpretation while the Goal owner is occupied.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub input_for_thread_id: Option<String>,
    /// A delegated work attempt, independent of the owning Goal Thread.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub goal_work: Option<GoalWork>,
    pub status: ThreadStatus,
    pub workspace: PathBuf,
    pub model: String,
    pub permission_profile: PermissionProfile,
    pub context_version: u64,
    pub cursor: u64,
    pub active_turn_id: Option<String>,
    pub queued: Vec<TurnReceipt>,
    pub pause_reason: Option<String>,
    pub waiting_for_capacity: bool,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct GoalWork {
    pub owner_thread_id: String,
    pub goal_id: String,
    pub task_id: String,
    pub execution_id: String,
    pub task_revision: u64,
    pub control_source_revision: u64,
}

impl GoalWork {
    pub fn validate(&self) -> Result<(), String> {
        for id in [
            &self.owner_thread_id,
            &self.goal_id,
            &self.task_id,
            &self.execution_id,
        ] {
            crate::goal::identifier(id).map_err(|error| error.to_string())?;
        }
        if self.task_revision == 0 {
            return Err("Goal work requires a positive task revision".into());
        }
        Ok(())
    }
}

/// A completed close result. Replays must not retire newer attachments or work.
#[derive(Debug, Clone)]
pub struct ThreadCloseReceipt {
    pub snapshot: ThreadSnapshot,
    pub replayed: bool,
}

impl ThreadSnapshot {
    /// These host-created Threads run explicit, tool-free model inputs. They
    /// do not grant filesystem access through ordinary native Turn RPCs.
    pub fn is_goal_coordination(&self) -> bool {
        self.owned_goal_id.is_some() || self.input_for_thread_id.is_some()
    }
}

/// A cold directory projection. Listing does not load context or subscribe.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThreadDirectoryEntry {
    pub thread: ThreadSnapshot,
    pub turn_status: Option<TurnStatus>,
    pub turn_id: Option<String>,
    pub needs_input: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThreadDirectoryPage {
    /// Fixes directory membership, not the mutable status of each Thread.
    pub cutoff: u64,
    pub next_after: Option<u64>,
    pub entries: Vec<ThreadDirectoryEntry>,
}

/// Presentation comes from committed facts. SDK messages are not reconstructed
/// from this view or from its evictable live-output cache.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThreadView {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub recovery: Option<RecoveryState>,
    pub thread: ThreadSnapshot,
    pub config: executor::Config,
    pub verification_command: Option<String>,
    /// Active Turn, or the last activated Turn after it settles.
    pub latest_turn: Option<TurnSnapshot>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecoveryState {
    pub source_server_instance_id: String,
    #[serde(default)]
    pub source_execution_owner: Option<crate::store::ExecutionOwner>,
    pub source_cursor: u64,
    pub stored_status: ThreadStatus,
    pub stored_pause_reason: Option<String>,
    pub context_valid: bool,
    pub terminal_checkpoint: bool,
    pub turn: Option<RecoveryTurn>,
    pub blockers: Vec<RecoveryBlocker>,
}

/// Explicitly accept one inspected durable checkpoint. A load alone never
/// grants continuation; retries retain the inspected source and operation key.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThreadRecoveryRequest {
    pub source_server_instance_id: String,
    pub source_cursor: u64,
    pub idempotency_key: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecoveryTurn {
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub acp_continuation: Option<crate::service::worker::acp::Continuation>,
    #[serde(default)]
    pub resources: Option<crate::harness::HarnessInventory>,
    pub turn_id: String,
    pub user_item_id: String,
    pub cancel_requested: bool,
    pub budget: RecoveryBudget,
    pub steering: Vec<RecoveredSteering>,
    pub unresolved_calls: Vec<CallRecord>,
    #[serde(default)]
    pub continuation_checkpoint: bool,
    #[serde(default)]
    pub outcome: Option<crate::store::SettlementOutcome>,
    #[serde(default)]
    pub confirmed_verification: Option<(
        crate::turn::VerificationStatus,
        crate::turn::VerificationEvidence,
    )>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct RecoveryBudget {
    pub model_steps: u32,
    pub tool_calls_known: u32,
    pub tool_calls_unknown: bool,
    pub estimated_spend_microusd: u64,
    pub estimated_spend_available: bool,
    pub usage_unknown_steps: Vec<String>,
    pub active_duration_ms: u64,
    pub active_duration_unknown: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecoveredSteering {
    pub receipt: SteeringReceipt,
    pub text: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum RecoveryBlocker {
    AcpSessionUnconfirmed,
    OwnershipUnconfirmed,
    EffectUnconfirmed { item_id: String, tool_name: String },
    UnsettledCall { item_id: String, tool_name: String },
    ModelRequestIncomplete { step_id: String },
    InvalidRecord { detail: String },
    BudgetUncertain { detail: String },
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum ThreadChange {
    AcpPermissions {
        turn_id: String,
        pending: Vec<crate::service::worker::acp::Permission>,
    },
    AcpPermissionChoice {
        turn_id: String,
        request_id: String,
        option_id: String,
    },
    AcpProcessStop {
        turn_id: String,
        observation: crate::service::worker::acp::Stop,
    },
    AcpSession {
        turn_id: String,
        binding: Box<crate::service::worker::acp::Binding>,
    },
    ContextRouting {
        turn_id: String,
        inspection: Box<crate::core::context_router::inspection::Inspection>,
    },
    Created {
        view: Box<ThreadView>,
    },
    TurnQueued {
        receipt: TurnReceipt,
        user_item_id: String,
        prompt: String,
    },
    TurnActivated {
        turn_id: String,
        context_version: u64,
    },
    QueuedTurnCancelled {
        turn_id: String,
    },
    QueueResumed,
    Recovered {
        source_server_instance_id: String,
        source_cursor: u64,
    },
    Checkpoint {
        snapshot: ThreadSnapshot,
    },
    TurnLifecycle {
        turn_id: String,
        lifecycle: TurnLifecycle,
    },
    ModelStep {
        turn_id: String,
        step_id: String,
        item_id: String,
        context_version: u64,
    },
    AssistantResponse {
        turn_id: String,
        step_id: String,
        item_id: String,
        request_id: String,
        requested_model: String,
        usage: Option<bitrouter_ai::types::Usage>,
        message: bitrouter_ai::types::Message,
        calls: Vec<CallRecord>,
    },
    AssistantInterrupted {
        turn_id: String,
        step_id: String,
        item_id: String,
        partial: bitrouter_ai::types::Message,
        detail: String,
    },
    ToolIntent {
        turn_id: String,
        step_id: String,
        call: CallRecord,
    },
    ToolResult {
        turn_id: String,
        step_id: String,
        item_id: String,
        message: bitrouter_ai::types::Message,
        effect: EffectStatus,
    },
    VerificationResult {
        turn_id: String,
        call: CallRecord,
        evidence: crate::turn::VerificationEvidence,
        effect: EffectStatus,
        active_duration_ms: u64,
        tool_calls: u32,
    },
    ContextAdvanced {
        #[serde(default, skip_serializing_if = "Option::is_none")]
        generation: Option<crate::turn::GenerationOrigin>,
        #[serde(default, skip_serializing_if = "Option::is_none")]
        resources: Option<Box<crate::harness::HarnessInventory>>,
        turn_id: String,
        context_version: u64,
    },
}

/// One acknowledged Thread transaction; sequences are durable root cursors and
/// can have gaps because internal execution facts share the same stream.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThreadEvent {
    pub server_instance_id: String,
    pub thread_id: String,
    pub seq: u64,
    pub timestamp_ms: u64,
    pub changes: Vec<ThreadChange>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum ThreadObservation {
    Snapshot {
        view: Box<ThreadView>,
        resynchronized: bool,
        catchup: Vec<ThreadEvent>,
    },
    Event {
        event: Box<ThreadEvent>,
    },
    /// Volatile output anchored to a durable cutoff. It never advances the
    /// Thread cursor and is not replayed by history pagination.
    Live {
        after_cursor: u64,
        event: Box<TurnEvent>,
    },
}

pub struct ThreadHistoryRequest {
    pub after: u64,
    pub cutoff: Option<u64>,
    pub limit: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThreadHistoryPage {
    pub server_instance_id: String,
    pub thread_id: String,
    pub cutoff: u64,
    pub events: Vec<ThreadEvent>,
    pub next_after: Option<u64>,
}

pub struct ThreadRequest {
    pub caller: CallerContext,
    pub workspace: PathBuf,
    pub config: AgentConfig,
    pub permission_profile: PermissionProfile,
    pub verification_command: Option<String>,
    pub idempotency_key: String,
}

/// Trusted host configuration; this is not accepted from an input RPC.
pub struct WorkspaceGrant {
    pub workspace: PathBuf,
    pub permission_profiles: Vec<PermissionProfile>,
}
