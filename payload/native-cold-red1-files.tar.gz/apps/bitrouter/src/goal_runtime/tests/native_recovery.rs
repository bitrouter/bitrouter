//! Controlled SQLite checkpoint images, actual SDK requests and local reads.
//! Source shutdown really joins before its stopped proof is transferred. This
//! is not abrupt-process retirement or private ACP context recovery.
use super::*;
use bitrouter_orchestrator::store as execution;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use tokio::sync::Semaphore;
use wiremock::matchers::{method, path};
use wiremock::{Mock, MockServer, Request};

#[derive(Clone, Copy)]
enum Boundary {
    SettledRead,
    PendingRead,
}

struct BarrierStore {
    inner: Arc<crate::agent_store::DatabaseExecutionStore>,
    boundary: Boundary,
    result_seen: AtomicBool,
    fired: AtomicBool,
    ready: Semaphore,
    release: Semaphore,
}

fn contains(
    record: &execution::ExecutionRecord,
    predicate: fn(&execution::ExecutionRecord) -> bool,
) -> bool {
    predicate(record)
        || matches!(record, execution::ExecutionRecord::TurnRecord { fact, .. } if contains(fact, predicate))
}

#[async_trait::async_trait]
impl ExecutionStore for BarrierStore {
    async fn read_index(
        &self,
        after: u64,
        cutoff: Option<u64>,
        limit: usize,
        bytes: usize,
    ) -> std::result::Result<execution::ExecutionIndexPage, String> {
        self.inner.read_index(after, cutoff, limit, bytes).await
    }
    async fn claim_owner(&self, id: &str) -> std::result::Result<execution::OwnerClaim, String> {
        self.inner.claim_owner(id).await
    }
    async fn read_owner(
        &self,
        id: &str,
    ) -> std::result::Result<Option<execution::ExecutionOwner>, String> {
        self.inner.read_owner(id).await
    }
    async fn stop_owner(
        &self,
        owner: &execution::ExecutionOwner,
    ) -> std::result::Result<execution::ExecutionOwner, String> {
        self.inner.stop_owner(owner).await
    }
    async fn commit_owned(
        &self,
        owner: &execution::ExecutionOwner,
        id: &str,
        expected: u64,
        records: &[execution::ExecutionRecord],
    ) -> std::result::Result<u64, String> {
        let version = self
            .inner
            .commit_owned(owner, id, expected, records)
            .await?;
        if records.iter().any(|record| {
            contains(record, |fact| {
                matches!(fact, execution::ExecutionRecord::ToolResult { .. })
            })
        }) {
            self.result_seen.store(true, Ordering::SeqCst);
        }
        let matched = records.iter().any(|record| {
            contains(
                record,
                match self.boundary {
                    Boundary::SettledRead => |fact| {
                        matches!(
                            fact,
                            execution::ExecutionRecord::RunCheckpoint {
                                model_steps: 1,
                                tool_calls: 1,
                                ..
                            }
                        )
                    },
                    Boundary::PendingRead => {
                        |fact| matches!(fact, execution::ExecutionRecord::ToolIntent { .. })
                    }
                },
            )
        });
        if matched
            && (matches!(self.boundary, Boundary::PendingRead)
                || self.result_seen.load(Ordering::SeqCst))
            && self
                .fired
                .compare_exchange(false, true, Ordering::SeqCst, Ordering::SeqCst)
                .is_ok()
        {
            // The complete batch is durable, but Core cannot advance before
            // this existing acknowledgement returns. No source facts are cut.
            self.ready.add_permits(1);
            self.release
                .acquire()
                .await
                .map_err(|error| error.to_string())?
                .forget();
        }
        Ok(version)
    }
    async fn commit(
        &self,
        id: &str,
        expected: u64,
        records: &[execution::ExecutionRecord],
    ) -> std::result::Result<u64, String> {
        self.inner.commit(id, expected, records).await
    }
    async fn load(
        &self,
        id: &str,
    ) -> std::result::Result<Option<execution::StoredExecution>, String> {
        self.inner.load(id).await
    }
    async fn read_records(
        &self,
        id: &str,
        after: u64,
        cutoff: Option<u64>,
        limit: usize,
        bytes: usize,
    ) -> std::result::Result<Option<execution::ExecutionPage>, String> {
        self.inner
            .read_records(id, after, cutoff, limit, bytes)
            .await
    }
    async fn thread_history(
        &self,
        id: &str,
        after: u64,
        cutoff: u64,
        limit: usize,
        bytes: usize,
    ) -> std::result::Result<execution::ThreadHistoryChunk, String> {
        self.inner
            .thread_history(id, after, cutoff, limit, bytes)
            .await
    }
    async fn find_key(
        &self,
        scope: &str,
        key: &str,
    ) -> std::result::Result<Option<execution::AcceptedKey>, String> {
        self.inner.find_key(scope, key).await
    }
}

fn model_app(routing: Arc<ConfigRoutingTable>) -> Result<Arc<App>> {
    let executor = Arc::new(bitrouter_sdk::language_model::HttpExecutor::with_defaults()?);
    Ok(Arc::new(
        App::builder()
            .skip_auth(true)
            .language_model(|model| {
                model.routing_table(routing).executor(executor);
            })
            .build()?,
    ))
}

async fn stopped_source(
    source: &Coordinator,
    barrier: &BarrierStore,
    workspace: &Path,
) -> Result<()> {
    let closing = {
        let threads = source.threads.clone();
        tokio::spawn(async move { threads.shutdown().await })
    };
    tokio::time::timeout(Duration::from_secs(5), async {
        loop {
            match source.threads.register_local_workspace(workspace) {
                Err(error)
                    if error.code == bitrouter_orchestrator::service::ErrorCode::ShuttingDown =>
                {
                    break;
                }
                Err(error) => return Err(anyhow::Error::from(error)),
                Ok(_) => tokio::task::yield_now().await,
            }
        }
        Ok(())
    })
    .await??;
    barrier.release.add_permits(1);
    tokio::time::timeout(Duration::from_secs(10), closing).await??;
    Ok(())
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn native_goal_resumes_only_a_stopped_safe_original_checkpoint_without_rereading()
-> Result<()> {
    for (label, boundary, retired, paused) in [
        ("safe", Boundary::SettledRead, true, false),
        ("live-owner", Boundary::SettledRead, false, false),
        ("pending-read", Boundary::PendingRead, true, false),
        ("paused", Boundary::SettledRead, true, true),
    ] {
        let mut home = tempfile::tempdir()?;
        let retained = std::env::var_os("BRO_GOAL_FIXTURE_KEEP_FAILURES").is_some();
        home.disable_cleanup(retained);
        if retained {
            eprintln!("Native recovery fixture {label}: {}", home.path().display());
        }
        let backend = MockServer::start().await;
        let calls = Arc::new(AtomicUsize::new(0));
        let recorded = Arc::new(std::sync::Mutex::new(Vec::<serde_json::Value>::new()));
        Mock::given(method("POST")).and(path("/v1/chat/completions")).respond_with({
            let calls=calls.clone();let recorded=recorded.clone();move |request:&Request| {
                calls.fetch_add(1,Ordering::SeqCst);
                let Ok(body)=serde_json::from_slice::<serde_json::Value>(&request.body) else {return wiremock::ResponseTemplate::new(400)};
                if let Ok(mut values)=recorded.lock() {values.push(body.clone());}
                let seen=body["messages"].as_array().is_some_and(|messages|messages.iter().any(|message|message["role"]=="tool"));
                crate::goal_runtime::tests::native::completion(&body,if seen {
                    serde_json::json!({"role":"assistant","content":"The original seed read is retained; no second read was needed."})
                } else {serde_json::json!({"role":"assistant","tool_calls":[{"id":"cold-read","type":"function","function":{"name":"read","arguments":"{\"path\":\"seed.txt\"}"}}]})},if seen {"stop"} else {"tool_calls"})
            }
        }).mount(&backend).await;
        let extra = format!(
            "server: {{skip_auth: true}}\nproviders:\n  fixture:\n    api_base: {}/v1\n    api_key: native-cold-fixture-key\n    api_protocol: [{{'*': chat_completions}}]\n    models: [{{id: test-model}}]\nmodels:\n  cold-model:\n    endpoints: [{{provider: fixture, service_id: test-model}}]\n",
            backend.uri()
        );
        let url = format!(
            "sqlite://{}?mode=rwc",
            home.path().join("source.db").display()
        );
        let (mut source, db) = coordinator_with_config(home.path(), &url, &extra).await?;
        source.threads.shutdown().await;
        source.app = model_app(source.routing.clone())?;
        let barrier = Arc::new(BarrierStore {
            inner: Arc::new(crate::agent_store::DatabaseExecutionStore::new(db.clone())),
            boundary,
            result_seen: AtomicBool::new(false),
            fired: AtomicBool::new(false),
            ready: Semaphore::new(0),
            release: Semaphore::new(0),
        });
        source.threads = ThreadService::with_store(source.app.clone(), &[], barrier.clone())?;
        let mut destination = None;
        let result: Result<()> = async {
            let id = prepared_worker_attempt(
                &source,
                home.path(),
                None,
                Selection {
                    model_route: Some("cold-model".into()),
                    ..Default::default()
                },
            )
            .await?;
            let goal = read(&source, &id).await?;
            let task = &goal.workflow.tasks[0];
            let execution = &task.executions[0];
            tokio::fs::write(
                execution.workspace.join("seed.txt"),
                "ORIGINAL_COLD_EVIDENCE\n",
            )
            .await?;
            source.drive_task(&goal, task).await?;
            tokio::time::timeout(Duration::from_secs(10), barrier.ready.acquire())
                .await??
                .forget();
            let saved = read(&source, &id).await?;
            let original = saved.workflow.tasks[0].executions[0].clone();
            let binding = original
                .thread
                .clone()
                .context("original native binding missing")?;
            assert_eq!(
                calls.load(Ordering::SeqCst),
                1,
                "source advanced beyond the captured boundary: {label}"
            );
            let image = home.path().join("checkpoint.db");
            crate::upgrade_preflight::snapshot(&db, &image).await?;
            let image_url = format!("sqlite://{}?mode=rwc", image.display());
            let (mut resumed, image_db) =
                coordinator_with_config(home.path(), &image_url, &extra).await?;
            resumed.threads.shutdown().await;
            resumed.app = model_app(resumed.routing.clone())?;
            resumed.threads = ThreadService::with_store(
                resumed.app.clone(),
                &[],
                Arc::new(crate::agent_store::DatabaseExecutionStore::new(
                    image_db.clone(),
                )),
            )?;
            destination = Some((resumed, image_db));
            let (resumed, image_db) = destination.as_ref().context("destination missing")?;
            let source_epoch = source.threads.capabilities().server_instance_id;
            if retired {
                stopped_source(&source, &barrier, &original.workspace).await?;
                let stopped = barrier
                    .read_owner(&source_epoch)
                    .await
                    .map_err(anyhow::Error::msg)?
                    .context("source owner proof missing")?;
                assert!(
                    stopped.stopped_at_ms.is_some(),
                    "source did not join cleanly: {label}"
                );
                let store = crate::agent_store::DatabaseExecutionStore::new(image_db.clone());
                let mut snapshot_owner = store
                    .read_owner(&source_epoch)
                    .await
                    .map_err(anyhow::Error::msg)?
                    .context("copied owner missing")?;
                assert!(snapshot_owner.stopped_at_ms.is_none());
                snapshot_owner.stopped_at_ms = stopped.stopped_at_ms;
                assert_eq!(
                    snapshot_owner, stopped,
                    "copied owner identity differs from the joined source"
                );
                snapshot_owner.stopped_at_ms = None;
                // Only after actual source join, affirm that same epoch's
                // stopped proof in its checkpoint image. Never retire a live owner.
                store
                    .stop_owner(&snapshot_owner)
                    .await
                    .map_err(anyhow::Error::msg)?;
            }
            if paused {
                let current = read(resumed, &id).await?;
                resumed
                    .goals
                    .execute(
                        "local",
                        GoalCommand::Control {
                            operation_id: "pause-cold-source".into(),
                            goal_id: id.clone(),
                            expected_revision: current.revision,
                            intent: RunIntent::Pause,
                        },
                        now()?,
                    )
                    .await?;
            }
            assert_eq!(calls.load(Ordering::SeqCst), 1);
            tokio::fs::write(
                original.workspace.join("seed.txt"),
                "CHANGED_AFTER_SOURCE_JOIN\n",
            )
            .await?;
            let before = read(resumed, &id).await?;
            resumed.claim_owner(&before).await?;
            let target = ThreadTarget {
                thread_id: binding.thread_id.clone(),
                server_instance_id: resumed.threads.capabilities().server_instance_id,
            };
            resumed
                .drive_task(&before, &before.workflow.tasks[0])
                .await?;
            let after = read(resumed, &id).await?;
            assert_eq!(after.workflow.tasks[0].executions.len(), 1);
            assert_eq!(
                after.workflow.tasks[0].executions[0].thread,
                Some(binding.clone())
            );
            assert_eq!(
                after.workflow.owner_thread_id,
                saved.workflow.owner_thread_id
            );
            assert!(!after.workflow.completion.completed_for(1));
            if matches!(boundary, Boundary::SettledRead) && retired && !paused {
                assert!(
                    !matches!(
                        after.workflow.tasks[0].executions[0].observation,
                        Observation::Unknown { .. }
                    ),
                    "safe accepted native checkpoint was only projected as unknown"
                );
                let done = tokio::time::timeout(Duration::from_secs(10), async {
                    loop {
                        let turn = resumed
                            .threads
                            .read_stored_turn(&target, &CallerContext::local(), &binding.turn_id)
                            .await?;
                        if turn.status == TurnStatus::Completed {
                            return Ok::<_, anyhow::Error>(turn);
                        }
                        anyhow::ensure!(
                            !turn.status.terminal(),
                            "continuation failed: {:?}",
                            turn.detail
                        );
                        tokio::time::sleep(Duration::from_millis(10)).await;
                    }
                })
                .await??;
                assert!(!done.unknown_effect);
                assert_eq!(calls.load(Ordering::SeqCst), 2);
                let bodies = recorded
                    .lock()
                    .map_err(|_| anyhow::anyhow!("request capture lock poisoned"))?;
                let resumed_body = bodies
                    .get(1)
                    .context("resumed provider request missing")?
                    .to_string();
                assert!(resumed_body.contains("ORIGINAL_COLD_EVIDENCE"));
                assert!(!resumed_body.contains("CHANGED_AFTER_SOURCE_JOIN"));
                drop(bodies);
                let store = crate::agent_store::DatabaseExecutionStore::new(image_db.clone());
                let records = store
                    .load(&binding.thread_id)
                    .await
                    .map_err(anyhow::Error::msg)?
                    .context("resumed native history missing")?;
                assert_eq!(
                    records
                        .records
                        .iter()
                        .filter(|record| contains(record, |fact| matches!(
                            fact,
                            execution::ExecutionRecord::ToolIntent { .. }
                        )))
                        .count(),
                    1
                );
                resumed.drive_task(&after, &after.workflow.tasks[0]).await?;
                assert_eq!(calls.load(Ordering::SeqCst), 2);
            } else {
                assert_eq!(
                    calls.load(Ordering::SeqCst),
                    1,
                    "unsafe checkpoint dispatched a model: {label}"
                );
                assert!(
                    paused
                        || matches!(
                            after.workflow.tasks[0].executions[0].observation,
                            Observation::Unknown { .. }
                        )
                );
                assert_eq!(
                    after.run_intent,
                    if paused {
                        RunIntent::Pause
                    } else {
                        RunIntent::Run
                    }
                );
            }
            Ok(())
        }
        .await;
        stopped_source(&source, &barrier, home.path()).await?;
        if let Some((resumed, image_db)) = destination {
            resumed.threads.shutdown().await;
            resumed.supervisor.shutdown().await;
            image_db.close().await?;
        }
        source.threads.shutdown().await;
        source.supervisor.shutdown().await;
        db.close().await?;
        if result.is_ok() {
            home.disable_cleanup(false);
        }
        result.with_context(|| format!("native checkpoint case {label}"))?;
    }
    Ok(())
}
