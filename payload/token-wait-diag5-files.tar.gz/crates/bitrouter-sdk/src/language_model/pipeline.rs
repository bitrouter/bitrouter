//! The `language_model` flight pipeline plus its interleaved StreamHook stage.

use std::pin::Pin;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};
use std::{future::Future, mem};

use async_trait::async_trait;
use futures::{FutureExt, StreamExt};
use futures_core::Stream;
use tracing::Instrument;

use super::native_preparation::{
    NativePreparationRuntime, NativePreparationWorkKind, observe_pipeline,
    runtime as preparation_runtime,
};
use crate::error::{BitrouterError, Result};
use crate::extension::request_check::{Decision, Input};
use crate::language_model::context::PipelineContext;
use crate::language_model::executor::{Executor, StreamPartStream};
use crate::language_model::hooks::{
    ExecutionHook, FallbackDecision, HookDecision, HopOutcome, ObserveHook, Phase, PreRequestHook,
    RequestOutcome, RouteHook, StreamHook, StreamHopOutcome,
};
use crate::language_model::native::{
    NativeAttemptReport, NativeExecutionControl, NativeModelSelection, NativePlan, NativeRoute,
};
use crate::language_model::operations::{HookRegistration, OperationScope, applicable};
use crate::language_model::request_checks::{
    CheckerFailure, CheckerFailureKind, CheckerResult, MAX_REQUEST_CHECKS_PER_ROUTER,
    RequestCheckBinding, RequestCheckerRunner, content_fragments, decision_content_fragments,
};
use crate::language_model::routing::ModelResolution;
use crate::language_model::routing::{FallbackPolicy, RoutingTable};
use crate::language_model::server_tools::loop_controller::{ServerToolLoop, UpstreamTurn};
use crate::language_model::server_tools::stream::UpstreamStream;
use crate::language_model::server_tools::toolset::ToolContext;
use crate::language_model::settlement::{
    DeliveryAcknowledgement, RequiredDeliveryHandshake, RequiredFinalizationContext,
    RequiredFinalizationReceipt, RequiredFinalizer, SettlementContext, SettlementRecorder,
};

use crate::language_model::stream::{StreamOutcome, StreamProcessor};

use crate::language_model::types::{
    ExecutionResult, PipelineInput, PipelineOutput, PipelineRequest, PipelineResponse,
    RoutingTarget,
};
use bitrouter_ai::types::{ModelOperation, Prompt, ReasoningEffortSource, StreamPart};

/// The default SSE keepalive interval.
pub const DEFAULT_KEEPALIVE: Duration = Duration::from_secs(30);

enum ExecutionInput<'a> {
    Generation(&'a Prompt),
    Decisions(&'a bitrouter_ai::decisions::DecisionRequest),
}

struct StreamingExecution {
    stream: StreamPartStream,
    target: RoutingTarget,
    provider_started_at: Instant,
}

struct ResolvedRequestBinding {
    resolution: ModelResolution,
    request_checks: Vec<RequestCheckBinding>,
    resolved_selector: String,
}

/// Immutable ingress checks also apply to a managed context reconstruction.
struct FrozenRequestChecks(Vec<RequestCheckBinding>);

struct PreparedEntry {
    ctx: PipelineContext,
    chain: Vec<RoutingTarget>,
}

struct EntryPreparationFailure {
    error: BitrouterError,
    requires_settlement: bool,
}

impl EntryPreparationFailure {
    fn pre_request(error: BitrouterError) -> Self {
        Self {
            error,
            requires_settlement: false,
        }
    }

    fn request_check(error: BitrouterError) -> Self {
        Self {
            error,
            requires_settlement: false,
        }
    }

    fn route(error: BitrouterError) -> Self {
        Self {
            error,
            requires_settlement: true,
        }
    }
}

pub(crate) struct DeliveryPermit {
    ready: tokio::sync::oneshot::Receiver<Result<()>>,
    acknowledged: Option<tokio::sync::oneshot::Sender<DeliveryAcknowledgement>>,
    activation_completed: tokio::sync::oneshot::Receiver<Result<()>>,
    terminal_committed: Option<tokio::sync::oneshot::Sender<()>>,
}

impl DeliveryPermit {
    pub(crate) async fn deliver(mut self) -> Result<()> {
        match self.ready.await {
            Ok(Ok(())) => {
                // Activation follows the acknowledgement. Once it completes,
                // the terminal-commit signal and Ready return happen in this
                // same poll with no intervening await.
                let acknowledged = self
                    .acknowledged
                    .take()
                    .is_some_and(|ack| ack.send(DeliveryAcknowledgement::Delivered).is_ok());
                if acknowledged {
                    self.activation_completed.await.map_err(|error| {
                        BitrouterError::internal(format!(
                            "delivery activation ended unexpectedly: {error}"
                        ))
                    })??;
                    self.terminal_committed
                        .take()
                        .ok_or_else(|| {
                            BitrouterError::internal("delivery terminal commit was already used")
                        })?
                        .send(())
                        .map_err(|_| {
                            BitrouterError::internal("delivery terminal commit receiver closed")
                        })?;
                    Ok(())
                } else {
                    Err(BitrouterError::internal(
                        "delivery authorization closed before acknowledgment",
                    ))
                }
            }
            Ok(Err(error)) => Err(error),
            Err(error) => Err(BitrouterError::internal(format!(
                "delivery authorization ended unexpectedly: {error}"
            ))),
        }
    }

    #[cfg(any(feature = "server", test))]
    pub(crate) async fn fail(mut self, failure: BitrouterError) -> Result<()> {
        match self.ready.await {
            Ok(Ok(())) => {
                let acknowledged = self
                    .acknowledged
                    .take()
                    .is_some_and(|ack| ack.send(DeliveryAcknowledgement::Failed(failure)).is_ok());
                if acknowledged {
                    self.activation_completed.await.map_err(|error| {
                        BitrouterError::internal(format!(
                            "delivery compensation ended unexpectedly: {error}"
                        ))
                    })??;
                    self.terminal_committed
                        .take()
                        .ok_or_else(|| {
                            BitrouterError::internal("delivery terminal commit was already used")
                        })?
                        .send(())
                        .map_err(|_| {
                            BitrouterError::internal("delivery terminal commit receiver closed")
                        })?;
                    Ok(())
                } else {
                    Err(BitrouterError::internal(
                        "delivery authorization closed before failure acknowledgment",
                    ))
                }
            }
            Ok(Err(error)) => Err(error),
            Err(error) => Err(BitrouterError::internal(format!(
                "delivery authorization ended unexpectedly: {error}"
            ))),
        }
    }
}

pub(crate) struct PreparedStreamPart {
    pub(crate) part: StreamPart,
    pub(crate) delivery: Option<DeliveryPermit>,
}

pub(crate) struct PreparedPipelineResponse {
    pub(crate) response: PipelineResponse,
    pub(crate) delivery: DeliveryPermit,
    #[cfg(feature = "server")]
    pub(crate) model_id: String,
}

struct ControlledExecution {
    result: ExecutionResult,
    output_rejection: Option<BitrouterError>,
}

pub(crate) struct PreparedPipelineStream {
    pub(crate) parts: Pin<Box<dyn Stream<Item = Result<PreparedStreamPart>> + Send>>,
    #[cfg(feature = "server")]
    pub(crate) model_id: String,
}

enum DeliveryAuthorizationOutcome {
    Delivered,
    Disconnected,
    Failed(BitrouterError),
}

fn delivery_handshake() -> (DeliveryPermit, RequiredDeliveryHandshake) {
    let (ready_tx, ready_rx) = tokio::sync::oneshot::channel();
    let (acknowledged_tx, acknowledged_rx) = tokio::sync::oneshot::channel();
    let (activation_completed_tx, activation_completed_rx) = tokio::sync::oneshot::channel();
    let (terminal_committed_tx, terminal_committed_rx) = tokio::sync::oneshot::channel();
    (
        DeliveryPermit {
            ready: ready_rx,
            acknowledged: Some(acknowledged_tx),
            activation_completed: activation_completed_rx,
            terminal_committed: Some(terminal_committed_tx),
        },
        RequiredDeliveryHandshake::new_with_completion(
            ready_tx,
            acknowledged_rx,
            activation_completed_tx,
            terminal_committed_rx,
        ),
    )
}

struct ObservedUpstreamStream {
    inner: StreamPartStream,
    hooks: Vec<Arc<dyn ObserveHook>>,
    request_id: String,
    target: RoutingTarget,
    provider_started_at: Instant,
    terminal: bool,
}

impl ObservedUpstreamStream {
    fn notify(&mut self, outcome: StreamHopOutcome<'_>) {
        if self.terminal {
            return;
        }
        self.terminal = true;
        let duration_ms = crate::language_model::timing::elapsed_millis(self.provider_started_at);
        for hook in &self.hooks {
            let callback = std::panic::AssertUnwindSafe(|| {
                hook.on_stream_hop_end(&self.request_id, &self.target, outcome, duration_ms)
            });
            if std::panic::catch_unwind(callback).is_err() {
                tracing::warn!("ObserveHook::on_stream_hop_end panicked; swallowed");
            }
        }
    }
}

impl Stream for ObservedUpstreamStream {
    type Item = Result<StreamPart>;

    fn poll_next(
        mut self: Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Self::Item>> {
        let item = self.inner.as_mut().poll_next(cx);
        match &item {
            std::task::Poll::Ready(None) => self.notify(StreamHopOutcome::Completed),
            std::task::Poll::Ready(Some(Err(error))) => {
                self.notify(StreamHopOutcome::Failed(error));
            }
            std::task::Poll::Ready(Some(Ok(part))) if part.is_terminal() => {
                self.notify(StreamHopOutcome::Completed);
            }
            std::task::Poll::Ready(Some(Ok(_))) | std::task::Poll::Pending => {}
        }
        item
    }
}

impl Drop for ObservedUpstreamStream {
    fn drop(&mut self) {
        self.notify(StreamHopOutcome::Dropped);
    }
}

#[derive(Clone)]
struct StreamAttempt {
    target: RoutingTarget,
    provider_started_at: Instant,
}

/// The `language_model` flight pipeline. Holds the registered hooks for every
/// stage plus the routing table, fallback policy and executor. Built via
/// [`crate::language_model::PipelineBuilder`].
pub struct Pipeline {
    pub(crate) pre_resolution_hooks: Vec<HookRegistration<dyn PreRequestHook>>,
    pub(crate) router_preparation_hooks: Vec<HookRegistration<dyn PreRequestHook>>,
    pub(crate) pre_request_hooks: Vec<HookRegistration<dyn PreRequestHook>>,
    pub(crate) route_hooks: Vec<HookRegistration<dyn RouteHook>>,
    pub(crate) model_selectors:
        Vec<HookRegistration<dyn crate::language_model::routing::ModelSelector>>,
    pub(crate) execution_hooks: Vec<HookRegistration<dyn ExecutionHook>>,
    pub(crate) decision_model: Option<crate::decision_model::DecisionRuntime>,
    pub(crate) stream_hooks: Vec<Arc<dyn StreamHook>>,
    pub(crate) settlement_recorders: Vec<HookRegistration<dyn SettlementRecorder>>,
    pub(crate) required_finalizers: Vec<HookRegistration<dyn RequiredFinalizer>>,
    pub(crate) observe_hooks: Vec<HookRegistration<dyn ObserveHook>>,
    pub(crate) routing_table: Arc<dyn RoutingTable>,
    pub(crate) fallback_policy: Arc<dyn FallbackPolicy>,
    pub(crate) executor: Arc<dyn Executor>,
    /// When set, non-streaming execution runs through the server-side tool loop
    /// (`server_tools`): router tools are injected, the model's calls to them
    /// are executed by BitRouter, and the upstream is re-called until the model
    /// stops calling them — all behind one caller response. `None` keeps the
    /// pipeline strictly single-shot.
    pub(crate) server_tool_loop: Option<Arc<ServerToolLoop>>,
    pub(crate) keepalive_interval: Duration,
    /// Opt-in bounded delay schedule between retryable fallback candidates.
    /// The final entry repeats for longer chains.
    pub(crate) fallback_backoff: Vec<Duration>,
    /// Detached stream-finalization tasks. Every terminal stream moves its
    /// settlement here before awaiting it, so a client disconnect cannot cancel
    /// recorders after the terminal SSE frame has already been delivered.
    /// [`Pipeline::drain_required_pending_settlements`] awaits them on
    /// production graceful shutdown.
    pub(crate) pending_settlements: Arc<std::sync::Mutex<tokio::task::JoinSet<()>>>,
    /// Detached **non-streaming** executions ([`Pipeline::execute_detached`]).
    /// A `TaskTracker` (not the `JoinSet` above) because *every* non-streaming
    /// request runs here, so completed tasks must be reaped automatically
    /// rather than retained until shutdown. The graceful drain methods close
    /// and await it so a SIGTERM can't cut a request that the upstream is still
    /// billing us for.
    pub(crate) detached_executions: tokio_util::task::TaskTracker,
    pub(crate) request_checker_runner: Option<Arc<dyn RequestCheckerRunner>>,
    pub(crate) native_private_context:
        Option<Arc<dyn super::native_context::NativePrivateContextPolicy>>,
    pub(crate) native_cost_estimator:
        Option<Arc<dyn super::native_accounting::NativeCostEstimator>>,
    pub(crate) native_cost_source: Option<Arc<dyn super::native_accounting::NativeCostSource>>,
    pub(crate) served_operations: OperationScope,
}

/// Adapts the pipeline's fallback execution into an [`UpstreamTurn`] so the
/// server-side tool loop can re-call the upstream for each iteration.
struct PipelineUpstream<'a> {
    pipeline: &'a Pipeline,
    chain: &'a [RoutingTarget],
    ctx: &'a PipelineContext,
}

#[async_trait]
impl UpstreamTurn for PipelineUpstream<'_> {
    async fn run(&self, prompt: &Prompt) -> Result<ExecutionResult> {
        self.pipeline
            .execute_with_fallback(self.chain, ExecutionInput::Generation(prompt), self.ctx)
            .await
    }
}

/// Drives one upstream **streaming** turn for the server-side tool loop. Each
/// iteration uses the pipeline's standard fallback policy over the routing
/// `chain` until one stream starts. A fresh throwaway [`PipelineContext`] keeps
/// per-turn fallback/observation state separate while the real request context
/// stays owned by the settlement guard.
struct PipelineStreamUpstream {
    pipeline: Arc<Pipeline>,
    chain: Vec<RoutingTarget>,
    context: PipelineContext,
    latest_attempt: SharedStreamAttempt,
}

#[async_trait]
impl UpstreamStream for PipelineStreamUpstream {
    async fn run(&self, prompt: &Prompt) -> Result<StreamPartStream> {
        let ctx = self.context.fork_for_prompt(prompt.clone());
        let execution = self
            .pipeline
            .execute_stream_with_fallback(&self.chain, &ctx)
            .await?;
        store_stream_attempt(
            &self.latest_attempt,
            StreamAttempt {
                target: execution.target,
                provider_started_at: execution.provider_started_at,
            },
        );
        Ok(execution.stream)
    }
}

type SharedStreamAttempt = Arc<std::sync::Mutex<Option<StreamAttempt>>>;

fn store_stream_attempt(slot: &SharedStreamAttempt, attempt: StreamAttempt) {
    match slot.lock() {
        Ok(mut current) => *current = Some(attempt),
        Err(poisoned) => *poisoned.into_inner() = Some(attempt),
    }
}

fn load_stream_attempt(slot: &SharedStreamAttempt) -> Option<StreamAttempt> {
    match slot.lock() {
        Ok(current) => current.clone(),
        Err(poisoned) => poisoned.into_inner().clone(),
    }
}

fn sync_execution_target(ctx: &mut PipelineContext, slot: &SharedStreamAttempt) {
    let Some(attempt) = load_stream_attempt(slot) else {
        return;
    };
    ctx.set_successful_target(attempt.target.clone());
    let Some(execution) = ctx.execution_result.as_mut() else {
        return;
    };
    execution.provider_id = attempt.target.provider_name;
    execution.model_id = attempt.target.service_id;
    execution.account_label = attempt.target.account_label;
}

impl Pipeline {
    /// The routing table backing this pipeline.
    pub fn routing_table(&self) -> &Arc<dyn RoutingTable> {
        &self.routing_table
    }

    /// The SSE keepalive interval — used by the server's streaming path to wrap
    /// the outbound frame stream in [`crate::language_model::SseKeepaliveStream`].
    pub fn keepalive_interval(&self) -> Duration {
        self.keepalive_interval
    }

    /// Wait for every detached client-disconnect settlement task to finish.
    /// Call this from the HTTP server's graceful-shutdown path so a SIGTERM
    /// during heavy streaming traffic doesn't drop receipts.
    /// Returns the number of tasks drained.
    ///
    /// Race note: any new `StreamSettlementGuard::drop` *after* this method
    /// has swapped the JoinSet lands on a fresh empty set and is not awaited
    /// by *this* call. In practice axum's graceful shutdown awaits every
    /// in-flight handler/stream-consumer to drop before returning, so all
    /// Drops fire *before* `drain_pending_settlements` is called — the swap
    /// is correct under that contract.
    pub async fn drain_pending_settlements(&self) -> usize {
        let drained = self.drain_detached_work().await;
        if self.drain_required_finalizers().await.is_err() {
            tracing::error!(
                reason = "required_finalizer_drain_failed",
                "RequiredFinalizer background drain failed"
            );
        }
        drained
    }

    /// Wait for detached pipeline work and require every success-critical
    /// finalizer to drain successfully.
    ///
    /// Production servers must use this error-returning shutdown contract so
    /// unresolved durable ownership cannot be mistaken for a clean exit. It is
    /// safe to retry after an error: detached work remains drained while each
    /// finalizer re-enters its retained reconciliation evidence.
    pub async fn drain_required_pending_settlements(&self) -> Result<usize> {
        let drained = self.drain_detached_work().await;
        self.drain_required_finalizers().await?;
        Ok(drained)
    }

    async fn drain_detached_work(&self) -> usize {
        // Detached non-stream execution may itself enqueue finalizer rollback
        // and delivery-observation tasks. Drain it first so those tasks are in
        // the JoinSet before we take that set below.
        let mut drained = self.detached_executions.len();
        self.detached_executions.close();
        self.detached_executions.wait().await;

        // Take the JoinSet out of the mutex so we can `await` join_next
        // without holding a sync lock across an await.
        let mut taken = {
            let mut guard = match self.pending_settlements.lock() {
                Ok(g) => g,
                Err(p) => p.into_inner(),
            };
            mem::take(&mut *guard)
        };
        while taken.join_next().await.is_some() {
            drained += 1;
        }
        drained
    }

    async fn drain_required_finalizers(&self) -> Result<()> {
        for finalizer in &self.required_finalizers {
            finalizer.drain_pending_work().await?;
        }
        Ok(())
    }

    fn spawn_stream_finalization<F>(&self, future: F)
    where
        F: Future<Output = ()> + Send + 'static,
    {
        let future = future.instrument(tracing::Span::current());
        match self.pending_settlements.lock() {
            Ok(mut set) => {
                while set.try_join_next().is_some() {}
                set.spawn(future);
            }
            Err(poisoned) => {
                let mut set = poisoned.into_inner();
                while set.try_join_next().is_some() {}
                set.spawn(future);
            }
        }
    }

    /// Execute a non-streaming request that **always runs to completion**, even
    /// if the caller (an HTTP request handler) is dropped because the client
    /// disconnected.
    ///
    /// axum/hyper drops the request-handler future the instant the client
    /// disconnects, which would otherwise cancel the in-flight upstream call
    /// mid-prefill and skip Stage-4 settlement — the client pays nothing while
    /// the upstream still bills us for the request it accepted. This mirrors
    /// OpenRouter's documented behaviour: for non-streaming requests the model
    /// "will continue processing and you will be billed for the complete
    /// response" (<https://openrouter.ai/docs/api/reference/streaming>).
    ///
    /// The work is spawned onto a shutdown-tracked task, so dropping the
    /// returned future no longer cancels it. The connected caller still awaits
    /// the task's `JoinHandle` and gets the real response. Streaming requests
    /// keep their own cancel-on-disconnect path ([`Pipeline::execute_stream`]).
    pub async fn execute_detached(
        self: Arc<Self>,
        req: PipelineRequest,
    ) -> Result<PipelineResponse> {
        let prepared = self.execute_detached_prepared(req).await?;
        prepared.delivery.deliver().await?;
        Ok(prepared.response)
    }

    pub(crate) async fn execute_detached_prepared(
        self: Arc<Self>,
        req: PipelineRequest,
    ) -> Result<PreparedPipelineResponse> {
        self.execute_detached_prepared_with_mode(req, true, None)
            .await
    }

    async fn execute_detached_prepared_with_mode(
        self: Arc<Self>,
        req: PipelineRequest,
        run_server_tools: bool,
        control: Option<Arc<dyn NativeExecutionControl>>,
    ) -> Result<PreparedPipelineResponse> {
        let pipeline = Arc::clone(&self);
        // `tokio::spawn` does not propagate the current tracing span, so attach
        // it explicitly — otherwise the whole request's logs would detach from
        // the handler's request span / trace context.
        let span = tracing::Span::current();
        let (prepared_tx, prepared_rx) = tokio::sync::oneshot::channel();
        self.detached_executions.spawn(
            async move {
                let result = pipeline
                    .execute_prepared(req, run_server_tools, control)
                    .await;
                // A dropped handler drops the prepared delivery permit here;
                // upstream execution and settlement have nevertheless run on
                // this shutdown-tracked task.
                let _ = prepared_tx.send(result);
            }
            .instrument(span),
        );
        prepared_rx.await.map_err(|error| {
            BitrouterError::internal(format!(
                "non-streaming execution task failed to complete: {error}"
            ))
        })?
    }

    /// Execute a non-streaming request: the four stages, in order.
    pub async fn execute(&self, req: PipelineRequest) -> Result<PipelineResponse> {
        let prepared = self.execute_prepared(req, true, None).await?;
        prepared.delivery.deliver().await?;
        Ok(prepared.response)
    }

    /// One native agent turn. The host agent executes client tool calls; the
    /// SDK must not inject or execute its own server tools on this request.
    pub(crate) async fn execute_without_server_tools(
        self: Arc<Self>,
        req: PipelineRequest,
    ) -> Result<PipelineResponse> {
        // A cancelled agent may stop waiting for a model turn. The accepted
        // upstream request still needs to settle before its result is dropped.
        let prepared = Arc::clone(&self)
            .execute_detached_prepared_with_mode(req, false, None)
            .await?;
        prepared.delivery.deliver().await?;
        Ok(prepared.response)
    }

    pub(crate) async fn execute_native_controlled(
        self: Arc<Self>,
        req: PipelineRequest,
        control: Arc<dyn NativeExecutionControl>,
    ) -> Result<PipelineResponse> {
        let prepared = Arc::clone(&self)
            .execute_detached_prepared_with_mode(req, false, Some(control))
            .await?;
        prepared.delivery.deliver().await?;
        Ok(prepared.response)
    }

    async fn execute_prepared(
        &self,
        req: PipelineRequest,
        run_server_tools: bool,
        control: Option<Arc<dyn NativeExecutionControl>>,
    ) -> Result<PreparedPipelineResponse> {
        let PreparedEntry { mut ctx, chain } =
            self.prepare_entry(req, false, control.clone()).await?;

        if let Some(control) = &control {
            ctx.insert_extension(Arc::new(super::native_work::NativeWorkRuntime::new(
                control.clone(),
            )));
            if control.observe_stream() {
                ctx.insert_extension(Arc::new(super::executor::NativeStreamCapture::default()));
            }
        }
        let control = control.as_deref();

        if control.is_some()
            && let Some(tokens) = ctx.require_generation_prompt()?.params.max_tokens
        {
            ctx.insert_extension(Arc::new(
                crate::language_model::native::NativeOutputReservation(tokens),
            ));
        }
        let mut native_routes = if control.is_some() {
            chain
                .iter()
                .map(|target| {
                    let mut route = NativeRoute::from_target(target);
                    route.output_token_limit_supported =
                        self.executor.output_token_limit_support(target);
                    route
                })
                .collect::<Vec<_>>()
        } else {
            Vec::new()
        };
        let admission = match control {
            Some(control) => self
                .admit_native_plan(&chain, &mut ctx, &mut native_routes, control)
                .await
                .map(Some),
            None => Ok(None),
        };

        // ---- Stage 3: execution (with the server-side tool loop when configured) ----
        let exec_outcome = match (admission, ctx.input(), &self.server_tool_loop) {
            (Err(error), _, _) => Err(error),
            (Ok(_), PipelineInput::Generation(prompt), Some(server_loop)) if run_server_tools => {
                let tool_ctx = ToolContext::from_pipeline(&ctx);
                let upstream = PipelineUpstream {
                    pipeline: self,
                    chain: &chain,
                    ctx: &ctx,
                };
                server_loop
                    .run_with_provenance(prompt, &tool_ctx, &upstream)
                    .await
                    .map(|outcome| (outcome.result, outcome.provider_terminal_exposed, None))
            }
            (Ok(admission), PipelineInput::Generation(prompt), _) => self
                .execute_with_fallback_controlled(
                    &chain,
                    prompt,
                    &ctx,
                    control
                        .zip(admission.as_ref())
                        .map(|(control, admission)| (control, native_routes.as_slice(), admission)),
                )
                .await
                .map(|outcome| (outcome.result, true, outcome.output_rejection)),
            (Ok(_), PipelineInput::Decisions(request), _) => self
                .execute_with_fallback(&chain, ExecutionInput::Decisions(request), &ctx)
                .await
                .map(|result| ControlledExecution {
                    result,
                    output_rejection: None,
                })
                .map(|outcome| (outcome.result, true, outcome.output_rejection)),
        };
        match exec_outcome {
            Ok((result, provider_terminal_exposed, output_rejection)) => {
                if let Some(error) = output_rejection {
                    // The provider completed and may bill the entire result.
                    // Preserve its original usage for settlement, but never
                    // deliver rejected content or start a fallback attempt.
                    ctx.execution_result = Some(result);
                    self.run_settlement(
                        &mut ctx,
                        control.is_some_and(|control| control.observe_stream()),
                        Some(error.clone()),
                    )
                    .await;
                    self.observe_after(Phase::Settlement, &ctx).await;
                    self.observe_end(&ctx, RequestOutcome::Failed(error.clone()))
                        .await;
                    return Err(error);
                }
                // Managed execution retains terminal validity privately after
                // removing the raw Responses ID from output and receipts.
                let response_id_valid = ctx
                    .extension::<super::native_context::NativePrivateContextRuntime>()
                    .map_or_else(
                        || {
                            result
                                .result
                                .generation()
                                .and_then(|result| result.response_id.as_deref())
                                .is_some_and(|id| !id.is_empty())
                        },
                        |runtime| runtime.response_terminal_valid(),
                    );
                let native_responses_terminal_invalid = provider_terminal_exposed
                    && ctx.successful_target().is_some_and(|target| {
                        target.api_protocol == bitrouter_ai::types::ApiProtocol::Responses
                    })
                    && (!response_id_valid
                        || !matches!(
                            result
                                .result
                                .generation()
                                .and_then(|result| result.finish_reason.as_ref()),
                            Some(
                                bitrouter_ai::types::FinishReason::Stop
                                    | bitrouter_ai::types::FinishReason::Length
                            )
                        ));
                if native_responses_terminal_invalid {
                    let error = BitrouterError::UpstreamInvalidResponse {
                        message: "native Responses result has no valid successful terminal"
                            .to_string(),
                        usage: None,
                    };
                    ctx.execution_result = Some(result);
                    self.run_settlement(
                        &mut ctx,
                        control.is_some_and(|control| control.observe_stream()),
                        Some(error.clone()),
                    )
                    .await;
                    self.observe_after(Phase::Settlement, &ctx).await;
                    self.observe_end(&ctx, RequestOutcome::Failed(error.clone()))
                        .await;
                    return Err(error);
                }
                let native_response_completed = provider_terminal_exposed
                    && ctx.successful_target().is_some_and(|target| {
                        target.api_protocol == bitrouter_ai::types::ApiProtocol::Responses
                    })
                    && response_id_valid
                    && matches!(
                        result
                            .result
                            .generation()
                            .and_then(|result| result.finish_reason.as_ref()),
                        Some(
                            bitrouter_ai::types::FinishReason::Stop
                                | bitrouter_ai::types::FinishReason::Length
                        )
                    );
                ctx.set_nonstream_native_response_completed(native_response_completed);
                ctx.execution_result = Some(result);
                self.observe_after(Phase::Execution, &ctx).await;
            }
            Err(e) => {
                // Settlement still runs for failed requests (records the error).
                self.run_settlement(
                    &mut ctx,
                    control.is_some_and(|control| control.observe_stream()),
                    Some(e.clone()),
                )
                .await;
                self.observe_after(Phase::Settlement, &ctx).await;
                self.observe_end(&ctx, RequestOutcome::Failed(e.clone()))
                    .await;
                return Err(e);
            }
        }

        // ---- Stage 4: settlement ----
        let mut finalization = match self.prepare_required_finalizers(&ctx, false).await {
            Ok(finalization) => finalization,
            Err(error) => {
                self.run_settlement(
                    &mut ctx,
                    control.is_some_and(|control| control.observe_stream()),
                    Some(error.clone()),
                )
                .await;
                self.observe_after(Phase::Settlement, &ctx).await;
                self.observe_end(&ctx, RequestOutcome::Failed(error.clone()))
                    .await;
                return Err(error);
            }
        };
        self.run_settlement(
            &mut ctx,
            control.is_some_and(|control| control.observe_stream()),
            None,
        )
        .await;
        self.observe_after(Phase::Settlement, &ctx).await;
        let response = ctx.response()?;
        #[cfg(feature = "server")]
        let model_id = ctx
            .successful_target()
            .and_then(|target| self.routing_table.canonical_model_id(ctx.model(), &target))
            .unwrap_or_else(|| ctx.model().to_owned());
        let (delivery, authorization) = finalization.begin_delivery();
        let observe_hooks = applicable(&self.observe_hooks, ctx.operation());
        self.spawn_stream_finalization(async move {
            let outcome = match authorization.await {
                Ok(DeliveryAuthorizationOutcome::Delivered) => RequestOutcome::Completed,
                Ok(DeliveryAuthorizationOutcome::Disconnected) => {
                    RequestOutcome::ClientDisconnected
                }
                Ok(DeliveryAuthorizationOutcome::Failed(error)) => RequestOutcome::Failed(error),
                Err(error) => RequestOutcome::Failed(BitrouterError::internal(format!(
                    "delivery authorization outcome ended unexpectedly: {error}"
                ))),
            };
            for hook in &observe_hooks {
                hook.on_request_end(&ctx, &outcome).await;
            }
        });

        Ok(PreparedPipelineResponse {
            response,
            delivery,
            #[cfg(feature = "server")]
            model_id,
        })
    }

    async fn admit_native_plan(
        &self,
        chain: &[RoutingTarget],
        ctx: &mut PipelineContext,
        routes: &mut [NativeRoute],
        control: &dyn NativeExecutionControl,
    ) -> Result<crate::language_model::native::NativePlanAdmission> {
        use crate::language_model::native::{
            NativeCountedRequests, NativeInputCount, NativeInputCountReport,
        };
        let prompt = ctx.require_generation_prompt()?;
        let can_rebuild = ctx
            .extension::<crate::language_model::context::ProviderContinuation>()
            .is_none()
            && ctx
                .extension::<crate::language_model::context::SuppressProviderContinuation>()
                .is_none()
            && ["previous_response_id", "conversation"].iter().all(|key| {
                prompt
                    .params
                    .extra
                    .get(*key)
                    .is_none_or(serde_json::Value::is_null)
                    && prompt
                        .params
                        .supplemental_extra
                        .get(*key)
                        .is_none_or(serde_json::Value::is_null)
            });
        for rebuild_round in 0..=1 {
            for (route, target) in routes.iter_mut().zip(chain) {
                route.input_count = None;
                route.continuation = self.executor.native_continuation(
                    target,
                    ctx.require_generation_prompt()?,
                    ctx,
                );
                route.protocol_validation = self.executor.native_protocol_validation(
                    target,
                    ctx.require_generation_prompt()?,
                    ctx,
                );
            }
            let mut plan = NativePlan {
                request_id: ctx.request_id().to_owned(),
                original_model: ctx.original_model().to_owned(),
                effective_model: ctx.model().to_owned(),
                effort_source: ctx
                    .require_generation_prompt()?
                    .params
                    .reasoning_effort_source,
                prompt: ctx.require_generation_prompt()?.clone(),
                routes: routes.to_vec(),
                router: ctx.router_identity().cloned(),
            };
            for (index, target) in chain.iter().enumerate() {
                if !routes[index].requires_input_count() {
                    continue;
                }
                let route_index = u32::try_from(index)
                    .map_err(|_| BitrouterError::bad_request("route index exhausted"))?;
                let report_limit = super::native_auxiliary::limit(control, &plan.request_id)?;
                control.before_input_count(&plan, route_index).await?;
                let started = Instant::now();
                let outcome = match self
                    .executor
                    .count_input_tokens(target, ctx.require_generation_prompt()?, ctx)
                    .await
                {
                    Ok(outcome) => outcome,
                    // Errors can contain parser body previews, native continuation
                    // IDs or credentials from extensions. Persist categories only.
                    Err(error) => NativeInputCount::Unavailable {
                        reason: format!(
                            "input_count_failed:{}:{}",
                            error.error_code(),
                            error.status()
                        ),
                    },
                };
                let mut report = NativeInputCountReport {
                    request_id: plan.request_id.clone(),
                    route_index,
                    outcome,
                    elapsed_ms: started.elapsed().as_millis().min(u128::from(u64::MAX)) as u64,
                    report_rejection: None,
                };
                super::native_auxiliary::count(&mut report, report_limit)?;
                let outcome = report.outcome.clone();
                let rejected = report.report_rejection.is_some();
                control.after_input_count(report).await?;
                if rejected {
                    return Err(BitrouterError::UpstreamInvalidResponse {
                        usage: None,
                        message: super::native::NativeInputCountRejection::REASON.into(),
                    });
                }
                routes[index].input_count = Some(outcome);
            }
            plan.routes = routes.to_vec();
            let reservations = routes
                .iter()
                .zip(chain)
                .map(|(route, target)| {
                    self.native_cost_estimator.as_ref().and_then(|estimator| {
                        estimator.reservation_for_attempt(route, &plan.prompt, ctx, target)
                    })
                })
                .collect();
            let admission = match control
                .plan_with_token_reservations(plan.clone(), reservations)
                .await
            {
                Ok(admission) => admission,
                Err(error) => {
                    if rebuild_round == 0
                        && can_rebuild
                        && let Some(messages) = control.rebuild_context(&plan).await?
                    {
                        ctx.replace_managed_messages(messages)?;
                        let checks = ctx
                            .extension::<FrozenRequestChecks>()
                            .map(|checks| checks.0.clone())
                            .ok_or_else(|| {
                                BitrouterError::internal(
                                    "managed rebuild lost its request-check bindings",
                                )
                            })?;
                        let _ = super::native_auxiliary::limit(control, ctx.request_id())?;
                        control.before_context_validation(ctx.request_id()).await?;
                        let started = Instant::now();
                        let validated = async {
                            control.check_context_validation(ctx.request_id()).await?;
                            control
                                .validate_context_rebuild(
                                    &plan.prompt,
                                    ctx.require_generation_prompt()?,
                                    ctx.request_id(),
                                )
                                .await?;
                            self.revalidate_native_context(chain, ctx, &checks, control)
                                .await
                        }
                        .await;
                        let elapsed = started.elapsed();
                        let work_elapsed_ms = control
                            .context_validation_gate_duration()
                            .and_then(|gates| elapsed.checked_sub(gates))
                            .map(|duration| duration.as_millis().min(u128::from(u64::MAX)) as u64);
                        control
                            .after_context_validation(
                                crate::language_model::native::NativeContextValidationReport {
                                    request_id: ctx.request_id().to_owned(),
                                    allowed: validated.is_ok(),
                                    error_code: validated
                                        .as_ref()
                                        .err()
                                        .map(|error| error.error_code().to_owned()),
                                    elapsed_ms: elapsed.as_millis().min(u128::from(u64::MAX))
                                        as u64,
                                    work_elapsed_ms,
                                },
                            )
                            .await?;
                        validated?;
                        continue;
                    }
                    return Err(error);
                }
            };
            admission.validate(routes.len())?;
            if admission.route_indices.iter().any(|index| {
                matches!(
                    routes[*index as usize].protocol_validation,
                    crate::language_model::native::NativeProtocolValidation::Rejected { .. }
                )
            }) {
                return Err(BitrouterError::bad_request(
                    "admitted route failed managed protocol validation",
                ));
            }
            if admission.route_indices.iter().any(|index| {
                let route = &routes[*index as usize];
                route.constraints.input_token_counting.is_some()
                    && !matches!(route.input_count, Some(NativeInputCount::Counted { .. }))
            }) {
                return Err(BitrouterError::bad_request(
                    "admitted route has no successful configured input count",
                ));
            }
            ctx.insert_extension(Arc::new(NativeCountedRequests::default()));
            return Ok(admission);
        }
        Err(BitrouterError::bad_request(
            "managed context rebuild exhausted",
        ))
    }

    async fn revalidate_native_context(
        &self,
        chain: &[RoutingTarget],
        ctx: &mut PipelineContext,
        checks: &[RequestCheckBinding],
        control: &dyn NativeExecutionControl,
    ) -> Result<()> {
        for hook in self
            .pre_resolution_hooks
            .iter()
            .chain(&self.router_preparation_hooks)
            .chain(&self.pre_request_hooks)
            .filter(|hook| hook.supports(ctx.operation()))
        {
            control.check_context_validation(ctx.request_id()).await?;
            match hook.revalidate_context(ctx).await? {
                HookDecision::Allow => {}
                HookDecision::Deny(reason) => return Err(reason.into()),
            }
        }
        self.run_request_checks(ctx, checks, Some(control)).await?;
        for hook in self
            .route_hooks
            .iter()
            .filter(|hook| hook.supports(ctx.operation()))
        {
            control.check_context_validation(ctx.request_id()).await?;
            hook.revalidate_context(chain, ctx).await?;
        }
        Ok(())
    }

    /// Execute a streaming request: Stages 1–3 run eagerly (so pre-stream
    /// failures are real errors), then the canonical `StreamPart` stream flows
    /// through the StreamHook stage; Settlement runs once the stream terminates.
    pub async fn execute_stream(
        self: Arc<Self>,
        req: PipelineRequest,
    ) -> Result<Pin<Box<dyn Stream<Item = Result<StreamPart>> + Send>>> {
        let prepared = self.execute_stream_prepared(req).await?;
        Ok(Self::deliver_stream(prepared))
    }

    pub(crate) async fn execute_stream_without_server_tools(
        self: Arc<Self>,
        req: PipelineRequest,
    ) -> Result<Pin<Box<dyn Stream<Item = Result<StreamPart>> + Send>>> {
        let prepared = self.execute_stream_prepared_with_mode(req, false).await?;
        Ok(Self::deliver_stream(prepared))
    }

    fn deliver_stream(
        prepared: PreparedPipelineStream,
    ) -> Pin<Box<dyn Stream<Item = Result<StreamPart>> + Send>> {
        Box::pin(prepared.parts.then(|item| async move {
            let PreparedStreamPart { part, delivery } = item?;
            if let Some(delivery) = delivery {
                delivery.deliver().await?;
            }
            Ok(part)
        }))
    }

    pub(crate) async fn execute_stream_prepared(
        self: Arc<Self>,
        req: PipelineRequest,
    ) -> Result<PreparedPipelineStream> {
        self.execute_stream_prepared_with_mode(req, true).await
    }

    async fn execute_stream_prepared_with_mode(
        self: Arc<Self>,
        req: PipelineRequest,
        run_server_tools: bool,
    ) -> Result<PreparedPipelineStream> {
        let PreparedEntry { mut ctx, chain } = self.prepare_entry(req, true, None).await?;
        let latest_attempt: SharedStreamAttempt = Arc::new(std::sync::Mutex::new(None));

        // Route Stage 3 through the server-side tool loop when configured: the
        // merged stream becomes the "upstream" the settlement guard drains, so
        // settlement is unchanged. Otherwise the pipeline stays single-shot.
        let upstream_result = match &self.server_tool_loop {
            Some(server_loop) if run_server_tools => {
                let tool_ctx = ToolContext::from_pipeline(&ctx);
                let upstream_impl: Arc<dyn UpstreamStream> = Arc::new(PipelineStreamUpstream {
                    pipeline: self.clone(),
                    chain: chain.clone(),
                    context: ctx.fork_for_prompt(ctx.require_generation_prompt()?.clone()),
                    latest_attempt: latest_attempt.clone(),
                });
                match server_loop
                    .clone()
                    .run_stream(ctx.require_generation_prompt()?, &tool_ctx, upstream_impl)
                    .await
                {
                    Ok(stream) => load_stream_attempt(&latest_attempt)
                        .map(|attempt| StreamingExecution {
                            stream,
                            target: attempt.target,
                            provider_started_at: attempt.provider_started_at,
                        })
                        .ok_or_else(|| {
                            BitrouterError::internal(
                                "server-tool stream opened without a successful upstream attempt",
                            )
                        }),
                    Err(error) => Err(error),
                }
            }
            _ => match self.execute_stream_with_fallback(&chain, &ctx).await {
                Ok(execution) => {
                    store_stream_attempt(
                        &latest_attempt,
                        StreamAttempt {
                            target: execution.target.clone(),
                            provider_started_at: execution.provider_started_at,
                        },
                    );
                    Ok(execution)
                }
                Err(error) => Err(error),
            },
        };
        let upstream = match upstream_result {
            Ok(upstream) => upstream,
            Err(error) => {
                self.run_settlement(&mut ctx, false, Some(error.clone()))
                    .await;
                self.observe_after(Phase::Settlement, &ctx).await;
                self.observe_end(&ctx, RequestOutcome::Failed(error.clone()))
                    .await;
                return Err(error);
            }
        };
        // A placeholder execution result so Settlement has provider/model ids;
        // usage is folded in from the StreamContext at stream end.
        ctx.set_stream_provider_started_at(upstream.provider_started_at);
        ctx.execution_result = Some(ExecutionResult {
            provider_id: upstream.target.provider_name.clone(),
            model_id: upstream.target.service_id.clone(),
            account_label: upstream.target.account_label.clone(),
            result: bitrouter_ai::types::GenerateResult {
                content: Vec::new(),
                usage: None,
                finish_reason: None,
                response_id: None,
                stop_details: None,
                provider_metadata: Default::default(),
            }
            .into(),
            request_duration_ms: 0,
            upstream_duration_ms: None,
            server_tool_calls: Vec::new(),
        });
        self.observe_after(Phase::Execution, &ctx).await;

        let mut stream_context = ctx.stream_context();
        let pricing = self.stream_pricing(&ctx, &upstream.target);
        stream_context.accumulated_usage.set_pricing(pricing);
        let processor = StreamProcessor::new(
            self.stream_hooks.clone(),
            applicable(&self.observe_hooks, ModelOperation::Generation),
            stream_context,
        );

        // The guard owns the processor + context. Whatever happens to the
        // returned stream — drained to completion, errored, or **dropped early
        // by the client** — `on_stream_end` and Settlement run exactly once
        // so streaming settlement is never lost.
        #[cfg(feature = "server")]
        let model_id = self
            .routing_table
            .canonical_model_id(ctx.model(), &upstream.target)
            .unwrap_or_else(|| ctx.model().to_owned());
        let guard = StreamSettlementGuard {
            pipeline: self.clone(),
            latest_attempt,
            required_finalizer_receipt: None,
            state: Some(StreamDeliveryState::Pending(Box::new(
                PendingStreamDelivery {
                    processor: Some(processor),
                    ctx: Some(ctx),
                },
            ))),
        };

        Ok(PreparedPipelineStream {
            parts: Box::pin(self.drive_stream(upstream.stream, guard)),
            #[cfg(feature = "server")]
            model_id,
        })
    }

    /// The streaming driver: feeds upstream parts through the guard's
    /// `StreamProcessor`, yields the (possibly rewritten) parts, and on a
    /// normal/errored/aborted termination finalises via the guard. If the
    /// consumer drops the stream early, the guard's `Drop` impl finalises with
    /// `ClientDisconnected` instead.
    fn drive_stream(
        self: Arc<Self>,
        mut upstream: StreamPartStream,
        mut guard: StreamSettlementGuard,
    ) -> impl Stream<Item = Result<PreparedStreamPart>> + Send {
        async_stream::stream! {
            'pump: loop {
                match upstream.next().await {
                    Some(Ok(part)) => {
                        let processed = match guard.processor() {
                            Ok(processor) => processor.process_part(part).await,
                            Err(error) => Err(error),
                        };
                        match processed {
                            Ok(parts) => {
                                for p in parts {
                                    let delivery = if p.is_terminal() {
                                        match guard.finalize(StreamOutcome::Completed).await {
                                            Ok(delivery) => delivery,
                                            Err(error) => {
                                                yield Err(error);
                                                break 'pump;
                                            }
                                        }
                                    } else {
                                        None
                                    };
                                    let terminal = p.is_terminal();
                                    yield Ok(PreparedStreamPart { part: p, delivery });
                                    if terminal {
                                        break 'pump;
                                    }
                                }
                            }
                            Err(abort_err) => {
                                let _ = guard
                                    .finalize(StreamOutcome::Aborted(abort_err.clone()))
                                    .await;
                                yield Err(abort_err);
                                break 'pump;
                            }
                        }
                    }
                    Some(Err(e)) => {
                        let _ = guard
                            .finalize(StreamOutcome::UpstreamError(e.clone()))
                            .await;
                        yield Err(e);
                        break 'pump;
                    }
                    None => {
                        if let Err(error) = guard.finalize(StreamOutcome::Completed).await {
                            yield Err(error);
                        }
                        break 'pump;
                    }
                }
            }
        }
    }

    // ===== stage helpers =====

    async fn prepare_entry(
        &self,
        req: PipelineRequest,
        streamed: bool,
        control: Option<Arc<dyn NativeExecutionControl>>,
    ) -> Result<PreparedEntry> {
        let selection = control
            .as_deref()
            .map(NativeExecutionControl::model_selection);
        if !self.served_operations.contains(req.input.operation()) {
            return Err(BitrouterError::bad_request(
                "pipeline does not serve this model operation",
            ));
        }
        if streamed && req.input.operation() != ModelOperation::Generation {
            return Err(BitrouterError::bad_request(
                "Decisions does not support streaming",
            ));
        }
        if req
            .inbound_protocol
            .as_ref()
            .is_some_and(|protocol| protocol.operation() != req.input.operation())
        {
            return Err(BitrouterError::bad_request(
                "endpoint protocol does not match model operation",
            ));
        }
        let mut ctx = PipelineContext::new(req);
        if let Some(control) = control {
            if let Some(limit) = control.provider_response_byte_limit() {
                ctx.insert_extension(Arc::new(super::native::NativeResponseByteLimit(limit)));
            }
            ctx.insert_extension(Arc::new(NativePreparationRuntime::new(control)));
        }
        if selection.is_some() {
            ctx.insert_extension(Arc::new(super::native::NativeManagedRequest));
            ctx.insert_extension(Arc::new(
                super::native_context::NativePrivateContextRuntime::new(
                    self.native_private_context.clone(),
                ),
            ));
        }
        self.observe_start(&ctx).await;

        let prepared = self.prepare_entry_stages(&mut ctx, selection).await;
        if let Some(runtime) = preparation_runtime(&ctx) {
            runtime.finish();
        }
        match prepared {
            Ok(chain) => {
                self.observe_after(Phase::Route, &ctx).await;
                log_request_received(&ctx, chain.first(), streamed);
                Ok(PreparedEntry { ctx, chain })
            }
            Err(failure) => {
                log_request_resolve_failed(&ctx, &failure.error);
                if failure.requires_settlement {
                    self.run_settlement(&mut ctx, false, Some(failure.error.clone()))
                        .await;
                    self.observe_after(Phase::Settlement, &ctx).await;
                }
                self.observe_end(&ctx, RequestOutcome::Failed(failure.error.clone()))
                    .await;
                Err(failure.error)
            }
        }
    }

    async fn prepare_entry_stages(
        &self,
        ctx: &mut PipelineContext,
        selection: Option<NativeModelSelection>,
    ) -> std::result::Result<Vec<RoutingTarget>, EntryPreparationFailure> {
        let fixed_selector =
            (selection == Some(NativeModelSelection::Fixed)).then(|| ctx.model().to_owned());
        let manual_effort = ctx
            .generation_prompt()
            .filter(|prompt| {
                selection.is_some()
                    && prompt.params.reasoning_effort_source == ReasoningEffortSource::Caller
            })
            .and_then(|prompt| prompt.params.reasoning_effort);
        // Local auth/session/continuation normalization must finish before any
        // configured checker can cause external egress.
        self.run_pre_resolution(ctx)
            .await
            .map_err(EntryPreparationFailure::pre_request)?;

        super::native_context::validate_managed_history(ctx)
            .map_err(EntryPreparationFailure::pre_request)?;

        // Freeze the ingress router identity and checker bindings before an
        // app hook can choose a different effective route.
        let mut binding = self
            .resolve_binding(ctx)
            .await
            .map_err(EntryPreparationFailure::route)?;
        self.validate_binding_operation(ctx, &binding)
            .map_err(EntryPreparationFailure::pre_request)?;
        self.run_router_preparation(ctx)
            .await
            .map_err(EntryPreparationFailure::pre_request)?;

        if binding.request_checks.is_empty() {
            // Compatibility path: before named-router request checks existed,
            // ordinary pre-request hooks could rewrite a bare/legacy selector
            // before its defaults were resolved. Preserve that behavior for
            // unguarded requests so only the final selector contributes
            // defaults, preferences, and policy.
            self.run_pre_request(ctx, None)
                .await
                .map_err(EntryPreparationFailure::pre_request)?;
            binding = self
                .resolve_effective_binding(ctx, binding)
                .await
                .map_err(EntryPreparationFailure::route)?;
        } else {
            // Checked routers resolve preparation rewrites and defaults before
            // local policy/guardrail hooks. The effective selector is then
            // immutable: changing it here would either mix two sets of
            // defaults or check content for a route that will not be served.
            binding = self
                .resolve_effective_binding(ctx, binding)
                .await
                .map_err(EntryPreparationFailure::route)?;
            let checked_selector = binding.resolved_selector.clone();
            self.run_pre_request(ctx, Some(&checked_selector))
                .await
                .map_err(EntryPreparationFailure::pre_request)?;
        }

        if fixed_selector
            .as_deref()
            .is_some_and(|model| model != ctx.model())
        {
            return Err(EntryPreparationFailure::route(BitrouterError::bad_request(
                "managed fixed model was changed during preparation",
            )));
        }
        if let Some(effort) = manual_effort {
            ctx.preserve_caller_effort(effort);
        }
        self.run_request_checks(ctx, &binding.request_checks, None)
            .await
            .map_err(EntryPreparationFailure::request_check)?;
        ctx.insert_extension(Arc::new(FrozenRequestChecks(
            binding.request_checks.clone(),
        )));
        self.observe_after(Phase::PreRequest, ctx).await;

        self.resolve_route(ctx, binding, selection, manual_effort)
            .await
            .map_err(EntryPreparationFailure::route)
    }

    async fn run_pre_resolution(&self, ctx: &mut PipelineContext) -> Result<()> {
        self.run_admitted_hooks(
            ctx,
            &self.pre_resolution_hooks,
            None,
            NativePreparationWorkKind::PreResolutionHook,
        )
        .await
    }

    async fn run_pre_request(
        &self,
        ctx: &mut PipelineContext,
        checked_selector: Option<&str>,
    ) -> Result<()> {
        self.run_admitted_hooks(
            ctx,
            &self.pre_request_hooks,
            checked_selector,
            NativePreparationWorkKind::PreRequestHook,
        )
        .await
    }

    async fn run_router_preparation(&self, ctx: &mut PipelineContext) -> Result<()> {
        self.run_admitted_hooks(
            ctx,
            &self.router_preparation_hooks,
            None,
            NativePreparationWorkKind::RouterPreparationHook,
        )
        .await
    }

    async fn run_admitted_hooks(
        &self,
        ctx: &mut PipelineContext,
        hooks: &[HookRegistration<dyn PreRequestHook>],
        checked_selector: Option<&str>,
        kind: NativePreparationWorkKind,
    ) -> Result<()> {
        let operation = ctx.operation();
        for hook in hooks.iter().filter(|hook| hook.supports(operation)) {
            observe_pipeline(
                preparation_runtime(ctx),
                ctx.request_id().into(),
                kind,
                async {
                    // Persist the complete verdict before acknowledging the
                    // callback. Otherwise a lost ACK can erase a known Deny.
                    match hook.check(ctx).await? {
                        HookDecision::Allow => {
                            if checked_selector.is_some_and(|selector| ctx.model() != selector) {
                                return Err(BitrouterError::internal(
                                    "a pre-request hook cannot change a checked router selector; register selector rewrites as router preparation hooks",
                                ));
                            }
                            Ok(())
                        }
                        HookDecision::Deny(reason) => Err(reason.into()),
                    }
                },
            )
            .await?;
        }
        Ok(())
    }

    async fn resolve_binding(&self, ctx: &mut PipelineContext) -> Result<ResolvedRequestBinding> {
        let resolved_selector = ctx.model().to_owned();
        let mut resolution = observe_pipeline(
            preparation_runtime(ctx),
            ctx.request_id().into(),
            NativePreparationWorkKind::RouterLookup,
            self.routing_table.resolve_model(ctx.model()),
        )
        .await?;
        if resolution.request_checks.len() > MAX_REQUEST_CHECKS_PER_ROUTER {
            return Err(BitrouterError::internal(
                "named router exceeds the maximum of 16 request checks",
            ));
        }
        if let Some(mut identity) = resolution.router.take() {
            // Preserve the documented exact ingress selector in public router
            // identity. `resolved_selector` separately retains the
            // post-session value used for this resolution.
            identity.original_selector = ctx.original_model().to_owned();
            ctx.set_router_identity(identity.clone());
            ctx.emit(identity);
        } else if !resolution.request_checks.is_empty() {
            return Err(BitrouterError::internal(
                "request checks require a named-router binding",
            ));
        }
        let request_checks = resolution.request_checks.clone();
        Ok(ResolvedRequestBinding {
            resolution,
            request_checks,
            resolved_selector,
        })
    }

    async fn resolve_effective_binding(
        &self,
        ctx: &mut PipelineContext,
        mut binding: ResolvedRequestBinding,
    ) -> Result<ResolvedRequestBinding> {
        if ctx.model() != binding.resolved_selector {
            let effective = observe_pipeline(
                preparation_runtime(ctx),
                ctx.request_id().into(),
                NativePreparationWorkKind::RouterLookup,
                self.routing_table.resolve_model(ctx.model()),
            )
            .await?;
            if binding.request_checks.is_empty() && !effective.request_checks.is_empty() {
                return Err(BitrouterError::internal(
                    "a selector rewrite cannot introduce request checks after the ingress binding is frozen",
                ));
            }
            binding.resolution = effective;
            binding.resolved_selector = ctx.model().to_owned();
        }
        self.validate_binding_operation(ctx, &binding)?;
        ctx.apply_preset_overrides(&binding.resolution.overrides)?;
        Ok(binding)
    }

    fn validate_binding_operation(
        &self,
        ctx: &PipelineContext,
        binding: &ResolvedRequestBinding,
    ) -> Result<()> {
        let operation = ctx.operation();
        if operation == ModelOperation::Decisions && !binding.resolution.overrides.is_empty() {
            return Err(BitrouterError::bad_request(
                "configured generation defaults do not support Decisions",
            ));
        }
        if operation == ModelOperation::Decisions
            && binding.resolution.policy.is_some()
            && !self
                .model_selectors
                .iter()
                .any(|hook| hook.supports(operation))
        {
            return Err(BitrouterError::bad_request(
                "configured model policy does not support Decisions",
            ));
        }
        for check in &binding.request_checks {
            if operation == ModelOperation::Decisions
                && !self
                    .request_checker_runner
                    .as_ref()
                    .is_some_and(|runner| runner.supports_operation(check, operation))
            {
                return Err(BitrouterError::bad_request(
                    "configured request checker does not support this model operation",
                ));
            }
        }
        Ok(())
    }

    async fn run_request_checks(
        &self,
        ctx: &mut PipelineContext,
        bindings: &[RequestCheckBinding],
        validation: Option<&dyn NativeExecutionControl>,
    ) -> Result<()> {
        super::native_context::validate_managed_history(ctx)?;
        if bindings.is_empty() {
            return Ok(());
        }
        for content in ctx
            .generation_prompt()
            .into_iter()
            .flat_map(|prompt| &prompt.messages)
            .flat_map(|message| &message.content)
        {
            bitrouter_ai::protocol::responses::validate_reasoning_projection(content)
                .map_err(BitrouterError::bad_request)?;
        }
        let runner = self.request_checker_runner.as_ref();
        ctx.router_identity().ok_or_else(|| {
            BitrouterError::internal("request checks lost their named-router binding")
        })?;
        let Some(runner) = runner else {
            return Err(BitrouterError::internal(
                "configured request checker is unavailable",
            ));
        };
        for binding in bindings {
            if let Some(control) = validation {
                control.check_context_validation(ctx.request_id()).await?;
            }
            let projection = match ctx.input() {
                PipelineInput::Generation(prompt) => {
                    content_fragments(prompt, binding.max_input_bytes)
                }
                PipelineInput::Decisions(request) => {
                    decision_content_fragments(request, binding.max_input_bytes)
                }
            };
            let (content, coverage) = projection.map_err(|_| BitrouterError::BadRequest {
                message: "request exceeds the configured checker input limit".to_string(),
            })?;
            observe_pipeline(
                preparation_runtime(ctx),
                ctx.request_id().into(),
                NativePreparationWorkKind::RequestCheck,
                async {
                    let result = runner
                        .check(
                            binding.clone(),
                            Input {
                                operation: ctx.operation(),
                                content,
                                coverage,
                            },
                        )
                        .await
                        .and_then(|result| {
                            result.decision.validate().map_err(|_| CheckerFailure {
                                kind: CheckerFailureKind::InvalidResponse,
                                detail: Some("invalid_decision".to_owned()),
                            })?;
                            Ok(result)
                        });
                    match result {
                        Ok(CheckerResult {
                            decision: Decision::Allow,
                            revision: _,
                        }) => {}
                        Ok(CheckerResult {
                            decision: Decision::Deny { reason_code: _ },
                            revision: _,
                        }) => {
                            return Err(BitrouterError::Forbidden(
                                "request denied by configured checker".to_string(),
                            ));
                        }
                        Err(_) => {
                            return Err(BitrouterError::internal(
                                "configured request checker failed closed",
                            ));
                        }
                    }
                    Ok(())
                },
            )
            .await?;
        }
        Ok(())
    }

    async fn prepare_required_finalizers(
        &self,
        ctx: &PipelineContext,
        streamed: bool,
    ) -> Result<RequiredFinalizationGuard> {
        let finalization = ctx.required_finalization_context(streamed);
        let mut guard = RequiredFinalizationGuard::new(
            applicable(&self.required_finalizers, ctx.operation()),
            finalization.clone(),
            self.pending_settlements.clone(),
        );
        if !finalization.successful_terminal {
            guard.disarm();
            return Ok(guard);
        }
        guard.receipt = self
            .prepare_required_finalizer_tracked(&finalization)
            .await?;
        Ok(guard)
    }

    async fn prepare_required_finalizer_tracked(
        &self,
        finalization: &RequiredFinalizationContext,
    ) -> Result<Option<RequiredFinalizationReceipt>> {
        let Some(finalizer) = self
            .required_finalizers
            .iter()
            .find(|hook| hook.supports(finalization.operation))
            .map(|hook| hook.hook.clone())
        else {
            return Ok(None);
        };
        let task_finalization = finalization.clone();
        let receipt = RequiredFinalizationReceipt::new();
        let task_receipt = receipt.clone();
        let (prepared_tx, prepared_rx) = tokio::sync::oneshot::channel();
        self.spawn_stream_finalization(async move {
            match finalizer
                .finalize_with_receipt(&task_finalization, &task_receipt)
                .await
            {
                Ok(()) => {
                    if prepared_tx.send(Ok(receipt)).is_err()
                        && let Err(error) = finalizer
                            .rollback_with_receipt(&task_finalization, &task_receipt)
                            .await
                    {
                        tracing::error!(error = %error, "RequiredFinalizer rollback failed");
                    }
                }
                Err(error) => {
                    if let Err(rollback_error) = finalizer
                        .rollback_with_receipt(&task_finalization, &task_receipt)
                        .await
                    {
                        tracing::error!(error = %rollback_error, "RequiredFinalizer rollback failed");
                    }
                    let _ = prepared_tx.send(Err(error));
                }
            }
        });
        let receipt = prepared_rx.await.map_err(|error| {
            BitrouterError::internal(format!(
                "required finalizer preparation ended unexpectedly: {error}"
            ))
        })??;
        Ok(Some(receipt))
    }

    async fn resolve_route(
        &self,
        ctx: &mut PipelineContext,
        binding: ResolvedRequestBinding,
        selection: Option<NativeModelSelection>,
        manual_effort: Option<bitrouter_ai::types::ReasoningEffort>,
    ) -> Result<Vec<RoutingTarget>> {
        // Binding/default resolution already ran before local and external
        // request checks. Effective model selection remains here so existing
        // pre-request ACLs continue to see the normalized named selector.
        if ctx.model() != binding.resolved_selector {
            return Err(BitrouterError::internal(
                "the effective selector changed after entry preparation",
            ));
        }
        let operation = ctx.operation();
        let resolution = binding.resolution;
        if selection != Some(NativeModelSelection::Fixed)
            && let Some(policy) = resolution.policy.as_deref()
        {
            for selector in self
                .model_selectors
                .iter()
                .filter(|hook| hook.supports(operation))
            {
                selector
                    .prepare_selection(policy, resolution.variant.as_deref(), ctx)
                    .await?;
            }
        }
        let native = preparation_runtime(ctx);
        if operation == ModelOperation::Generation {
            let prepared =
                if let Some(prepared) = ctx.extension::<crate::routing::preparation::Prepared>() {
                    Some(prepared.as_ref().clone())
                } else {
                    match native.as_ref() {
                        Some(native) => {
                            native
                                .control
                                .prepare_routing(ctx.require_generation_prompt()?)
                                .await?
                        }
                        None => None,
                    }
                };
            let prepared = match prepared {
                Some(prepared) => prepared,
                None => {
                    let prompt = ctx.require_generation_prompt()?;
                    let runtime = resolution.policy.as_ref().and(self.decision_model.as_ref());
                    match native.as_ref() {
                        Some(native) => {
                            crate::routing::preparation::Prepared::from_prompt_controlled(
                                prompt,
                                runtime,
                                ctx.request_id(),
                                native.control.as_ref(),
                            )
                            .await?
                        }
                        None => {
                            crate::routing::preparation::Prepared::from_prompt(
                                prompt,
                                runtime,
                                ctx.request_id(),
                            )
                            .await
                        }
                    }
                }
            };
            prepared.validate_for(ctx.require_generation_prompt()?)?;
            if let Some(receipt) = &prepared.receipt {
                ctx.emit(receipt.clone());
            }
            ctx.insert_extension(Arc::new(prepared));
        }
        ctx.set_model(resolution.clean_model);
        if selection != Some(NativeModelSelection::Fixed)
            && let Some(policy) = resolution.policy.as_deref()
        {
            let operation = ctx.operation();
            for selector in self
                .model_selectors
                .iter()
                .filter(|hook| hook.supports(operation))
            {
                observe_pipeline(
                    preparation_runtime(ctx),
                    ctx.request_id().into(),
                    NativePreparationWorkKind::ModelSelection,
                    selector.select_variant(policy, resolution.variant.as_deref(), ctx),
                )
                .await?;
            }
        }

        if let Some(effort) = manual_effort {
            ctx.preserve_caller_effort(effort);
        }

        // Supply actual prompt requirements to the shared routing table. The
        // configured catalog carries positive observations; omitted declarations
        // alone do not establish incompatibility or remove a provider.
        let mut prefs = resolution.prefs;
        prefs.require_capabilities = ctx
            .generation_prompt()
            .map(Prompt::required_capabilities)
            .unwrap_or_default();
        prefs.operation = ctx.operation();
        // Carry the inbound protocol so the table can prefer a native,
        // same-protocol upstream for each chosen target.
        prefs.inbound_protocol = ctx.inbound_protocol();
        let mut chain = observe_pipeline(
            preparation_runtime(ctx),
            ctx.request_id().into(),
            NativePreparationWorkKind::RouterLookup,
            self.routing_table
                .route_resolved(ctx.model(), &prefs, ctx.caller()),
        )
        .await?;
        let mut context_changed = false;
        let mut routing_prompt = None;
        if operation == ModelOperation::Generation {
            filter_reasoning_effort_targets(&mut chain, ctx.require_generation_prompt()?)?;
            // A native caller may leave the output budget to the selected model.
            // Resolve it before committing the exact prompt and before token counts.
            // Explicit caller/router limits retain their existing admission checks.
            let output_reservation = match (
                selection,
                ctx.require_generation_prompt()?.params.max_tokens,
            ) {
                (Some(_), None) => Some(
                    match chain
                        .first()
                        .and_then(|target| target.model_constraints.token_limits.max_output_tokens)
                    {
                        Some(limit) => u32::try_from(limit).map_err(|_| {
                            BitrouterError::bad_request(
                                "model output capacity exceeds supported reservation",
                            )
                        })?,
                        None => 4096,
                    },
                ),
                (_, requested) => requested,
            };

            let prepared = ctx
                .extension::<crate::routing::preparation::Prepared>()
                .ok_or_else(|| BitrouterError::internal("routing preparation vanished"))?;
            let mut views = prepared.views.clone();
            for view in &mut views {
                view.prompt.params.max_tokens = output_reservation;
                view.prompt.params.reasoning_effort =
                    ctx.require_generation_prompt()?.params.reasoning_effort;
                view.prompt.params.reasoning_effort_source = ctx
                    .require_generation_prompt()?
                    .params
                    .reasoning_effort_source;
            }
            let model = crate::routing::plan::AdmittedModel {
                model: crate::routing::plan::Model {
                    model: ctx.model().into(),
                    max_prompt_bytes: prepared.hard_limit_bytes,
                    input_microusd_per_million: None,
                    output_microusd_per_million: None,
                },
                admitted: true,
            };
            let plan = crate::routing::plan::select(
                &[model],
                ctx.model(),
                &views,
                crate::routing::plan::Options {
                    strategy: ctx
                        .extension::<crate::routing::ContextStrategy>()
                        .as_deref()
                        .copied()
                        .unwrap_or_default(),
                    policy: crate::routing::plan::CostPolicy {
                        minimum_savings_fraction: prepared.policy.minimum_savings_fraction,
                        model_switch_penalty_microusd: prepared
                            .policy
                            .model_switch_penalty_microusd,
                        prefix_loss_penalty_microusd_per_kib: prepared
                            .policy
                            .prefix_loss_penalty_microusd_per_kib,
                    },
                    previous: prepared.previous.as_ref(),
                    hard_limit_bytes: prepared.hard_limit_bytes,
                    capabilities: &prepared.capabilities,
                },
            )?;
            context_changed = plan.prompt.messages != ctx.require_generation_prompt()?.messages
                || plan.prompt.system != ctx.require_generation_prompt()?.system;
            if let Some(native) = &native {
                native.control.commit_routing(&plan).await?;
            }
            ctx.apply_routing_prompt(plan.prompt.clone())?;
            ctx.emit(plan.selection.clone());
            ctx.insert_extension(Arc::new(plan.selection));
            routing_prompt = Some(plan.prompt);
        }
        let fixed_routes = (selection == Some(NativeModelSelection::Fixed)).then(|| {
            chain
                .iter()
                .map(|target| (target.provider_name.clone(), target.service_id.clone()))
                .collect::<Vec<_>>()
        });
        let selected_model = ctx.model().to_owned();
        let operation = ctx.operation();
        for hook in self
            .route_hooks
            .iter()
            .filter(|hook| hook.supports(operation))
        {
            observe_pipeline(
                preparation_runtime(ctx),
                ctx.request_id().into(),
                NativePreparationWorkKind::RouteHook,
                hook.resolve(&mut chain, ctx),
            )
            .await?;
        }
        if selection.is_some()
            && ctx
                .extension::<crate::language_model::context::ProviderContinuation>()
                .is_some_and(|continuation| {
                    !continuation.admits_effort(
                        ctx.generation_prompt()
                            .and_then(|prompt| prompt.params.reasoning_effort),
                    )
                })
            && ctx
                .extension::<crate::language_model::context::SuppressProviderContinuation>()
                .is_none()
        {
            return Err(BitrouterError::bad_request(
                "managed effort differs from the authoritative provider continuation or its constraint is unknown",
            ));
        }
        if (selection == Some(NativeModelSelection::Fixed) && ctx.model() != selected_model)
            || fixed_routes.is_some_and(|routes| {
                chain.iter().any(|target| {
                    !routes.contains(&(target.provider_name.clone(), target.service_id.clone()))
                })
            })
            || manual_effort.is_some_and(|effort| {
                ctx.generation_prompt()
                    .and_then(|prompt| prompt.params.reasoning_effort)
                    != Some(effort)
            })
        {
            return Err(BitrouterError::bad_request(
                "a route hook changed a managed manual model or effort constraint",
            ));
        }
        if let Some(effort) = manual_effort {
            ctx.preserve_caller_effort(effort);
        }
        chain.retain(|target| target.api_protocol.operation() == ctx.operation());
        if let Some(prompt) = ctx.generation_prompt() {
            filter_reasoning_effort_targets(&mut chain, prompt)?;
        }
        if chain.is_empty() {
            if ctx.operation() == ModelOperation::Decisions {
                return Err(BitrouterError::bad_request(
                    "no compatible Decisions target for the selected model",
                ));
            }
            return Err(BitrouterError::NotFound(format!(
                "no route for model '{}'",
                ctx.model()
            )));
        }
        for hook in self
            .route_hooks
            .iter()
            .filter(|hook| hook.supports(operation))
        {
            hook.after_resolve(&chain, ctx).await?;
        }
        ctx.route_chain = Some(chain.clone());
        if context_changed {
            for hook in self
                .pre_resolution_hooks
                .iter()
                .chain(&self.router_preparation_hooks)
                .chain(&self.pre_request_hooks)
                .filter(|hook| hook.supports(operation))
            {
                match observe_pipeline(
                    preparation_runtime(ctx),
                    ctx.request_id().into(),
                    NativePreparationWorkKind::PreRequestHook,
                    hook.revalidate_context(ctx),
                )
                .await?
                {
                    HookDecision::Allow => {}
                    HookDecision::Deny(reason) => return Err(reason.into()),
                }
            }
            self.run_request_checks(ctx, &resolution.request_checks, None)
                .await?;
            for hook in self
                .route_hooks
                .iter()
                .filter(|hook| hook.supports(operation))
            {
                observe_pipeline(
                    preparation_runtime(ctx),
                    ctx.request_id().into(),
                    NativePreparationWorkKind::RouteHook,
                    hook.revalidate_context(&chain, ctx),
                )
                .await?;
            }
        }
        if let Some(prompt) = routing_prompt.as_ref()
            && (ctx.model() != prompt.model || ctx.generation_prompt() != Some(prompt))
        {
            return Err(BitrouterError::bad_request(
                "route hook changed the frozen routing prompt",
            ));
        }
        Ok(chain)
    }

    fn stream_pricing(
        &self,
        ctx: &PipelineContext,
        target: &RoutingTarget,
    ) -> Option<super::stream::UsagePricing> {
        let target_key = crate::language_model::stream::PricingTargetKey::from_target(target);
        let frozen = ctx
            .get_events::<crate::language_model::stream::UsagePricingSnapshot>()
            .into_iter()
            .rev()
            .find(|snapshot| snapshot.target == target_key);
        match frozen {
            Some(snapshot) => snapshot.pricing.clone(),
            None => self.routing_table.usage_pricing(ctx.model(), target),
        }
    }

    /// Keep native streaming state on the heap so ordinary batch callers do
    /// not inherit its async frame through nested model/judge futures.
    async fn execute_native_stream_attempt(
        &self,
        target: &RoutingTarget,
        prompt: &Prompt,
        ctx: &PipelineContext,
        control: &dyn NativeExecutionControl,
        started: Instant,
    ) -> (Result<ExecutionResult>, Option<BitrouterError>) {
        let mut stream_interruption = None;
        let mut stream_prompt = prompt.clone();
        stream_prompt.stream = true;
        let stream = tokio::select! {
            biased;
            _ = control.provider_cancelled() => Err(BitrouterError::internal(
                "managed provider execution cancelled by durable authority",
            )),
            stream = self.executor.execute_stream(target, &stream_prompt, ctx) => stream,
        };
        let outcome = match stream {
            Err(error) => Err(error),
            Ok(stream) => {
                let mut stream_context = ctx.stream_context();
                stream_context
                    .accumulated_usage
                    .set_pricing(self.stream_pricing(ctx, target));
                let processor = StreamProcessor::new(
                    self.stream_hooks.clone(),
                    applicable(&self.observe_hooks, ctx.operation()),
                    stream_context,
                );
                let (mut result, interruption) =
                    super::native_stream::collect(stream, processor, control, ctx.request_id())
                        .await;
                stream_interruption = interruption;
                if stream_interruption.is_none() {
                    let usage = result.usage.clone();
                    result = match self.executor.finish_native_stream(
                        target,
                        &stream_prompt,
                        ctx,
                        result,
                    ) {
                        Ok(result) => result,
                        Err(error) => {
                            stream_interruption = Some(error);
                            let mut result = super::native_output::empty_result();
                            result.usage = usage;
                            result.finish_reason = Some(bitrouter_ai::types::FinishReason::Error(
                                "native terminal rejected".into(),
                            ));
                            result
                        }
                    };
                }
                Ok(ExecutionResult {
                    provider_id: target.provider_name.clone(),
                    model_id: target.service_id.clone(),
                    account_label: target.account_label.clone(),
                    result: PipelineOutput::Generation(result),
                    request_duration_ms: super::timing::duration_millis(started.elapsed()),
                    upstream_duration_ms: Some(super::timing::duration_millis(started.elapsed())),
                    server_tool_calls: Vec::new(),
                })
            }
        };
        (outcome, stream_interruption)
    }

    async fn execute_with_fallback(
        &self,
        chain: &[RoutingTarget],
        input: ExecutionInput<'_>,
        ctx: &PipelineContext,
    ) -> Result<ExecutionResult> {
        let mut errors = Vec::new();
        let mut excluded = bitrouter_ai::conversion::ConversionReport::default();
        for target in chain {
            if target.api_protocol.operation() != ctx.operation() {
                continue;
            }
            match input {
                ExecutionInput::Generation(prompt) => {
                    if !self
                        .admit_candidate(target, prompt, false, ctx, &mut excluded)
                        .await?
                    {
                        continue;
                    }
                }
                ExecutionInput::Decisions(request) => {
                    self.executor.preflight_decisions(target, request)?;
                }
            }
            self.wait_before_fallback(errors.len()).await;
            self.observe_hop_start(ctx, target).await;
            let outcome = match input {
                ExecutionInput::Generation(prompt) => {
                    self.executor.execute(target, prompt, ctx).await
                }
                ExecutionInput::Decisions(request) => {
                    self.executor.execute_decisions(target, request, ctx).await
                }
            }
            .and_then(|result| {
                let matches = match input {
                    ExecutionInput::Generation(_) => result.result.generation().is_some(),
                    ExecutionInput::Decisions(_) => result.result.decisions().is_some(),
                };
                if !matches {
                    if ctx.operation() == ModelOperation::Decisions {
                        // Usage from a generation result is not native wire
                        // evidence and cannot be charged as Decisions usage.
                        ctx.record_decision_failure_usage(None);
                    }
                    return Err(BitrouterError::UpstreamInvalidResponse {
                        message: "executor result operation mismatch".into(),
                        usage: None,
                    });
                }
                if let (ExecutionInput::Decisions(request), Some(native)) =
                    (&input, result.result.decisions())
                {
                    // Custom executors must satisfy the same native contract as
                    // HTTP executors before any success hook or settlement runs.
                    bitrouter_ai::protocol::decisions::DecisionsCodec::render_response(
                        native, request,
                    )
                    .map_err(|error| {
                        ctx.record_decision_failure_usage(error.decision_usage().cloned());
                        BitrouterError::from(error)
                    })?;
                }
                Ok(result)
            });
            match &outcome {
                Ok(result) => {
                    self.observe_hop_end(ctx, target, HopOutcome::Generated(result))
                        .await;
                }
                Err(e) => {
                    self.observe_hop_end(ctx, target, HopOutcome::Failed(e))
                        .await;
                }
            }
            match outcome {
                Ok(result) => {
                    for hook in self
                        .execution_hooks
                        .iter()
                        .filter(|hook| hook.supports(ctx.operation()))
                    {
                        hook.on_success(ctx, &result).await?;
                    }
                    ctx.set_successful_target(target.clone());
                    return Ok(result);
                }
                Err(e) => match self.classify_failure(ctx, &e, target).await {
                    FallbackDecision::TryNext => {
                        tracing::warn!(
                            provider = %target.provider_name,
                            model = %target.service_id,
                            error = %e,
                            "upstream route candidate failed"
                        );
                        errors.push(e);
                        continue;
                    }
                    FallbackDecision::Fail(e) => return Err(e),
                },
            }
        }
        if errors.is_empty() && !excluded.issues.is_empty() {
            return Err(BitrouterError::Incompatible { report: excluded });
        }
        Err(aggregate_fallback_errors(errors))
    }

    async fn execute_with_fallback_controlled(
        &self,
        chain: &[RoutingTarget],
        prompt: &Prompt,
        ctx: &PipelineContext,
        control: Option<(
            &dyn NativeExecutionControl,
            &[NativeRoute],
            &crate::language_model::native::NativePlanAdmission,
        )>,
    ) -> Result<ControlledExecution> {
        let mut errors = Vec::new();
        let mut excluded = bitrouter_ai::conversion::ConversionReport::default();
        let mut dispatched = 0;
        for (attempt_index, target) in chain.iter().enumerate() {
            let index = u32::try_from(attempt_index)
                .map_err(|_| BitrouterError::internal("provider attempt index exhausted"))?;
            if control.is_some_and(|(_, _, admission)| !admission.route_indices.contains(&index)) {
                continue;
            }
            if !self
                .admit_candidate(target, prompt, false, ctx, &mut excluded)
                .await?
            {
                continue;
            }
            let attempt_control = match control {
                Some((control, routes, _)) => Some((
                    control,
                    routes.get(attempt_index).ok_or_else(|| {
                        BitrouterError::internal("managed route snapshot missing")
                    })?,
                )),
                None => None,
            };
            if let Some((_, route)) = attempt_control
                && let Some(counted) =
                    ctx.extension::<crate::language_model::native::NativeCountedRequests>()
            {
                counted.select(route.input_count.as_ref())?;
            }
            let report_limit = match attempt_control {
                Some((control, route)) => {
                    let limit = control.attempt_report_byte_limit(ctx.request_id(), route)?;
                    if let Some(limit) = limit
                        && limit
                            < NativeAttemptReport::rejection_byte_reserve(ctx.request_id(), route)?
                    {
                        return Err(BitrouterError::bad_request(
                            "attempt report limit cannot hold rejection evidence",
                        ));
                    }
                    limit
                }
                None => None,
            };
            self.wait_before_fallback(dispatched).await;
            dispatched += 1;
            self.observe_hop_start(ctx, target).await;
            if let Some((control, route)) = attempt_control {
                let reservation = self.native_cost_estimator.as_ref().and_then(|estimator| {
                    estimator.reservation_for_attempt(route, prompt, ctx, target)
                });
                let admitted = tokio::select! {
                    biased;
                    () = control.provider_cancelled() => Err(BitrouterError::internal(
                        "managed attempt admission cancelled before provider dispatch")),
                    result = control.before_attempt_with_token_reservation(
                        ctx.request_id(), index, reservation.as_ref()) => result,
                };
                if let Err(error) = admitted {
                    control.admission_aborted(ctx.request_id(), index).await;
                    self.observe_hop_end(ctx, target, HopOutcome::Failed(&error))
                        .await;
                    return Err(error);
                }
            }
            let private_context =
                ctx.extension::<super::native_context::NativePrivateContextRuntime>();
            let work = ctx.extension::<super::native_work::NativeWorkRuntime>();
            if let Some(runtime) = &work {
                runtime.begin_attempt(index)?;
            }
            if let Some(runtime) = &private_context {
                runtime.begin_attempt();
            }
            let started = Instant::now();
            let mut stream_interruption = None;
            let mut outcome = match attempt_control {
                Some((control, _)) if control.observe_stream() => {
                    let (outcome, interruption) = Box::pin(
                        self.execute_native_stream_attempt(target, prompt, ctx, control, started),
                    )
                    .await;
                    stream_interruption = interruption;
                    outcome
                }
                Some((control, _)) => tokio::select! {
                    // A prior cancellation must not poll a new executor future.
                    // Accepted work may still have unknown provider-side usage.
                    biased;
                    _ = control.provider_cancelled() => Err(BitrouterError::internal(
                        "managed provider execution cancelled by durable authority",
                    )),
                    outcome = self.executor.execute(target, prompt, ctx) => outcome,
                },
                None => self.executor.execute(target, prompt, ctx).await,
            };
            outcome = outcome.and_then(|result| {
                if result.result.generation().is_none() {
                    return Err(BitrouterError::UpstreamInvalidResponse {
                        message: "executor result operation mismatch".into(),
                        usage: None,
                    });
                }
                Ok(result)
            });
            let output_limit =
                attempt_control.and_then(|(control, _)| control.canonical_output_byte_limit());
            // Count without allocating an encoded copy, before private-output
            // sealing or durable-report cloning. Check again after sealing,
            // since trusted policy metadata may grow the canonical result.
            let mut output_rejected = output_limit.is_some_and(|limit| {
                outcome.as_ref().is_ok_and(|result| {
                    result
                        .result
                        .generation()
                        .is_none_or(|result| !super::native_output::fits(result, limit))
                })
            });
            if !output_rejected
                && stream_interruption.is_none()
                && let (Some(runtime), Ok(result)) = (&private_context, &mut outcome)
                && let Some(generation) = result.result.generation_mut()
            {
                runtime.seal_output(ctx, target, generation);
            }
            output_rejected |= output_limit.is_some_and(|limit| {
                outcome.as_ref().is_ok_and(|result| {
                    result
                        .result
                        .generation()
                        .is_none_or(|result| !super::native_output::fits(result, limit))
                })
            });
            if let Some(runtime) = &work {
                runtime.flush().await;
            }
            let mut report_rejected = false;
            if let Some((control, route)) = attempt_control {
                let mut report = NativeAttemptReport {
                    request_id: ctx.request_id().to_owned(),
                    attempt_index: index,
                    route: route.clone(),
                    actual_provider: outcome
                        .as_ref()
                        .ok()
                        .map(|result| result.provider_id.clone()),
                    actual_model: outcome.as_ref().ok().map(|result| result.model_id.clone()),
                    // Move the original through the estimator. Only admitted
                    // output is cloned for the durable callback below.
                    result: outcome
                        .as_mut()
                        .ok()
                        .and_then(|result| result.result.generation_mut())
                        .map(|result| {
                            std::mem::replace(result, super::native_output::empty_result())
                        }),
                    output_rejection: None,
                    report_rejection: None,
                    error: stream_interruption
                        .as_ref()
                        .or_else(|| outcome.as_ref().err())
                        .map(ToString::to_string),
                    elapsed_ms: super::timing::duration_millis(
                        work.as_ref()
                            .map(|runtime| runtime.work_duration(started.elapsed()))
                            .unwrap_or_else(|| started.elapsed()),
                    ),
                    token_cost: Default::default(),
                    private_context: private_context
                        .as_ref()
                        .map(|runtime| runtime.observation())
                        .unwrap_or_default(),
                    continuation: private_context
                        .as_ref()
                        .map(|runtime| runtime.continuation_observation())
                        .unwrap_or_default(),
                    cache: Default::default(),
                };
                report.cache = super::native_accounting::NativeCacheObservation::capture(
                    &route.protocol,
                    report
                        .result
                        .as_ref()
                        .and_then(|result| result.usage.as_ref()),
                );
                if let Some(estimator) = &self.native_cost_estimator {
                    report.token_cost = estimator.estimate_for_attempt(&report, ctx, target);
                }
                if let Some(result) = report.result.take() {
                    if output_rejected && let Some(limit) = output_limit {
                        report.output_rejection =
                            Some(super::native_output::rejection(&result, limit));
                        report.error =
                            Some("canonical model output exceeds its admitted byte limit".into());
                    } else {
                        report.result = Some(result.clone());
                    }
                    if let Ok(execution) = &mut outcome {
                        execution.result = result.into();
                    }
                }
                if let Some(limit) = report_limit {
                    match super::native_report::admit(&mut report, limit) {
                        Ok(rejected) => report_rejected = rejected,
                        Err(error) => {
                            // Even an internal projection failure cannot discard
                            // a successful executor's original billing evidence.
                            return match outcome {
                                Ok(result) => Ok(ControlledExecution {
                                    result,
                                    output_rejection: Some(error),
                                }),
                                Err(_) => Err(error),
                            };
                        }
                    }
                }
                control.after_attempt(report).await;
            }
            match &outcome {
                Ok(result) => {
                    self.observe_hop_end(ctx, target, HopOutcome::Generated(result))
                        .await;
                }
                Err(e) => {
                    self.observe_hop_end(ctx, target, HopOutcome::Failed(e))
                        .await;
                }
            }
            match outcome {
                Ok(result) => {
                    if let Some(error) = stream_interruption {
                        ctx.set_successful_target(target.clone());
                        return Ok(ControlledExecution {
                            result,
                            output_rejection: Some(error),
                        });
                    }
                    if output_rejected || report_rejected {
                        // Do not let a fallible success hook discard the
                        // original billed result before rejection settlement.
                        ctx.set_successful_target(target.clone());
                        return Ok(ControlledExecution {
                            result,
                            output_rejection: Some(BitrouterError::UpstreamInvalidResponse {
                                usage: None,
                                message: if report_rejected {
                                    "attempt report metadata rejected by durable admission"
                                } else {
                                    "canonical model output exceeds its admitted byte limit"
                                }
                                .into(),
                            }),
                        });
                    }
                    for hook in self
                        .execution_hooks
                        .iter()
                        .filter(|hook| hook.supports(ctx.operation()))
                    {
                        hook.on_success(ctx, &result).await?;
                    }
                    ctx.set_successful_target(target.clone());
                    return Ok(ControlledExecution {
                        result,
                        output_rejection: None,
                    });
                }
                Err(_) if report_rejected => {
                    return Err(BitrouterError::UpstreamInvalidResponse {
                        usage: None,
                        message: "attempt report metadata rejected by durable admission".into(),
                    });
                }
                Err(e) => match self.classify_failure(ctx, &e, target).await {
                    FallbackDecision::TryNext => {
                        tracing::warn!(
                            provider = %target.provider_name,
                            model = %target.service_id,
                            error = %e,
                            "upstream route candidate failed"
                        );
                        errors.push(e);
                        continue;
                    }
                    FallbackDecision::Fail(e) => return Err(e),
                },
            }
        }
        if errors.is_empty() && !excluded.issues.is_empty() {
            return Err(BitrouterError::Incompatible { report: excluded });
        }
        Err(aggregate_fallback_errors(errors))
    }

    async fn execute_stream_with_fallback(
        &self,
        chain: &[RoutingTarget],
        ctx: &PipelineContext,
    ) -> Result<StreamingExecution> {
        let mut errors = Vec::new();
        let mut excluded = bitrouter_ai::conversion::ConversionReport::default();
        for target in chain {
            if !self
                .admit_candidate(
                    target,
                    ctx.require_generation_prompt()?,
                    true,
                    ctx,
                    &mut excluded,
                )
                .await?
            {
                continue;
            }
            self.wait_before_fallback(errors.len()).await;
            let provider_started_at = Instant::now();
            self.observe_hop_start(ctx, target).await;
            let outcome = self
                .executor
                .execute_stream(target, ctx.require_generation_prompt()?, ctx)
                .await;
            match &outcome {
                Ok(_) => {
                    self.observe_hop_end(ctx, target, HopOutcome::StreamStarted)
                        .await;
                }
                Err(e) => {
                    self.observe_hop_end(ctx, target, HopOutcome::Failed(e))
                        .await;
                }
            }
            match outcome {
                // Once the stream starts, the SSE response is committed — no
                // more fallback.
                Ok(stream) => {
                    ctx.set_successful_target(target.clone());
                    let stream = Box::pin(ObservedUpstreamStream {
                        inner: stream,
                        hooks: applicable(&self.observe_hooks, ModelOperation::Generation),
                        request_id: ctx.request_id().to_string(),
                        target: target.clone(),
                        provider_started_at,
                        terminal: false,
                    });
                    return Ok(StreamingExecution {
                        stream,
                        target: target.clone(),
                        provider_started_at,
                    });
                }
                Err(e) => match self.classify_failure(ctx, &e, target).await {
                    FallbackDecision::TryNext => {
                        tracing::warn!(
                            provider = %target.provider_name,
                            model = %target.service_id,
                            error = %e,
                            "upstream streaming route candidate failed"
                        );
                        errors.push(e);
                        continue;
                    }
                    FallbackDecision::Fail(e) => return Err(e),
                },
            }
        }
        if errors.is_empty() && !excluded.issues.is_empty() {
            return Err(BitrouterError::Incompatible { report: excluded });
        }
        Err(aggregate_fallback_errors(errors))
    }

    /// Share the executor's conversion contract without invoking failure policy
    /// or hop observers for a candidate that cannot represent this source.
    async fn admit_candidate(
        &self,
        target: &RoutingTarget,
        prompt: &Prompt,
        stream: bool,
        ctx: &PipelineContext,
        excluded: &mut bitrouter_ai::conversion::ConversionReport,
    ) -> Result<bool> {
        let assessment = if ctx
            .extension::<super::native::NativeManagedRequest>()
            .is_some()
        {
            self.executor.preflight_managed(target, prompt, stream, ctx)
        } else {
            self.executor.preflight(target, prompt, stream)
        }
        .and_then(|report| {
            report.require_admitted()?;
            Ok(report)
        });
        match assessment {
            Ok(report) => {
                if !report.admitted.is_empty() {
                    for hook in self
                        .observe_hooks
                        .iter()
                        .filter(|hook| hook.supports(ctx.operation()))
                    {
                        let fut = std::panic::AssertUnwindSafe(
                            hook.on_conversion_admitted(ctx, target, &report),
                        );
                        if fut.catch_unwind().await.is_err() {
                            tracing::warn!(
                                "ObserveHook::on_conversion_admitted panicked; swallowed"
                            );
                        }
                    }
                }
                Ok(true)
            }
            Err(BitrouterError::Incompatible { report }) if !report.is_output_failure() => {
                for hook in self
                    .observe_hooks
                    .iter()
                    .filter(|hook| hook.supports(ctx.operation()))
                {
                    let fut = std::panic::AssertUnwindSafe(
                        hook.on_conversion_excluded(ctx, target, &report),
                    );
                    if fut.catch_unwind().await.is_err() {
                        tracing::warn!("ObserveHook::on_conversion_excluded panicked; swallowed");
                    }
                }
                excluded.issues.extend(report.issues);
                excluded.admitted.extend(report.admitted);
                Ok(false)
            }
            Err(error) => Err(error),
        }
    }

    async fn wait_before_fallback(&self, attempt_index: usize) {
        if attempt_index == 0 || self.fallback_backoff.is_empty() {
            return;
        }
        let schedule_index = (attempt_index - 1).min(self.fallback_backoff.len() - 1);
        let delay = self.fallback_backoff[schedule_index];
        if delay.is_zero() {
            return;
        }
        tracing::debug!(
            attempt = attempt_index + 1,
            delay_ms = delay.as_millis(),
            "waiting before retryable fallback candidate"
        );
        tokio::time::sleep(delay).await;
    }

    /// Decide fallback after an upstream failure. Any registered execution hook
    /// voting `Fail` short-circuits to Fail; otherwise the `FallbackPolicy`
    /// decides. A previous version of this method consulted the
    /// FallbackPolicy *only* when `execution_hooks` was empty, which silently
    /// disabled `FallbackPolicy::Fail` on 4xx upstream errors as soon as any
    /// hook (even an observe-only one) was registered.
    async fn classify_failure(
        &self,
        ctx: &PipelineContext,
        err: &BitrouterError,
        target: &RoutingTarget,
    ) -> FallbackDecision {
        if ctx.has_completed_decision_failure()
            || (ctx.operation() == ModelOperation::Decisions
                && matches!(err, BitrouterError::UpstreamInvalidResponse { .. }))
        {
            return FallbackDecision::Fail(err.clone());
        }
        for hook in self
            .execution_hooks
            .iter()
            .filter(|hook| hook.supports(ctx.operation()))
        {
            if let FallbackDecision::Fail(e) = hook.on_failure(ctx, err).await {
                return FallbackDecision::Fail(e);
            }
        }
        self.fallback_policy.classify(err, target)
    }

    /// Stage 4 — Settlement. Every `SettlementRecorder` runs in registration
    /// order against the immutable [`SettlementContext`]. Deployments that
    /// need exclusive-charging semantics implement them inside a single
    /// recorder (the SDK no longer enforces a charge chain).
    async fn run_settlement(
        &self,
        ctx: &mut PipelineContext,
        streamed: bool,
        error: Option<BitrouterError>,
    ) {
        ctx.finalize_request_duration();
        let mut settle = ctx.settlement_context();
        settle.streamed = streamed;
        if let Some(BitrouterError::UpstreamInvalidResponse {
            usage: Some(usage), ..
        }) = &error
        {
            settle.prompt_tokens = usage.prompt_tokens;
            settle.completion_tokens = usage.completion_tokens;
            settle.reasoning_tokens = usage.reasoning_tokens;
            settle.cache_read_tokens = usage.cache_read_tokens;
            settle.cache_write_tokens = usage.cache_write_tokens;
            settle.web_search_count = usage.web_search_count;
            settle.usage_origin = usage.origin;
            settle.raw_usage = usage.raw.as_deref().cloned();
        }
        settle.error = error;

        // Emit the canonical "request finished" line before recorders
        // run. The two-line model (received + finished) is inherited from
        // v0's operator-facing log shape and kept for log-scraper
        // compatibility.
        log_request_finished(&settle);

        for recorder in self
            .settlement_recorders
            .iter()
            .filter(|hook| hook.supports(ctx.operation()))
        {
            if let Err(e) = recorder.record(&mut settle).await {
                tracing::error!(error = %e, "SettlementRecorder failed");
            }
        }

        ctx.absorb_settlement(settle);
    }

    // ===== observe helpers (read-only, swallow errors AND panics) =====

    async fn observe_start(&self, ctx: &PipelineContext) {
        for hook in self
            .observe_hooks
            .iter()
            .filter(|hook| hook.supports(ctx.operation()))
        {
            let fut = std::panic::AssertUnwindSafe(hook.on_request_start(ctx));
            if fut.catch_unwind().await.is_err() {
                tracing::warn!("ObserveHook::on_request_start panicked; swallowed");
            }
        }
    }

    async fn observe_after(&self, phase: Phase, ctx: &PipelineContext) {
        for hook in self
            .observe_hooks
            .iter()
            .filter(|hook| hook.supports(ctx.operation()))
        {
            let fut = std::panic::AssertUnwindSafe(hook.after_phase(phase, ctx));
            if fut.catch_unwind().await.is_err() {
                tracing::warn!(?phase, "ObserveHook::after_phase panicked; swallowed");
            }
        }
    }

    async fn observe_hop_start(&self, ctx: &PipelineContext, target: &RoutingTarget) {
        ctx.set_last_attempted_target(target.clone());
        observe_hop_start_with(&self.observe_hooks, ctx, target).await;
    }

    async fn observe_hop_end(
        &self,
        ctx: &PipelineContext,
        target: &RoutingTarget,
        outcome: HopOutcome<'_>,
    ) {
        observe_hop_end_with(&self.observe_hooks, ctx, target, outcome).await;
    }

    async fn observe_end(&self, ctx: &PipelineContext, outcome: RequestOutcome) {
        for hook in self
            .observe_hooks
            .iter()
            .filter(|hook| hook.supports(ctx.operation()))
        {
            let fut = std::panic::AssertUnwindSafe(hook.on_request_end(ctx, &outcome));
            if fut.catch_unwind().await.is_err() {
                tracing::warn!("ObserveHook::on_request_end panicked; swallowed");
            }
        }
    }
}

fn filter_reasoning_effort_targets(chain: &mut Vec<RoutingTarget>, prompt: &Prompt) -> Result<()> {
    let Some(effort) = prompt.params.reasoning_effort else {
        return Ok(());
    };
    let policy_owned = prompt.params.reasoning_effort_source == ReasoningEffortSource::Policy;
    chain.retain(|target| match &target.reasoning_effort {
        Some(support) => support.levels.contains(&effort),
        None => !policy_owned,
    });
    if chain.is_empty() {
        return Err(BitrouterError::bad_request(format!(
            "reasoning effort '{effort}' has no supported provider/model route"
        )));
    }
    Ok(())
}

async fn observe_hop_start_with(
    hooks: &[HookRegistration<dyn ObserveHook>],
    ctx: &PipelineContext,
    target: &RoutingTarget,
) {
    for hook in hooks.iter().filter(|hook| hook.supports(ctx.operation())) {
        let fut = std::panic::AssertUnwindSafe(hook.on_hop_start(ctx, target));
        if fut.catch_unwind().await.is_err() {
            tracing::warn!("ObserveHook::on_hop_start panicked; swallowed");
        }
    }
}

async fn observe_hop_end_with(
    hooks: &[HookRegistration<dyn ObserveHook>],
    ctx: &PipelineContext,
    target: &RoutingTarget,
    outcome: HopOutcome<'_>,
) {
    for hook in hooks.iter().filter(|hook| hook.supports(ctx.operation())) {
        let fut = std::panic::AssertUnwindSafe(hook.on_hop_end(ctx, target, outcome));
        if fut.catch_unwind().await.is_err() {
            tracing::warn!("ObserveHook::on_hop_end panicked; swallowed");
        }
    }
}

/// Produce a deterministic terminal error from a fully exhausted fallback
/// chain. The result describes the route set rather than whichever provider
/// happened to sort last.
fn aggregate_fallback_errors(errors: Vec<BitrouterError>) -> BitrouterError {
    if errors.is_empty() {
        return BitrouterError::NotFound("empty routing chain".to_string());
    }

    if errors.iter().all(|error| {
        matches!(
            error,
            BitrouterError::UpstreamRateLimited { .. }
                | BitrouterError::Upstream { status: 429, .. }
        )
    }) {
        let retry_after = errors
            .iter()
            .filter_map(|error| match error {
                BitrouterError::UpstreamRateLimited { retry_after, .. } => *retry_after,
                _ => None,
            })
            .min();
        let detail = errors
            .iter()
            .find_map(BitrouterError::upstream_detail)
            .map(str::to_owned);
        return BitrouterError::UpstreamRateLimited {
            retry_after,
            detail,
        };
    }

    if errors
        .iter()
        .all(|error| matches!(error, BitrouterError::UpstreamTimeout))
    {
        return BitrouterError::UpstreamTimeout;
    }

    if errors
        .iter()
        .all(|error| matches!(error, BitrouterError::UpstreamPaymentRequired { .. }))
    {
        let detail = errors
            .iter()
            .find_map(BitrouterError::upstream_detail)
            .map(str::to_owned);
        return BitrouterError::UpstreamPaymentRequired { detail };
    }

    if errors.iter().all(|error| {
        matches!(
            error,
            BitrouterError::UpstreamBadRequest { .. }
                | BitrouterError::UpstreamPolicyViolation { .. }
        )
    }) && let Some(error) = errors.last()
    {
        return error.clone();
    }
    if errors
        .iter()
        .all(|error| matches!(error, BitrouterError::UpstreamInvalidResponse { .. }))
        && let Some(error) = errors.first()
    {
        return error.clone();
    }

    let is_availability_failure = |error: &BitrouterError| {
        matches!(
            error,
            BitrouterError::UpstreamRateLimited { .. }
                | BitrouterError::UpstreamTimeout
                | BitrouterError::UpstreamUnavailable
                | BitrouterError::Upstream { status: 408, .. }
                | BitrouterError::Upstream {
                    status: 500..=599,
                    ..
                }
        )
    };
    if errors.iter().all(is_availability_failure) {
        return BitrouterError::UpstreamUnavailable;
    }

    let is_provider_failure = |error: &BitrouterError| {
        matches!(
            error,
            BitrouterError::UpstreamPaymentRequired { .. }
                | BitrouterError::UpstreamRateLimited { .. }
                | BitrouterError::Upstream { .. }
                | BitrouterError::UpstreamAuth { .. }
                | BitrouterError::UpstreamTimeout
                | BitrouterError::UpstreamUnavailable
        )
    };
    if errors.iter().all(is_provider_failure) {
        return BitrouterError::UpstreamUnavailable;
    }

    errors
        .into_iter()
        .last()
        .unwrap_or_else(|| BitrouterError::NotFound("empty routing chain".to_string()))
}

#[cfg(test)]
mod policy_effort_target_tests {
    use super::filter_reasoning_effort_targets;
    use crate::language_model::types::RoutingTarget;
    use bitrouter_ai::types::{
        ApiProtocol, GenerationParams, Prompt, ReasoningEffort, ReasoningEffortConfig,
        ReasoningEffortSource,
    };

    fn prompt() -> Prompt {
        Prompt {
            model: "model".to_string(),
            system: None,
            system_provider_metadata: Default::default(),
            messages: Vec::new(),
            tools: Vec::new(),
            params: GenerationParams::default(),
            response_format: None,
            tool_choice: None,
            stream: false,
        }
    }

    fn target(name: &str, levels: Option<Vec<ReasoningEffort>>) -> RoutingTarget {
        RoutingTarget {
            provider_name: name.to_string(),
            service_id: "model".to_string(),
            api_base: "https://example.test/v1".to_string(),
            api_key: "test".to_string(),
            api_protocol: ApiProtocol::Responses,
            chat_token_limit_field: None,
            chat_supports_store: None,
            chat_supports_stream_options: None,
            chat_google_extensions: false,
            reasoning_effort: levels.map(|levels| ReasoningEffortConfig {
                levels,
                default: None,
            }),
            model_constraints: Default::default(),
            account_label: None,
            api_key_override: None,
            api_base_override: None,
            auth_scheme: Default::default(),
            headers: Vec::new(),
        }
    }

    #[test]
    fn policy_effort_keeps_only_exact_positive_support() -> crate::Result<()> {
        let mut prompt = prompt();
        prompt.params.reasoning_effort = Some(ReasoningEffort::High);
        prompt.params.reasoning_effort_source = ReasoningEffortSource::Policy;
        let mut chain = vec![
            target("supported", Some(vec![ReasoningEffort::High])),
            target("wrong-level", Some(vec![ReasoningEffort::Low])),
            target("unknown", None),
        ];

        filter_reasoning_effort_targets(&mut chain, &prompt)?;
        assert_eq!(chain.len(), 1);
        assert_eq!(chain[0].provider_name, "supported");
        Ok(())
    }

    #[test]
    fn caller_effort_preserves_unknown_target_passthrough() -> crate::Result<()> {
        let mut prompt = prompt();
        prompt.params.reasoning_effort = Some(ReasoningEffort::High);
        let mut chain = vec![target("unknown", None)];

        filter_reasoning_effort_targets(&mut chain, &prompt)?;
        assert_eq!(chain.len(), 1);
        Ok(())
    }

    #[test]
    fn caller_effort_drops_routes_with_known_incompatible_ladders() -> crate::Result<()> {
        let mut prompt = prompt();
        prompt.params.reasoning_effort = Some(ReasoningEffort::Minimal);
        let mut chain = vec![
            target("anthropic", Some(vec![ReasoningEffort::Low])),
            target("gemini", Some(vec![ReasoningEffort::Minimal])),
            target("custom-unknown", None),
        ];

        filter_reasoning_effort_targets(&mut chain, &prompt)?;
        assert_eq!(chain.len(), 2);
        assert_eq!(chain[0].provider_name, "gemini");
        assert_eq!(chain[1].provider_name, "custom-unknown");
        Ok(())
    }

    #[test]
    fn unsupported_policy_effort_fails_closed() -> crate::Result<()> {
        let mut prompt = prompt();
        prompt.params.reasoning_effort = Some(ReasoningEffort::Max);
        prompt.params.reasoning_effort_source = ReasoningEffortSource::Policy;
        let mut chain = vec![target("unsupported", Some(vec![ReasoningEffort::High]))];

        let error = filter_reasoning_effort_targets(&mut chain, &prompt)
            .err()
            .ok_or_else(|| crate::BitrouterError::internal("unsupported effort was accepted"))?;
        assert!(error.to_string().contains("reasoning effort 'max'"));
        Ok(())
    }
}

#[cfg(test)]
mod fallback_error_tests {
    use super::aggregate_fallback_errors;
    use crate::error::BitrouterError;

    #[test]
    fn mixed_provider_failures_aggregate_to_unavailable() {
        let error = aggregate_fallback_errors(vec![
            BitrouterError::UpstreamPaymentRequired {
                detail: Some("insufficient balance".to_owned()),
            },
            BitrouterError::UpstreamRateLimited {
                retry_after: Some(30),
                detail: Some("quota exceeded".to_owned()),
            },
            BitrouterError::Upstream {
                status: 503,
                message: "service unavailable".to_owned(),
            },
        ]);

        assert!(matches!(error, BitrouterError::UpstreamUnavailable));
    }

    #[test]
    fn homogeneous_rate_limits_keep_retry_and_diagnostic() {
        let error = aggregate_fallback_errors(vec![
            BitrouterError::UpstreamRateLimited {
                retry_after: Some(60),
                detail: Some("requests exhausted".to_owned()),
            },
            BitrouterError::UpstreamRateLimited {
                retry_after: Some(15),
                detail: None,
            },
        ]);

        assert!(matches!(
            error,
            BitrouterError::UpstreamRateLimited {
                retry_after: Some(15),
                detail: Some(ref detail),
            } if detail == "requests exhausted"
        ));
    }

    #[test]
    fn homogeneous_payment_failures_keep_diagnostic() {
        let error = aggregate_fallback_errors(vec![
            BitrouterError::UpstreamPaymentRequired {
                detail: Some("insufficient credit".to_owned()),
            },
            BitrouterError::UpstreamPaymentRequired { detail: None },
        ]);

        assert!(matches!(
            error,
            BitrouterError::UpstreamPaymentRequired { detail: Some(ref detail) }
                if detail == "insufficient credit"
        ));
    }
}

/// Owns provisional non-stream success state until the response is ready to be
/// returned. Dropping `Pipeline::execute` at any await after a finalizer starts
/// schedules reverse-order rollback on the same shutdown-tracked task set used
/// by streaming settlement.
struct RequiredFinalizationGuard {
    finalizers: Vec<Arc<dyn RequiredFinalizer>>,
    finalization: RequiredFinalizationContext,
    pending_settlements: Arc<std::sync::Mutex<tokio::task::JoinSet<()>>>,
    receipt: Option<RequiredFinalizationReceipt>,
    armed: bool,
}

impl RequiredFinalizationGuard {
    fn new(
        finalizers: Vec<Arc<dyn RequiredFinalizer>>,
        finalization: RequiredFinalizationContext,
        pending_settlements: Arc<std::sync::Mutex<tokio::task::JoinSet<()>>>,
    ) -> Self {
        Self {
            finalizers,
            finalization,
            pending_settlements,
            receipt: None,
            armed: true,
        }
    }

    fn disarm(&mut self) {
        self.armed = false;
        self.receipt = None;
    }

    fn begin_delivery(
        &mut self,
    ) -> (
        DeliveryPermit,
        tokio::sync::oneshot::Receiver<DeliveryAuthorizationOutcome>,
    ) {
        let (permit, delivery) = delivery_handshake();
        let (outcome_tx, outcome_rx) = tokio::sync::oneshot::channel();
        let finalizers = self.finalizers.clone();
        let finalization = self.finalization.clone();
        let receipt = self.receipt.clone();
        self.disarm();
        let authorization = async move {
            let authorization_result = match receipt.as_ref() {
                Some(receipt) => {
                    finalizers[0]
                        .commit_with_receipt(&finalization, receipt, &delivery)
                        .await
                }
                None => delivery.wait_for_delivery().await,
            };
            let delivered = match authorization_result {
                Ok(delivered) => delivered,
                Err(error) => {
                    delivery.reject(error.clone());
                    if let Some(receipt) = receipt.as_ref()
                        && let Err(rollback_error) = finalizers[0]
                            .rollback_with_receipt(&finalization, receipt)
                            .await
                    {
                        tracing::error!(error = %rollback_error, "RequiredFinalizer rollback failed");
                    }
                    let _ = outcome_tx.send(DeliveryAuthorizationOutcome::Failed(error));
                    return;
                }
            };
            if !delivered
                && let Some(receipt) = receipt.as_ref()
                && let Err(error) = finalizers[0]
                    .rollback_with_receipt(&finalization, receipt)
                    .await
            {
                tracing::error!(error = %error, "RequiredFinalizer rollback failed");
            }
            let _ = outcome_tx.send(if delivered {
                DeliveryAuthorizationOutcome::Delivered
            } else {
                DeliveryAuthorizationOutcome::Disconnected
            });
        }
        .instrument(tracing::Span::current());
        match self.pending_settlements.lock() {
            Ok(mut set) => {
                while set.try_join_next().is_some() {}
                set.spawn(authorization);
            }
            Err(poisoned) => {
                let mut set = poisoned.into_inner();
                while set.try_join_next().is_some() {}
                set.spawn(authorization);
            }
        }
        (permit, outcome_rx)
    }
}

impl Drop for RequiredFinalizationGuard {
    fn drop(&mut self) {
        if !self.armed || self.receipt.is_none() {
            return;
        }
        let finalizers = self.finalizers.clone();
        let finalization = self.finalization.clone();
        let receipt = self.receipt.clone();
        self.disarm();
        let rollback = async move {
            if let Some(receipt) = receipt.as_ref()
                && let Err(error) = finalizers[0]
                    .rollback_with_receipt(&finalization, receipt)
                    .await
            {
                tracing::error!(error = %error, "RequiredFinalizer rollback failed");
            }
        }
        .instrument(tracing::Span::current());
        match self.pending_settlements.lock() {
            Ok(mut set) => {
                while set.try_join_next().is_some() {}
                set.spawn(rollback);
            }
            Err(poisoned) => {
                let mut set = poisoned.into_inner();
                while set.try_join_next().is_some() {}
                set.spawn(rollback);
            }
        }
    }
}

/// Owns the streaming `StreamProcessor` + `PipelineContext` for the lifetime of
/// a streaming response, and guarantees the StreamHook stage's `on_stream_end`
/// plus Stage-4 Settlement run **exactly once** — whether the stream completes
/// normally or the client drops it early.
struct StreamSettlementGuard {
    pipeline: Arc<Pipeline>,
    latest_attempt: SharedStreamAttempt,
    required_finalizer_receipt: Option<RequiredFinalizationReceipt>,
    /// Owned until the terminal is ready to be returned. Cancellation at any
    /// await leaves this state available to `Drop`, which reclassifies the
    /// request as disconnected and never runs required finalizers.
    state: Option<StreamDeliveryState>,
}

struct PendingStreamDelivery {
    processor: Option<StreamProcessor>,
    ctx: Option<PipelineContext>,
}

enum StreamDeliveryState {
    Pending(Box<PendingStreamDelivery>),
    Preparing {
        disconnected: Arc<AtomicBool>,
        prepared: Arc<std::sync::Mutex<Option<PipelineContext>>>,
    },
    Ready(Box<PipelineContext>),
}

fn take_prepared_context(
    slot: &Arc<std::sync::Mutex<Option<PipelineContext>>>,
) -> Option<PipelineContext> {
    match slot.lock() {
        Ok(mut ctx) => ctx.take(),
        Err(poisoned) => poisoned.into_inner().take(),
    }
}

impl StreamSettlementGuard {
    /// Mutable access to the in-flight processor (the stream driver feeds parts
    /// through it). Invalid or repeated state transitions fail closed without
    /// taking ownership away from `Drop`.
    fn processor(&mut self) -> Result<&mut StreamProcessor> {
        match self.state.as_mut() {
            Some(StreamDeliveryState::Pending(state)) => {
                state.processor.as_mut().ok_or_else(|| {
                    BitrouterError::internal("stream processor has already been absorbed")
                })
            }
            None => Err(BitrouterError::internal(
                "stream guard has already been finalized",
            )),
            Some(StreamDeliveryState::Preparing { .. } | StreamDeliveryState::Ready(_)) => Err(
                BitrouterError::internal("stream processor is already preparing or absorbed"),
            ),
        }
    }

    async fn finish_processor(&mut self, outcome: StreamOutcome) -> Result<()> {
        match self.state.as_ref() {
            Some(StreamDeliveryState::Pending(_)) => {}
            Some(StreamDeliveryState::Preparing { .. }) => {
                return Err(BitrouterError::internal(
                    "stream terminal preparation is already in progress",
                ));
            }
            Some(StreamDeliveryState::Ready(_)) => {
                return Err(BitrouterError::internal(
                    "stream processor has already finished",
                ));
            }
            None => {
                return Err(BitrouterError::internal(
                    "stream guard has already been finalized",
                ));
            }
        }
        let Some(StreamDeliveryState::Pending(mut pending)) = self.state.take() else {
            return Err(BitrouterError::internal(
                "stream guard state changed during terminal preparation",
            ));
        };
        let Some(mut processor) = pending.processor.take() else {
            self.state = Some(StreamDeliveryState::Pending(pending));
            return Err(BitrouterError::internal(
                "stream processor has already been absorbed",
            ));
        };
        let Some(mut ctx) = pending.ctx.take() else {
            pending.processor = Some(processor);
            self.state = Some(StreamDeliveryState::Pending(pending));
            return Err(BitrouterError::internal(
                "stream context has already been taken",
            ));
        };
        let disconnected = Arc::new(AtomicBool::new(false));
        let task_disconnected = disconnected.clone();
        let prepared = Arc::new(std::sync::Mutex::new(None));
        let task_prepared = prepared.clone();
        let pipeline = self.pipeline.clone();
        let latest_attempt = self.latest_attempt.clone();
        let task_outcome = outcome.clone();
        let (prepared_tx, prepared_rx) = tokio::sync::oneshot::channel();
        self.pipeline.spawn_stream_finalization(async move {
            // Stream hooks and usage finalization run in one tracked task. If
            // the body poll is cancelled inside a hook await, this task keeps
            // ownership and completes each hook exactly once; it never runs a
            // required finalizer.
            processor.finish(task_outcome.clone()).await;
            sync_execution_target(&mut ctx, &latest_attempt);
            ctx.absorb_stream(processor.into_context());
            ctx.finalize_stream_upstream_duration();

            if task_disconnected.load(Ordering::Acquire)
                && matches!(task_outcome, StreamOutcome::Completed)
            {
                settle_prepared_stream(pipeline, ctx, None, RequestOutcome::ClientDisconnected)
                    .await;
                return;
            }
            match task_prepared.lock() {
                Ok(mut slot) => *slot = Some(ctx),
                Err(poisoned) => *poisoned.into_inner() = Some(ctx),
            }
            if task_disconnected.load(Ordering::Acquire)
                && matches!(task_outcome, StreamOutcome::Completed)
            {
                if let Some(ctx) = take_prepared_context(&task_prepared) {
                    settle_prepared_stream(pipeline, ctx, None, RequestOutcome::ClientDisconnected)
                        .await;
                }
                return;
            }
            if prepared_tx.send(()).is_err() {
                let Some(ctx) = take_prepared_context(&task_prepared) else {
                    return;
                };
                let (error, request_outcome) = if matches!(task_outcome, StreamOutcome::Completed) {
                    (None, RequestOutcome::ClientDisconnected)
                } else {
                    stream_terminal_metadata(&task_outcome)
                };
                settle_prepared_stream(pipeline, ctx, error, request_outcome).await;
            }
        });
        self.state = Some(StreamDeliveryState::Preparing {
            disconnected,
            prepared: prepared.clone(),
        });
        prepared_rx.await.map_err(|error| {
            BitrouterError::internal(format!(
                "stream terminal preparation ended unexpectedly: {error}"
            ))
        })?;
        let ctx = take_prepared_context(&prepared).ok_or_else(|| {
            BitrouterError::internal("stream terminal preparation returned no context")
        })?;
        self.state = Some(StreamDeliveryState::Ready(Box::new(ctx)));
        Ok(())
    }

    async fn run_required_finalizers(&mut self) -> Result<()> {
        let Some(StreamDeliveryState::Ready(ctx)) = self.state.as_ref() else {
            return Err(BitrouterError::internal(
                "required stream finalizers need a prepared terminal",
            ));
        };
        let finalization = ctx.required_finalization_context(true);
        if !finalization.successful_terminal {
            return Ok(());
        }
        self.required_finalizer_receipt = self
            .pipeline
            .prepare_required_finalizer_tracked(&finalization)
            .await?;
        Ok(())
    }

    /// Finalise a provider terminal inline only through the required-finalizer
    /// boundary. Settlement is then enqueued and the terminal is returned
    /// synchronously by the same `poll_next` call.
    async fn finalize(&mut self, outcome: StreamOutcome) -> Result<Option<DeliveryPermit>> {
        if self.state.is_none() {
            return Err(BitrouterError::internal(
                "stream guard has already been finalized",
            ));
        }
        self.finish_processor(outcome.clone()).await?;

        let (settlement_error, request_outcome, delivery_error) = {
            let Some(StreamDeliveryState::Ready(ctx)) = self.state.as_ref() else {
                return Err(BitrouterError::internal(
                    "stream terminal preparation did not produce a ready context",
                ));
            };
            let (error, outcome) = stream_terminal_metadata(&outcome);
            if matches!(outcome, RequestOutcome::Completed) && !ctx.stream_terminal_succeeded() {
                let error = BitrouterError::UpstreamInvalidResponse {
                    message: "stream ended with a non-success provider terminal".to_string(),
                    usage: None,
                };
                let missing_terminal = ctx
                    .required_finalization_context(true)
                    .finish_reason
                    .is_none();
                (
                    Some(error.clone()),
                    RequestOutcome::Failed(error.clone()),
                    missing_terminal.then_some(error),
                )
            } else {
                (error, outcome, None)
            }
        };

        if matches!(outcome, StreamOutcome::Completed)
            && settlement_error.is_none()
            && let Err(error) = self.run_required_finalizers().await
        {
            let Some(StreamDeliveryState::Ready(ctx)) = self.state.take() else {
                return Err(error);
            };
            let settlement_error = error.clone();
            let pipeline = self.pipeline.clone();
            let receipt = self.required_finalizer_receipt.take();
            self.pipeline.spawn_stream_finalization(async move {
                rollback_required_finalizer(&pipeline, &ctx, true, receipt).await;
                settle_prepared_stream(
                    pipeline.clone(),
                    *ctx,
                    Some(settlement_error.clone()),
                    RequestOutcome::Failed(settlement_error),
                )
                .await;
            });
            return Err(error);
        }

        let Some(StreamDeliveryState::Ready(ctx)) = self.state.take() else {
            return Err(BitrouterError::internal(
                "stream terminal context was consumed before settlement",
            ));
        };
        if settlement_error.is_some() {
            let pipeline = self.pipeline.clone();
            self.pipeline.spawn_stream_finalization(async move {
                settle_prepared_stream(pipeline, *ctx, settlement_error, request_outcome).await;
            });
            if let Some(error) = delivery_error {
                return Err(error);
            }
            return Ok(None);
        }
        let pipeline = self.pipeline.clone();
        let receipt = self.required_finalizer_receipt.take();
        let finalization = ctx.required_finalization_context(true);
        let (permit, delivery) = delivery_handshake();
        self.pipeline.spawn_stream_finalization(async move {
            let authorization_result = match receipt.as_ref() {
                Some(receipt) => {
                    pipeline.required_finalizers[0]
                        .commit_with_receipt(&finalization, receipt, &delivery)
                        .await
                }
                None => delivery.wait_for_delivery().await,
            };
            let delivered = match authorization_result {
                Ok(delivered) => delivered,
                Err(error) => {
                    delivery.reject(error.clone());
                    rollback_required_finalizer(&pipeline, &ctx, true, receipt).await;
                    settle_prepared_stream(
                        pipeline.clone(),
                        *ctx,
                        Some(error.clone()),
                        RequestOutcome::Failed(error),
                    )
                    .await;
                    return;
                }
            };
            if delivered {
                settle_prepared_stream(pipeline, *ctx, settlement_error, request_outcome).await;
            } else {
                rollback_required_finalizer(&pipeline, &ctx, true, receipt).await;
                settle_prepared_stream(pipeline, *ctx, None, RequestOutcome::ClientDisconnected)
                    .await;
            }
        });

        // NO AWAIT BELOW THIS POINT. The caller yields the buffered terminal
        // immediately after this Ready return, in this same `poll_next` call.
        // This transition is the delivery authorization boundary: before it,
        // Drop owns PendingDelivery and may reclassify to ClientDisconnected;
        // after it, required finalization has committed and Poll::Ready carries
        // the terminal to the consumer without another cancellation point.
        Ok(Some(permit))
    }
}

fn stream_terminal_metadata(outcome: &StreamOutcome) -> (Option<BitrouterError>, RequestOutcome) {
    match outcome {
        StreamOutcome::Completed => (None, RequestOutcome::Completed),
        StreamOutcome::ClientDisconnected => (None, RequestOutcome::ClientDisconnected),
        StreamOutcome::Aborted(err) | StreamOutcome::UpstreamError(err) => {
            (Some(err.clone()), RequestOutcome::Failed(err.clone()))
        }
    }
}

async fn rollback_required_finalizer(
    pipeline: &Pipeline,
    ctx: &PipelineContext,
    streamed: bool,
    receipt: Option<RequiredFinalizationReceipt>,
) {
    let Some(receipt) = receipt.as_ref() else {
        return;
    };
    let finalization = ctx.required_finalization_context(streamed);
    if let Err(error) = pipeline.required_finalizers[0]
        .rollback_with_receipt(&finalization, receipt)
        .await
    {
        tracing::error!(error = %error, "RequiredFinalizer rollback failed");
    }
}

async fn settle_prepared_stream(
    pipeline: Arc<Pipeline>,
    mut ctx: PipelineContext,
    settlement_error: Option<BitrouterError>,
    request_outcome: RequestOutcome,
) {
    pipeline
        .run_settlement(&mut ctx, true, settlement_error)
        .await;
    pipeline.observe_after(Phase::Settlement, &ctx).await;
    pipeline.observe_end(&ctx, request_outcome).await;
}

async fn finalize_disconnected_stream(
    pipeline: Arc<Pipeline>,
    latest_attempt: SharedStreamAttempt,
    mut state: PendingStreamDelivery,
) {
    if let Some(processor) = state.processor.as_mut() {
        processor.finish(StreamOutcome::ClientDisconnected).await;
    }
    let Some(mut ctx) = state.ctx.take() else {
        return;
    };
    if let Some(processor) = state.processor.take() {
        sync_execution_target(&mut ctx, &latest_attempt);
        ctx.absorb_stream(processor.into_context());
        ctx.finalize_stream_upstream_duration();
    }
    settle_prepared_stream(pipeline, ctx, None, RequestOutcome::ClientDisconnected).await;
}

impl Drop for StreamSettlementGuard {
    fn drop(&mut self) {
        // If `state` is still `Some`, the consumer dropped the stream before it
        // terminated — settle the delivered tokens on a detached task with a
        // `ClientDisconnected` outcome so no streaming settlement is lost.
        //
        // The task is held on the pipeline's `pending_settlements` JoinSet so
        // `Pipeline::drain_pending_settlements` can await every in-flight
        // detached settlement during graceful shutdown — otherwise SIGTERM
        // could cut a settlement task mid-await and the receipt would be lost.
        match self.state.take() {
            Some(StreamDeliveryState::Pending(state)) => {
                let pipeline = self.pipeline.clone();
                let latest_attempt = self.latest_attempt.clone();
                self.pipeline.spawn_stream_finalization(async move {
                    finalize_disconnected_stream(pipeline, latest_attempt, *state).await;
                });
            }
            Some(StreamDeliveryState::Preparing {
                disconnected,
                prepared,
            }) => {
                // The tracked terminal-hook task retains processor/context
                // ownership and will settle as ClientDisconnected. It cannot
                // invoke required finalizers.
                disconnected.store(true, Ordering::Release);
                if let Some(ctx) = take_prepared_context(&prepared) {
                    let pipeline = self.pipeline.clone();
                    self.pipeline.spawn_stream_finalization(async move {
                        settle_prepared_stream(
                            pipeline,
                            ctx,
                            None,
                            RequestOutcome::ClientDisconnected,
                        )
                        .await;
                    });
                }
            }
            Some(StreamDeliveryState::Ready(ctx)) => {
                let pipeline = self.pipeline.clone();
                let receipt = self.required_finalizer_receipt.take();
                self.pipeline.spawn_stream_finalization(async move {
                    rollback_required_finalizer(&pipeline, &ctx, true, receipt).await;
                    settle_prepared_stream(
                        pipeline.clone(),
                        *ctx,
                        None,
                        RequestOutcome::ClientDisconnected,
                    )
                    .await;
                });
            }
            None => {}
        }
    }
}

// ===== request lifecycle logging =====
//
// Two canonical INFO lines per request, mirroring v0's operator log:
//
//     "request received"  — once route resolution succeeds.
//     "request finished"  — once settlement runs (success or failure).
//
// An additional "request received (resolution failed)" line covers the
// pre-request / route-resolution failure path so the operator sees the
// request even when it never reaches a provider. Fields stay flat
// (no nested objects) so structured-log collectors can index them.

/// Emit the "request received" log line. Called from `execute` and
/// `execute_stream` after the route chain is non-empty.
fn log_request_received(ctx: &PipelineContext, head: Option<&RoutingTarget>, stream: bool) {
    let (provider, model) = head
        .map(|t| (t.provider_name.as_str(), t.service_id.as_str()))
        .unwrap_or(("-", "-"));
    // The account of the *primary* target — for a multi-account
    // provider this is the one routing will try first; failover may
    // land on a different one (see the "request finished" line).
    let account = head.and_then(|t| t.account_label.as_deref()).unwrap_or("-");
    tracing::info!(
        request_id = %ctx.request_id(),
        user_id = ctx.caller().user_id(),
        route = ctx.model(),
        provider,
        model,
        account,
        stream,
        "request received"
    );
}

/// Emit the "request received (resolution failed)" log line — the
/// pre-request or route-resolution stage rejected the request, so we
/// never made it to a provider. Recorded so a stream of `info!`s
/// always carries the request even if it doesn't have a counterpart
/// "finished" line.
fn log_request_resolve_failed(ctx: &PipelineContext, error: &BitrouterError) {
    tracing::info!(
        request_id = %ctx.request_id(),
        user_id = ctx.caller().user_id(),
        route = ctx.model(),
        error = %error,
        "request received (resolution failed)"
    );
}

/// Emit the "request finished" log line from a [`SettlementContext`].
/// Carries the canonical accounting fields — token counts, latency,
/// streamed flag — plus `status` (200 / inferred from error) so a
/// log-collector can build dashboards without parsing the message.
fn log_request_finished(settle: &SettlementContext) {
    // The account that actually served the request — for a
    // multi-account provider this reflects any failover hop, so it can
    // differ from the "request received" line's primary account.
    let account = settle.account_label.as_deref().unwrap_or("-");
    match &settle.error {
        None => tracing::info!(
            request_id = %settle.request_id,
            user_id = settle.caller.user_id(),
            provider = %settle.provider_id,
            model = %settle.model_id,
            account,
            stream = settle.streamed,
            status = 200,
            request_duration_ms = settle.request_duration_ms,
            input_tokens = settle.prompt_tokens,
            output_tokens = settle.completion_tokens,
            "request finished"
        ),
        Some(err) => tracing::info!(
            request_id = %settle.request_id,
            user_id = settle.caller.user_id(),
            provider = %settle.provider_id,
            model = %settle.model_id,
            account,
            stream = settle.streamed,
            request_duration_ms = settle.request_duration_ms,
            error = %err,
            "request finished"
        ),
    }
}

#[cfg(test)]
mod stream_outcome_tests {
    use std::sync::Arc;

    use super::{
        RequestOutcome, StreamOutcome, StreamSettlementGuard, delivery_handshake,
        stream_terminal_metadata,
    };
    use crate::error::BitrouterError;

    use crate::language_model::{MockExecutor, PipelineBuilder, StaticRoutingTable};

    fn finalized_guard() -> StreamSettlementGuard {
        let mut builder = PipelineBuilder::new();
        builder
            .routing_table(Arc::new(StaticRoutingTable::new()))
            .executor(Arc::new(MockExecutor::new(Vec::new())));
        StreamSettlementGuard {
            pipeline: Arc::new(builder.build().expect("test pipeline")),
            latest_attempt: Arc::new(std::sync::Mutex::new(None)),
            required_finalizer_receipt: None,
            state: None,
        }
    }

    #[test]
    fn invalid_stream_guard_processor_access_returns_without_panicking() {
        let mut guard = finalized_guard();

        let access = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            guard.processor().map(|_| ())
        }));
        assert!(
            access.is_ok(),
            "invalid stream guard state panicked instead of returning a typed error"
        );
        let error = access
            .expect("processor access does not panic")
            .expect_err("finalized guard processor access must fail");
        assert!(matches!(error, BitrouterError::Internal(_)));
    }

    #[tokio::test]
    async fn repeated_stream_guard_finalization_returns_typed_error() {
        let error = match finalized_guard().finalize(StreamOutcome::Completed).await {
            Err(error) => error,
            Ok(_) => panic!("repeated finalization succeeded"),
        };
        assert!(matches!(error, BitrouterError::Internal(_)));
    }

    #[test]
    fn upstream_error_maps_to_failed() {
        // The fix for the streaming-error blind spot: a mid-stream upstream error
        // must reach `on_request_end` as `Failed`, not a silent `Completed`.
        let outcome = StreamOutcome::UpstreamError(BitrouterError::internal("mid-stream boom"));
        let (error, request_outcome) = stream_terminal_metadata(&outcome);
        assert!(error.is_some());
        assert!(matches!(request_outcome, RequestOutcome::Failed(_)));
    }

    #[test]
    fn abort_maps_to_failed_settlement() {
        let outcome = StreamOutcome::Aborted(BitrouterError::bad_request("blocked"));
        let (error, request_outcome) = stream_terminal_metadata(&outcome);
        assert!(error.is_some());
        assert!(matches!(request_outcome, RequestOutcome::Failed(_)));
    }

    #[test]
    fn completion_maps_to_completed_without_error() {
        let (error, request_outcome) = stream_terminal_metadata(&StreamOutcome::Completed);
        assert!(error.is_none());
        assert!(matches!(request_outcome, RequestOutcome::Completed));
    }

    #[test]
    fn disconnect_maps_to_disconnect() {
        let (error, request_outcome) = stream_terminal_metadata(&StreamOutcome::ClientDisconnected);
        assert!(error.is_none());
        assert!(matches!(
            request_outcome,
            RequestOutcome::ClientDisconnected
        ));
    }

    #[tokio::test]
    async fn explicit_wire_failure_is_not_classified_as_disconnect() {
        let (permit, delivery) = delivery_handshake();
        let authorization = tokio::spawn(async move { delivery.wait_for_delivery().await });
        permit
            .fail(BitrouterError::internal("terminal encoder failed"))
            .await
            .expect("failure acknowledgement reaches authorization worker");
        let outcome = authorization.await.expect("authorization worker joins");
        assert!(matches!(
            outcome,
            Err(BitrouterError::Internal(message)) if message == "terminal encoder failed"
        ));
    }

    #[tokio::test]
    async fn delivered_permit_waits_for_finalizer_post_ack_commit() {
        let (permit, delivery) = delivery_handshake();
        let (ack_observed_tx, ack_observed_rx) = tokio::sync::oneshot::channel();
        let (finish_tx, finish_rx) = tokio::sync::oneshot::channel();
        let authorization = tokio::spawn(async move {
            let delivered = delivery.wait_for_delivery_acknowledgement().await?;
            let _ = ack_observed_tx.send(());
            let _ = finish_rx.await;
            assert!(delivery.complete_activation(Ok(())));
            assert!(delivery.wait_for_terminal_commit().await);
            Ok::<bool, BitrouterError>(delivered)
        });
        let mut delivery_result = tokio::spawn(async move { permit.deliver().await });

        ack_observed_rx
            .await
            .expect("finalizer observes downstream acknowledgement");
        assert!(
            tokio::time::timeout(std::time::Duration::from_millis(20), &mut delivery_result,)
                .await
                .is_err(),
            "successful terminal must wait for the finalizer's post-ack durable commit"
        );
        finish_tx.send(()).expect("release finalizer");
        assert!(authorization.await.expect("authorization joins").unwrap());
        delivery_result
            .await
            .expect("delivery task joins")
            .expect("delivery succeeds");
    }

    #[tokio::test]
    async fn dropping_permit_after_activation_signal_closes_terminal_commit() {
        let (permit, delivery) = delivery_handshake();
        let mut authorization = Box::pin(async move {
            assert!(delivery.wait_for_delivery_acknowledgement().await?);
            assert!(delivery.complete_activation(Ok(())));
            Ok::<bool, BitrouterError>(delivery.wait_for_terminal_commit().await)
        });
        assert!(futures::poll!(authorization.as_mut()).is_pending());

        let mut deliver = Box::pin(permit.deliver());
        assert!(futures::poll!(deliver.as_mut()).is_pending());
        assert!(futures::poll!(authorization.as_mut()).is_pending());
        drop(deliver);

        assert!(!authorization.await.expect("authorization remains valid"));
    }
}
