//! ACP continuation derives from the original public journal, never native context.
use super::Active;
use crate::service::worker::acp::{Action, Binding, Continuation};
use crate::store::ExecutionRecord;

#[derive(serde::Serialize)]
pub(super) struct State {
    prompt: String,
    binding: Option<Binding>,
    submitted: bool,
    observed: bool,
    pub(super) accepted_at_ms: Option<u64>,
}
impl State {
    pub(super) fn new(prompt: String) -> Self {
        Self {
            prompt,
            binding: None,
            submitted: false,
            observed: false,
            accepted_at_ms: None,
        }
    }
    pub(super) fn consume(&mut self, fact: &ExecutionRecord) -> Result<(), String> {
        match fact {
            ExecutionRecord::AcpSession { binding } => {
                if binding.session_id.is_empty() || binding.run_id.is_empty() {
                    return Err("ACP session identity is empty".into());
                }
                if let Some(old) = &self.binding {
                    if binding.restored_from.as_ref() != Some(&old.run_id)
                        || binding.session_id != old.session_id
                        || binding.agent_id != old.agent_id
                        || self.submitted
                        || self.observed
                    {
                        return Err(
                            "ACP restored binding lacks original pre-prompt continuity".into()
                        );
                    }
                } else if binding.restored_from.is_some() {
                    return Err("ACP restored binding has no original session".into());
                }
                self.binding = Some(binding.as_ref().clone());
            }
            ExecutionRecord::AcpDispatch {
                action: Action::Prompt,
                ..
            } => self.submitted = true,
            ExecutionRecord::AcpObservation { .. }
            | ExecutionRecord::AcpPermissionChoice { .. }
            | ExecutionRecord::AcpPermissionDispatch { .. } => self.observed = true,
            _ => {}
        }
        Ok(())
    }
    pub(super) fn continuation(&self, active: &Active) -> Option<Continuation> {
        let binding = self.binding.as_ref()?;
        let accepted_at_ms = self.accepted_at_ms.filter(|ms| *ms > 0)?;
        (!self.submitted
            && !self.observed
            && !active.native
            && !active.settled
            && !active.cancel_requested
            && active.steps.is_empty()
            && active.calls.is_empty()
            && active.steering.is_empty()
            && !self.prompt.trim().is_empty())
        .then(|| Continuation {
            binding: binding.clone(),
            prompt: self.prompt.clone(),
            accepted_at_ms,
        })
    }
}
