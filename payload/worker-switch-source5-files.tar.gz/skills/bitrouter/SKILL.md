---
name: bitrouter
description: >
  Use when installing, configuring, running, or troubleshooting BitRouter from
  its CLI — a self-hosted LLM proxy on 127.0.0.1:4356 routing OpenAI- or
  Anthropic-shaped traffic to any provider, via a coding-agent subscription,
  hosted BitRouter, or your own keys. Covers bro init, provider
  credentials, BRO Goals, native task APIs, ACP harnesses, routing, and spend.
  Trigger on bitrouter.yaml, port 4356, brk_ keys, "replace litellm", or
  pointing a coding agent at a proxy.
license: Apache-2.0
metadata:
  author: BitRouterAI
  tags: [llm, proxy, routing, cli, ai-gateway, claude-code, codex]
---

# BitRouter
BitRouter is a self-hosted Rust daemon at `http://127.0.0.1:4356` that routes OpenAI- or Anthropic-shaped requests to providers selected in §4. Native CLI tasks use bounded read workers and database execution records; see `references/cli.md` for permissions and restart limitations. Metered `google` uses Chat Completions with `GEMINI_API_KEY`; native Gemini routes, `google-ai` and Vertex Express are retired.

Native BRO execution commits task/model/tool facts to the database; `references/cli.md` covers capabilities and restart limitations.
`bro task managed` connects native tools to the in-process managed core with released-session continuation. Custom durable harness clients use the negotiated managed-core HTTP/WebSocket profile; see `references/managed-core.md` for binding, ACKs, results and current limits.

## Activate in one pass
Work top to bottom, probing before asking.

### 1. Probe
```bash
bro --version          # not found -> step 2
bro status             # liveness + `spend`; `running: false` when nothing is reachable
bro providers list     # ID  MODELS  ACTIVE  API_BASE
```

These emit JSON by default (`--human` is readable). Branch on the result:
missing command → §2; no active providers → §3; stopped daemon → `start`; both ready → §5.

### 2. Install
```bash
curl --proto '=https' --tlsv1.2 -LsSf https://bitrouter.ai/install.sh | sh
```

macOS: `brew install bitrouter/tap/bitrouter`. Node: `npm install -g bitrouter`.
Windows: `powershell -ExecutionPolicy Bypass -c "irm https://bitrouter.ai/install.ps1 | iex"`.
Verify with `bro --version`; on failure read `references/diagnose.md`.

### 3. Configure

A human runs `bro init` to configure providers (including BitRouter Cloud),
ACP harnesses and the finish action. Bare `bro` opens Goals. Credentials alone do not mark setup complete.
For scripted setup:
```bash
bro init --yes --use-detected --harness codex --after exit
```

This saves `chat.agent: codex-acp` in the resolved config, or the BitRouter home when
no config exists. `--model ID` persists the default model too. Existing settings are
preserved; `--force` resets them. Read `providers_skipped_interactive` for logins needing
a human. No hand-written agent entry is needed. See `references/cli.md` for all flags.

### 4. Choose providers — subscription first
These logins are interactive, so they are what `providers_skipped_interactive`
reports. Work the order below: it buys the same tokens for less money.

**a. The subscription they already pay for.** If the user drives Claude Code or Codex,
log that in first so the harness keeps serving its models from the plan they already bought.

```bash
bro providers login claude-code    # adopts the live Claude Code session
bro providers login openai-codex   # ChatGPT PKCE flow in a browser
bro providers login bitrouter      # hosted; same sign-in as `cloud login`
```
Auth is catalog-derived; `references/providers.md` lists each login method.
**b. Hosted BitRouter for everything else.** Signing in adds a managed
`bitrouter` provider to this daemon; it is not a second deployment.

**c. BYOK for anything they want to own directly.** Export the key and start —
the daemon auto-enables every provider whose key is present, and
`export ...; bro reload` rotates one without a restart.
Detected vars: `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GEMINI_API_KEY` (not `GOOGLE_API_KEY`), `OPENROUTER_API_KEY`, `OPENCODE_ZEN_API_KEY` (zen *and* go).

`providers login` also takes `--api-key` / `--key-stdin`; `references/cloud-setup.md`
covers hosted accounts, credits, and `brk_*` keys. Hosted BitRouter or BYOK supplements subscriptions.

### 5. Choose the work interface

BRO orchestrates long-running, parallel workflows. Built-in Goal workers use native Thread/Turn execution and one-time permission replies; ACP workers remain available. See `references/cli.md` for bounded model-admission waiting and remaining recovery/budget-wait limits.
The Goal directory, current Goal and read-only Workflow have separate navigation;
viewing never creates work. Enter submits to the current Goal even while workers run.
Queries and hypotheses do not modify requirements; accepted changes and actual
execution evidence are reported separately. Pause, stop, resume, budgets and permission
responses use explicit controls. Finished, declared local tool work can be
replaced after stop/history/workspace reconciliation; incomplete or external
effects remain blocked. Saved edits do not resume paused work. Exit detaches. Read `references/cli.md` for keys,
resource limits, unknown costs and recovery boundaries.

Goal tasks select configured MCP IDs, versioned skill material IDs and relative
workspace context. BRO freezes supplied bytes before dispatch; ACP MCP transport
support is negotiated. Configuration/material delivery does not prove tool use,
private skill activation or an actual provider model.
Tasks may select a configured BRO model route when session route control is
available. BRO requires controller confirmation before sending work; requested
and confirmed routes remain distinct from an actual upstream model identity.
Current-Goal input versions a task's requested worker/resources. BRO confirms old
execution/effect boundaries before a new Thread adopts that selection.
Unresolved input survives queries; `/input <id> <reply>` references it, and exact `/input <id> /withdraw` cancels only that uncommitted request without a model/budget increase. Query-only clarification adds no completion condition. Goal IPC v6 preserves older outboxes without replay. Superseded reconciled executions can leave the current snapshot; their complete records remain in immutable Goal history without resetting current attempts or budget.

```bash
bro                         # Goals; no Goal or agent starts from a directory read
bro code --workspace PATH   # Goals; workspace applies to new Goals only
bro claude                  # Claude's own interface with per-process overrides
bro codex -- --search       # Codex's own interface; arguments are forwarded
bro run codex "audit this repo" --background  # supervised headless ACP
bro acp serve codex          # transparent ACP stdio endpoint for another client
bro task run "inspect this project" --read-only  # retained native task API
bro agents sessions --json   # supervised-run inventory
```

`code <agent>` and the old `chat/tui` aliases are removed. Goal `code` accepts
`--config` and `--workspace`; native Thread/model/load/resume flags belong to
retained task/run interfaces, not Goals. Remote Goal execution is unsupported;
non-TTY callers should use `run` or the native task API.

Native `launch <agent>` accepts catalog harnesses; `claude`, `claude-code` and
`codex` are shortcuts. User configuration is not edited. Existing harness processes
need a new launch to adopt overrides; `bro acp serve <agent>` serves ACP clients.
Background runs survive client exit; attach/stop/remove remain separate.
Standalone native task APIs (local v17, opt-in HTTP `/agent/v2`) remain available; Native and managed ACP Goal workers share Thread/Turn ownership and Goal controls; generic supervisor controls cannot take over managed Turns.
See `references/sessions.md` for ownership and `references/decision-native.md`
for bounded model/context routing, MCP/skills, token reservations and its cost scope.
For the native BRO ACP endpoint, use bare `bro acp serve --model openai/gpt-5`.
It negotiates v1/draft v2 on the retained ThreadService; EOF detaches, cancel
pauses inputs and close retains history. External harnesses use `acp serve <agent>`.

### 6. Verify
```bash
bro route claude-sonnet-4-6   # preview; check `policy_decision_executed`
bro models                    # everything routable, with every provider that serves it
bro requests                  # settled requests + spend, JSON (--human for a table)
```

`requests` reads the metering store directly, so it works with no
daemon and is safe for an agent to call — a routed call appearing there, naming
the provider that actually served it, is the proof activation worked. Do **not**
use the cost as that proof: most rows carry no charge evidence and render `?`,
and the rollup reads `unreported` rather than `$0.00` when none does. Canonical
ids use slashes and a pin uses a colon (`openrouter:openai/gpt-4o`);
`references/diagnose.md` has the full spelling rules.

For administration from another computer, use a named `--context`; see
`references/remote-administration.md` for token scopes, tunnel setup, and host
boundaries. Remote errors never fall back to this machine's configuration.

## References — read on demand
| File | When to read |
|---|---|
| `references/cli.md` | Full subcommand reference — the primary reference |
| `references/remote-administration.md` | Remote contexts, operator credentials, and host boundaries |
| `references/guardrails.md` | Independent input checker, router binding, and blocked legacy guardrails migration |
| `references/providers.md` | Add / configure providers, multi-account, custom endpoints, model-id spelling |
| `references/decisions.md` | Native Decisions requests, API-key setup, operation routing and tariff limits |
| `references/cloud-setup.md` | Cloud signup, key mint, billing, wallet path |
| `references/diagnose.md` | Install issues, daemon won't start, connection refused, model ids |
| `references/harness-*.md` | Durable per-harness wiring instead of `launch`: `-claude-code`, `-codex`, `-hermes-agent`, `-openclaw`, `-terminus-2` |
| `references/migrate-from-*.md` | Migrating off `-litellm`, `-openrouter`, `-openai-compatible` (Azure, Together, Groq, Ollama, LM Studio), `-anthropic-compatible` |
| `references/adaptive-routing.md`, `references/workflow-optimization.md`, `references/metering.md` | `bitrouter/auto`, trace projections, policy locks; history-driven quality/cost optimization; cache-aware pricing, charge evidence, usage export |
| `references/sessions.md`, `references/updating.md` | ACP controller/supervisor (`acp serve`, foreground/background `run`, `agents`, native sessions, NDJSON); `bro update` and channels |
| `references/decision-native.md` | TypeSafe decision configuration, native BRO context views, evidence recall and decision accounting |

## Gotchas

- Request-check extensions use SDK ExtensionApi and the shared foreground host. Restart the same custom binary, not official `bro restart`. No HTTP service or probe; legacy `plugins.bitrouter-guardrails` blocks startup. See `references/guardrails.md`.
- **A Skill does not grant command execution.** If the host cannot run local
  processes, explain that this local integration is unavailable; do not suggest
  the removed OSS origin MCP server as a fallback.
- MCP upstreams default to modern `server/discover` with rmcp's classified
  legacy fallback. Set `mcp.upstream_protocol: latest` only when an upstream
  must use the legacy `initialize` lifecycle.
- `server.skip_auth: false` protects both model and MCP routes with the same
  `brvk_` virtual-key validation. Static credentials under `mcp_servers` are
  for BitRouter's upstream hop; they do not authenticate a downstream caller.
- **Local port is `127.0.0.1:4356`** — old docs saying 8787 are stale. Hosted:
  `https://api.bitrouter.ai/v1` for the OpenAI shape, `https://api.bitrouter.ai`
  (no `/v1`) for the Anthropic SDK — same asymmetry locally.
- **Hosted sign-in is `cloud login` or `providers login bitrouter`** (same flow),
  everything else `providers login <id>`; there is no top-level `login`.
- **Remote control is separate from inference and ACP.** `control.enabled: true`
  starts a control API on `127.0.0.1:4358` with dedicated operator credentials
  (legacy `BITROUTER_CONTROL_TOKEN` grants reads only). Keep it loopback-only behind a
  private tunnel or TLS reverse proxy. `server.skip_auth` never disables this
  authentication, changes under `control:` require a daemon restart, and the
  control API does not run remote ACP sessions.
- **Native task HTTP is opt-in and separately privileged.** `agent_api.enabled:
  true` requires a loopback `listen`, `token_env`, and exact `workspaces`
  allowlist. `server.skip_auth` never admits an HTTP task caller.
- **`init --harness` only accepts `claude` and `codex`**; `launch <agent>`
  accepts the native facets listed by `launch --help`.
- **`providers add/remove/use/test/stats` and `bro doctor` do not exist.** Manage
  with `providers list|login|logout` + config/reload; diagnose via `status`, `route`, `models`, and logs.
- **`bitrouter/<id>` selects a named router** before provider lookup; `auto` and
  `fusion` retain compatibility behavior. See `references/cli.md` for details.
